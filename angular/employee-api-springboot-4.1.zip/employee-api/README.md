# Employee API

Spring Boot 4.1.0 + Spring Security JWT + PostgreSQL backend for the Angular Employee CRUD application.

## Requirements

- Java 21
- Maven 3.6.3+
- Docker / Docker Compose (for PostgreSQL)

## Option A: Start PostgreSQL + API with Docker

```bash
docker compose up --build
```

## Option B: Run PostgreSQL in Docker and API locally

```bash
docker compose up -d postgres
mvn spring-boot:run
```

API base URL: `http://localhost:8080`

## Development user

The `dev` profile seeds:

- Email: `admin@test.com`
- Password: `admin123`

It also seeds three employees.

## Public endpoints

- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`

## Protected employee endpoints

All require `Authorization: Bearer <accessToken>`.

- `GET /api/employees`
- `GET /api/employees/{id}`
- `POST /api/employees`
- `PUT /api/employees/{id}`
- `DELETE /api/employees/{id}`

## Login

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@test.com","password":"admin123"}'
```

## Call protected endpoint

```bash
TOKEN='<paste accessToken>'

curl http://localhost:8080/api/employees \
  -H "Authorization: Bearer $TOKEN"
```

## Angular changes

Change Angular URLs from JSON Server to Spring Boot:

- Login: `http://localhost:8080/api/auth/login`
- Register: `http://localhost:8080/api/auth/register`
- Employees: `http://localhost:8080/api/employees`

The existing Angular JWT interceptor can continue sending:

```text
Authorization: Bearer <token>
```

The existing route guard can continue protecting `/employees`.

## Production

Run with the `prod` profile and provide environment variables:

```bash
SPRING_PROFILES_ACTIVE=prod \
DB_URL=jdbc:postgresql://host:5432/employeedb \
DB_USERNAME=... \
DB_PASSWORD=... \
JWT_SECRET=... \
CORS_ALLOWED_ORIGINS=https://your-angular-app.example \
mvn spring-boot:run
```

Use a cryptographically random JWT secret of at least 32 bytes. Do not use the development default secret in production.


## Postman

Import `postman/Employee_API.postman_collection.json`. The Login request automatically stores the returned `accessToken` for protected employee requests.
