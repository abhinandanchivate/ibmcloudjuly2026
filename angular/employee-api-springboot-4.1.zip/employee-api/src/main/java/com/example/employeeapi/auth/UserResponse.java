package com.example.employeeapi.auth;

public record UserResponse(
        Long id,
        String name,
        String email,
        String role
) {
}
