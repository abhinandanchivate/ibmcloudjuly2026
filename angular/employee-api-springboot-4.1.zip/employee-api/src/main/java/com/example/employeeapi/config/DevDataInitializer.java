package com.example.employeeapi.config;

import com.example.employeeapi.employee.Employee;
import com.example.employeeapi.employee.EmployeeRepository;
import com.example.employeeapi.user.AppUser;
import com.example.employeeapi.user.AppUserRepository;
import com.example.employeeapi.user.Role;
import java.math.BigDecimal;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@Profile("dev")
public class DevDataInitializer {

    @Bean
    CommandLineRunner seedData(
            AppUserRepository userRepository,
            EmployeeRepository employeeRepository,
            PasswordEncoder passwordEncoder) {

        return args -> {
            if (!userRepository.existsByEmailIgnoreCase("admin@test.com")) {
                userRepository.save(new AppUser(
                        "Admin User",
                        "admin@test.com",
                        passwordEncoder.encode("admin123"),
                        Role.ADMIN
                ));
            }

            if (employeeRepository.count() == 0) {
                employeeRepository.save(new Employee(
                        "Amit Sharma",
                        "amit@gmail.com",
                        "IT",
                        new BigDecimal("75000.00"),
                        "Pune"
                ));

                employeeRepository.save(new Employee(
                        "Priya Patil",
                        "priya@gmail.com",
                        "HR",
                        new BigDecimal("65000.00"),
                        "Mumbai"
                ));

                employeeRepository.save(new Employee(
                        "Rahul Verma",
                        "rahul@gmail.com",
                        "Finance",
                        new BigDecimal("70000.00"),
                        "Bengaluru"
                ));
            }
        };
    }
}
