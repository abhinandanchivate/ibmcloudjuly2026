package com.example.employeeapi.employee;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false, length = 100)
    private String department;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal salary;

    @Column(nullable = false, length = 100)
    private String city;

    protected Employee() {
    }

    public Employee(
            String name,
            String email,
            String department,
            BigDecimal salary,
            String city) {
        this.name = name;
        this.email = email;
        this.department = department;
        this.salary = salary;
        this.city = city;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public String getCity() {
        return city;
    }

    public void update(
            String name,
            String email,
            String department,
            BigDecimal salary,
            String city) {
        this.name = name;
        this.email = email;
        this.department = department;
        this.salary = salary;
        this.city = city;
    }
}
