package com.example.employeeapi.employee;

import java.math.BigDecimal;

public record EmployeeResponse(
        Long id,
        String name,
        String email,
        String department,
        BigDecimal salary,
        String city
) {
}
