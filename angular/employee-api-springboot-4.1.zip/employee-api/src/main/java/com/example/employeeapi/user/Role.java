package com.example.employeeapi.user;

public enum Role {
    USER,
    ADMIN
}
