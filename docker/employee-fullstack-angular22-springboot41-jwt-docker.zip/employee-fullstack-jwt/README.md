# Employee Full Stack - Angular NgModules + Spring Boot Security + JWT + PostgreSQL + Docker Compose

## Stack

- Angular 22.x using **NgModules**
- Spring Boot 4.1.1
- Java 21
- Spring Security
- JWT using JJWT
- Spring Data JPA
- PostgreSQL 17
- Docker + Docker Compose
- Nginx for Angular production build

## Features

- Register user
- Login
- JWT generation and validation
- USER / ADMIN roles
- Employee CRUD
- AuthGuard
- JWT HTTP interceptor
- PostgreSQL persistence
- Dockerized frontend, backend, and database

## Default admin account

When the backend starts, it creates this admin account if it does not already exist:

- Email: `admin@example.com`
- Password: `Admin@123`

You can override these values with the Docker Compose environment variables.

## Run everything with Docker

From the project root:

```bash
docker compose up --build
```

Open:

- Angular UI: http://localhost:4200
- Spring Boot API: http://localhost:8080
- Spring Boot health: http://localhost:8080/actuator/health
- PostgreSQL: localhost:5432

Stop:

```bash
docker compose down
```

Stop and delete database volume:

```bash
docker compose down -v
```

## Run backend locally

Start PostgreSQL first or change datasource settings.

```bash
cd backend
mvn spring-boot:run
```

## Run Angular locally

Angular 22 requires a supported Node version. Use Node 24.15+ or another Angular-22-supported Node release.

```bash
cd frontend
npm install
npm start
```

The Angular dev proxy forwards `/api` to `http://localhost:8080`.

## API endpoints

### Public

```text
POST /api/auth/register
POST /api/auth/login
GET  /actuator/health
```

### Authenticated USER or ADMIN

```text
GET /api/employees
GET /api/employees/{id}
```

### ADMIN only

```text
POST   /api/employees
PUT    /api/employees/{id}
DELETE /api/employees/{id}
```

## Login request

```json
{
  "email": "admin@example.com",
  "password": "Admin@123"
}
```

## Authorization header

```text
Authorization: Bearer <token>
```
