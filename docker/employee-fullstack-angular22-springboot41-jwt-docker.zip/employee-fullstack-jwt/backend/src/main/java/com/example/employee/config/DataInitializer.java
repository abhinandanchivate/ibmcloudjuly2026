package com.example.employee.config;

import com.example.employee.entity.AppUser;
import com.example.employee.entity.Employee;
import com.example.employee.entity.Role;
import com.example.employee.repository.AppUserRepository;
import com.example.employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initializeData(
        AppUserRepository userRepository,
        EmployeeRepository employeeRepository,
        PasswordEncoder passwordEncoder,
        @Value("${app.admin.email}") String adminEmail,
        @Value("${app.admin.password}") String adminPassword
    ) {
        return args -> {

            if (!userRepository.existsByEmailIgnoreCase(adminEmail)) {
                AppUser admin = new AppUser(
                    "System Admin",
                    adminEmail.toLowerCase(),
                    passwordEncoder.encode(adminPassword),
                    Role.ADMIN
                );

                userRepository.save(admin);
            }

            if (employeeRepository.count() == 0) {
                employeeRepository.save(
                    new Employee(
                        "Asha Patil",
                        "asha@example.com",
                        "Engineering",
                        new BigDecimal("85000.00")
                    )
                );

                employeeRepository.save(
                    new Employee(
                        "Rahul Sharma",
                        "rahul@example.com",
                        "Training",
                        new BigDecimal("72000.00")
                    )
                );
            }
        };
    }
}
