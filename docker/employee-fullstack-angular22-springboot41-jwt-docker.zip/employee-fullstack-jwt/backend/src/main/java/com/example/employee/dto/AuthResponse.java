package com.example.employee.dto;

public record AuthResponse(
    String token,
    String tokenType,
    String email,
    String name,
    String role
) {
}
