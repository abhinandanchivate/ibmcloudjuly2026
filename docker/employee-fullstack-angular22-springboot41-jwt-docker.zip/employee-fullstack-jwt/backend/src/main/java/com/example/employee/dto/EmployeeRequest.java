package com.example.employee.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record EmployeeRequest(

    @NotBlank(message = "Name is required")
    @Size(max = 100, message = "Name can contain at most 100 characters")
    String name,

    @NotBlank(message = "Email is required")
    @Email(message = "Email is invalid")
    String email,

    @NotBlank(message = "Department is required")
    @Size(max = 100, message = "Department can contain at most 100 characters")
    String department,

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Salary cannot be negative")
    BigDecimal salary
) {
}
