package com.example.employee.entity;

public enum Role {
    USER,
    ADMIN
}
