package com.example.employee.service;

import com.example.employee.dto.AuthResponse;
import com.example.employee.dto.LoginRequest;
import com.example.employee.dto.RegisterRequest;
import com.example.employee.entity.AppUser;
import com.example.employee.entity.Role;
import com.example.employee.repository.AppUserRepository;
import com.example.employee.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private final AppUserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthService(
        AppUserRepository userRepository,
        PasswordEncoder passwordEncoder,
        AuthenticationManager authenticationManager,
        JwtService jwtService
    ) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @Transactional
    public AuthResponse register(RegisterRequest request) {

        String email = request.email().trim().toLowerCase();

        if (userRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException("Email is already registered");
        }

        AppUser user = new AppUser(
            request.name().trim(),
            email,
            passwordEncoder.encode(request.password()),
            Role.USER
        );

        AppUser saved = userRepository.save(user);

        UserDetails userDetails =
            org.springframework.security.core.userdetails.User
                .withUsername(saved.getEmail())
                .password(saved.getPassword())
                .roles(saved.getRole().name())
                .build();

        String token = jwtService.generateToken(userDetails);

        return new AuthResponse(
            token,
            "Bearer",
            saved.getEmail(),
            saved.getName(),
            saved.getRole().name()
        );
    }

    public AuthResponse login(LoginRequest request) {

        String email = request.email().trim().toLowerCase();

        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                email,
                request.password()
            )
        );

        AppUser user = userRepository.findByEmailIgnoreCase(email)
            .orElseThrow(() ->
                new IllegalArgumentException("User not found")
            );

        UserDetails userDetails =
            org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())
                .build();

        String token = jwtService.generateToken(userDetails);

        return new AuthResponse(
            token,
            "Bearer",
            user.getEmail(),
            user.getName(),
            user.getRole().name()
        );
    }
}
