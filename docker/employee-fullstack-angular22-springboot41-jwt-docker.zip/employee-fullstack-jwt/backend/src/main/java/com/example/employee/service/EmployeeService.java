package com.example.employee.service;

import com.example.employee.dto.EmployeeRequest;
import com.example.employee.dto.EmployeeResponse;
import com.example.employee.entity.Employee;
import com.example.employee.exception.ResourceNotFoundException;
import com.example.employee.repository.EmployeeRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Transactional(readOnly = true)
    public List<EmployeeResponse> findAll() {

        return employeeRepository
            .findAll(Sort.by(Sort.Direction.ASC, "id"))
            .stream()
            .map(this::toResponse)
            .toList();
    }

    @Transactional(readOnly = true)
    public EmployeeResponse findById(Long id) {
        return toResponse(getEmployee(id));
    }

    @Transactional
    public EmployeeResponse create(EmployeeRequest request) {

        String email = request.email().trim().toLowerCase();

        if (employeeRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException(
                "Employee email already exists"
            );
        }

        Employee employee = new Employee(
            request.name().trim(),
            email,
            request.department().trim(),
            request.salary()
        );

        return toResponse(employeeRepository.save(employee));
    }

    @Transactional
    public EmployeeResponse update(Long id, EmployeeRequest request) {

        Employee employee = getEmployee(id);

        String email = request.email().trim().toLowerCase();

        if (
            employeeRepository.existsByEmailIgnoreCaseAndIdNot(email, id)
        ) {
            throw new IllegalArgumentException(
                "Employee email already exists"
            );
        }

        employee.setName(request.name().trim());
        employee.setEmail(email);
        employee.setDepartment(request.department().trim());
        employee.setSalary(request.salary());

        return toResponse(employeeRepository.save(employee));
    }

    @Transactional
    public void delete(Long id) {
        Employee employee = getEmployee(id);
        employeeRepository.delete(employee);
    }

    private Employee getEmployee(Long id) {
        return employeeRepository.findById(id)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Employee not found with id " + id
                )
            );
    }

    private EmployeeResponse toResponse(Employee employee) {
        return new EmployeeResponse(
            employee.getId(),
            employee.getName(),
            employee.getEmail(),
            employee.getDepartment(),
            employee.getSalary()
        );
    }
}
