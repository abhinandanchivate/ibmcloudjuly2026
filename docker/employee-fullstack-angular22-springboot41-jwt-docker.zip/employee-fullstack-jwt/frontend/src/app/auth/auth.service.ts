import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';

import {
  AuthResponse,
  LoginRequest,
  RegisterRequest
} from '../core/models/auth.models';

import { TokenService } from '../core/services/token.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly apiUrl = '/api/auth';

  constructor(
    private http: HttpClient,
    private tokenService: TokenService,
    private router: Router
  ) {
  }

  login(
    request: LoginRequest
  ): Observable<AuthResponse> {

    return this.http
      .post<AuthResponse>(
        `${this.apiUrl}/login`,
        request
      )
      .pipe(
        tap(response =>
          this.tokenService.saveAuth(response)
        )
      );
  }

  register(
    request: RegisterRequest
  ): Observable<AuthResponse> {

    return this.http
      .post<AuthResponse>(
        `${this.apiUrl}/register`,
        request
      )
      .pipe(
        tap(response =>
          this.tokenService.saveAuth(response)
        )
      );
  }

  logout(): void {
    this.tokenService.clear();

    void this.router.navigate([
      '/login'
    ]);
  }

  isLoggedIn(): boolean {
    return this.tokenService.hasToken();
  }

  isAdmin(): boolean {
    return this.tokenService.isAdmin();
  }

  currentUserName(): string {
    return this.tokenService.getUser()?.name ?? '';
  }

  currentRole(): string {
    return this.tokenService.getUser()?.role ?? '';
  }
}
