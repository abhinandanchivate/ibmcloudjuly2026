import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  UrlTree
} from '@angular/router';

import { TokenService } from '../services/token.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {

  constructor(
    private tokenService: TokenService,
    private router: Router
  ) {
  }

  canActivate(): boolean | UrlTree {

    if (this.tokenService.isAdmin()) {
      return true;
    }

    return this.router.createUrlTree([
      '/employees'
    ]);
  }
}
