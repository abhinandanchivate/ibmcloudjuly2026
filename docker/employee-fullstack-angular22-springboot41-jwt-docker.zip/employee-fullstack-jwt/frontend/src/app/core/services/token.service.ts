import { Injectable } from '@angular/core';

import { AuthResponse } from '../models/auth.models';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  private readonly tokenKey = 'employee_auth_token';
  private readonly userKey = 'employee_auth_user';

  saveAuth(response: AuthResponse): void {
    localStorage.setItem(
      this.tokenKey,
      response.token
    );

    localStorage.setItem(
      this.userKey,
      JSON.stringify({
        email: response.email,
        name: response.name,
        role: response.role
      })
    );
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  getUser(): {
    email: string;
    name: string;
    role: 'USER' | 'ADMIN';
  } | null {

    const raw = localStorage.getItem(this.userKey);

    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  clear(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  hasToken(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    return this.getUser()?.role === 'ADMIN';
  }
}
