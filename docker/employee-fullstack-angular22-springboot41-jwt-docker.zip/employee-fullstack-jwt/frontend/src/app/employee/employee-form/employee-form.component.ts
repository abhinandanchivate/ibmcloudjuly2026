import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-form',
  standalone: false,
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent implements OnInit {

  employeeForm: FormGroup;

  employeeId: number | null = null;
  loading = false;
  saving = false;
  errorMessage = '';

  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.employeeForm = this.formBuilder.group({
      name: [
        '',
        Validators.required
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ],
      department: [
        '',
        Validators.required
      ],
      salary: [
        0,
        [
          Validators.required,
          Validators.min(0)
        ]
      ]
    });
  }

  ngOnInit(): void {

    const idParam =
      this.route.snapshot.paramMap.get('id');

    if (!idParam) {
      return;
    }

    this.employeeId = Number(idParam);

    if (Number.isNaN(this.employeeId)) {
      this.errorMessage =
        'Invalid employee id';

      return;
    }

    this.loadEmployee(this.employeeId);
  }

  get isEditMode(): boolean {
    return this.employeeId !== null;
  }

  submit(): void {

    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }

    this.saving = true;
    this.errorMessage = '';

    const employee =
      this.employeeForm.getRawValue();

    const request$ =
      this.employeeId === null
        ? this.employeeService.create(employee)
        : this.employeeService.update(
            this.employeeId,
            employee
          );

    request$.subscribe({
      next: () => {
        void this.router.navigate([
          '/employees'
        ]);
      },

      error: (error: HttpErrorResponse) => {
        this.errorMessage =
          error.error?.message
          ?? 'Could not save employee';

        this.saving = false;
      }
    });
  }

  private loadEmployee(id: number): void {

    this.loading = true;

    this.employeeService
      .findById(id)
      .subscribe({
        next: employee => {

          this.employeeForm.patchValue({
            name: employee.name,
            email: employee.email,
            department: employee.department,
            salary: employee.salary
          });

          this.loading = false;
        },

        error: (error: HttpErrorResponse) => {
          this.errorMessage =
            error.error?.message
            ?? 'Could not load employee';

          this.loading = false;
        }
      });
  }
}
