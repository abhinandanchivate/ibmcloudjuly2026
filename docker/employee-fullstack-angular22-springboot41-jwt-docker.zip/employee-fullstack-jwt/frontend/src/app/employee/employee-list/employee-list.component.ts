import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { Employee } from '../../core/models/employee.model';
import { EmployeeService } from '../employee.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-employee-list',
  standalone: false,
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent implements OnInit {

  employees: Employee[] = [];

  loading = false;
  errorMessage = '';

  constructor(
    private employeeService: EmployeeService,
    public authService: AuthService
  ) {
  }

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {

    this.loading = true;
    this.errorMessage = '';

    this.employeeService
      .findAll()
      .subscribe({
        next: employees => {
          this.employees = employees;
          this.loading = false;
        },

        error: (error: HttpErrorResponse) => {
          this.errorMessage =
            error.error?.message
            ?? 'Could not load employees';

          this.loading = false;
        }
      });
  }

  deleteEmployee(employee: Employee): void {

    if (!employee.id) {
      return;
    }

    const confirmed = window.confirm(
      `Delete ${employee.name}?`
    );

    if (!confirmed) {
      return;
    }

    this.employeeService
      .delete(employee.id)
      .subscribe({
        next: () => {
          this.loadEmployees();
        },

        error: (error: HttpErrorResponse) => {
          this.errorMessage =
            error.error?.message
            ?? 'Could not delete employee';
        }
      });
  }
}
