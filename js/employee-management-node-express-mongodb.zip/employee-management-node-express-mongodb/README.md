# Employee Management System

Full-stack CRUD project using **Node.js, Express 5, MongoDB, Mongoose, HTML, CSS and vanilla JavaScript**.

## Features

- Create, read, update, patch and delete employees
- MongoDB persistence through Mongoose
- Layered backend: routes, controllers, services and repositories
- Request validation and Mongoose schema validation
- Unique employee email handling
- Centralized exception handling
- Search in the browser
- Dashboard statistics from the backend
- Responsive frontend based on the supplied Employee Management HTML
- MongoDB seed script
- Postman collection
- Dockerfile and Docker Compose
- Health endpoint and graceful shutdown

## Project structure

```text
employee-management-node-express-mongodb/
├── public/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── scripts/seed.js
├── src/
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── repositories/
│   ├── routes/
│   ├── services/
│   ├── utils/
│   ├── validators/
│   ├── app.js
│   └── server.js
├── postman/
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── package.json
```

## Requirements

- Node.js 22 or newer
- MongoDB 7/8, or Docker Desktop
- npm

## Option 1: Run locally

### 1. Install packages

```bash
npm install
```

### 2. Create environment file

macOS/Linux:

```bash
cp .env.example .env
```

Windows Command Prompt:

```bat
copy .env.example .env
```

Default `.env` values:

```env
NODE_ENV=development
PORT=3000
MONGODB_URI=mongodb://localhost:27017/employee_management
```

### 3. Start MongoDB

Use your local MongoDB service, or start only MongoDB with Docker:

```bash
docker compose up -d mongodb
```

### 4. Load sample data

```bash
npm run seed
```

### 5. Start the application

Development mode:

```bash
npm run dev
```

Normal mode:

```bash
npm start
```

Open:

```text
http://localhost:3000
```

## Option 2: Run everything with Docker

```bash
docker compose up --build
```

In another terminal, seed the database:

```bash
docker compose exec app npm run seed
```

Open:

```text
http://localhost:3000
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Application health |
| GET | `/api/employees` | Get all employees |
| GET | `/api/employees?status=Active` | Filter by status |
| GET | `/api/employees?q=amit` | Search employees |
| GET | `/api/employees/stats` | Dashboard statistics |
| GET | `/api/employees/:id` | Get employee by ID |
| POST | `/api/employees` | Create employee |
| PUT | `/api/employees/:id` | Replace employee fields |
| PATCH | `/api/employees/:id` | Partially update employee |
| DELETE | `/api/employees/:id` | Delete employee |

## Example request

```json
{
  "name": "Rohit Mehta",
  "email": "rohit.mehta@example.com",
  "department": "Information Technology",
  "designation": "Node.js Developer",
  "salary": 72000,
  "status": "Active",
  "joiningDate": "2026-08-04"
}
```

## Verify source syntax

```bash
npm run check
```

## Postman

Import:

```text
postman/Employee_Management_Node_Mongo.postman_collection.json
```

The collection uses:

```text
baseUrl = http://localhost:3000
```
