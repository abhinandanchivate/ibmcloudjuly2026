"use strict";

const API_URL = "/api/employees";

let employees = [];
let employeeIdToDelete = null;
let notificationTimer;

const employeeForm = document.getElementById("employeeForm");
const employeeIdInput = document.getElementById("employeeId");
const employeeNameInput = document.getElementById("employeeName");
const employeeEmailInput = document.getElementById("employeeEmail");
const employeeDepartmentInput = document.getElementById("employeeDepartment");
const employeeDesignationInput = document.getElementById("employeeDesignation");
const employeeSalaryInput = document.getElementById("employeeSalary");
const employeeStatusInput = document.getElementById("employeeStatus");
const employeeJoiningDateInput = document.getElementById("employeeJoiningDate");
const employeeTableBody = document.getElementById("employeeTableBody");
const formTitle = document.getElementById("formTitle");
const submitButton = document.getElementById("submitButton");
const submitButtonText = document.getElementById("submitButtonText");
const cancelButton = document.getElementById("cancelButton");
const resetButton = document.getElementById("resetButton");
const searchInput = document.getElementById("searchInput");
const totalEmployeesElement = document.getElementById("totalEmployees");
const activeEmployeesElement = document.getElementById("activeEmployees");
const totalDepartmentsElement = document.getElementById("totalDepartments");
const displayedEmployeeCount = document.getElementById("displayedEmployeeCount");
const notification = document.getElementById("notification");
const loadingIndicator = document.getElementById("loadingIndicator");
const emptyState = document.getElementById("emptyState");
const deleteModal = document.getElementById("deleteModal");
const deleteEmployeeName = document.getElementById("deleteEmployeeName");
const cancelDeleteButton = document.getElementById("cancelDeleteButton");
const confirmDeleteButton = document.getElementById("confirmDeleteButton");

window.addEventListener("DOMContentLoaded", initializeApplication);

function initializeApplication() {
  setMaximumJoiningDate();
  registerEventListeners();
  loadEmployees();
}

function registerEventListeners() {
  employeeForm.addEventListener("submit", handleFormSubmit);
  cancelButton.addEventListener("click", resetEmployeeForm);
  resetButton.addEventListener("click", () => setTimeout(resetEmployeeForm, 0));
  searchInput.addEventListener("input", filterEmployees);
  employeeTableBody.addEventListener("click", handleTableAction);
  cancelDeleteButton.addEventListener("click", closeDeleteModal);
  confirmDeleteButton.addEventListener("click", deleteEmployee);
  deleteModal.addEventListener("click", event => {
    if (event.target === deleteModal) closeDeleteModal();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !deleteModal.classList.contains("hidden")) {
      closeDeleteModal();
    }
  });

  employeeForm.querySelectorAll("input, select").forEach(element => {
    element.addEventListener("input", clearFieldError);
    element.addEventListener("change", clearFieldError);
  });
}

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/json",
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.headers ?? {})
    }
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(payload.message || `Request failed with status ${response.status}.`);
    error.details = payload.details;
    error.status = response.status;
    throw error;
  }

  return payload;
}

async function loadEmployees() {
  showLoading(true);

  try {
    const [employeeResponse, statsResponse] = await Promise.all([
      apiRequest(API_URL),
      apiRequest(`${API_URL}/stats`)
    ]);

    employees = employeeResponse.data ?? [];
    renderEmployees(employees);
    renderStatistics(statsResponse.data);
  } catch (error) {
    console.error(error);
    employees = [];
    renderEmployees(employees);
    renderStatistics({ totalEmployees: 0, activeEmployees: 0, totalDepartments: 0 });
    showNotification(
      "Unable to load employees. Verify that the Express server and MongoDB are running.",
      "error"
    );
  } finally {
    showLoading(false);
  }
}

async function handleFormSubmit(event) {
  event.preventDefault();
  clearAllValidationErrors();

  if (!validateEmployeeForm()) {
    showNotification("Please correct the highlighted form fields.", "warning");
    return;
  }

  const employeeData = collectEmployeeFormData();
  const employeeId = employeeIdInput.value.trim();
  setSubmitButtonLoading(true);

  try {
    const response = employeeId
      ? await apiRequest(`${API_URL}/${employeeId}`, {
          method: "PUT",
          body: JSON.stringify(employeeData)
        })
      : await apiRequest(API_URL, {
          method: "POST",
          body: JSON.stringify(employeeData)
        });

    showNotification(response.message, "success");
    resetEmployeeForm();
    await loadEmployees();
  } catch (error) {
    applyServerValidationErrors(error.details);
    showNotification(error.message, "error");
  } finally {
    setSubmitButtonLoading(false);
  }
}

async function deleteEmployee() {
  if (!employeeIdToDelete) return;

  confirmDeleteButton.disabled = true;
  confirmDeleteButton.textContent = "Deleting...";

  try {
    const response = await apiRequest(`${API_URL}/${employeeIdToDelete}`, {
      method: "DELETE"
    });

    if (employeeIdInput.value === employeeIdToDelete) resetEmployeeForm();
    closeDeleteModal();
    showNotification(response.message, "success");
    await loadEmployees();
  } catch (error) {
    showNotification(error.message, "error");
  } finally {
    confirmDeleteButton.disabled = false;
    confirmDeleteButton.textContent = "Delete Employee";
  }
}

function renderEmployees(employeeList) {
  employeeTableBody.innerHTML = "";
  displayedEmployeeCount.textContent = employeeList.length;

  if (employeeList.length === 0) {
    emptyState.classList.remove("hidden");
    return;
  }

  emptyState.classList.add("hidden");

  employeeList.forEach(employee => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>
        <div class="employee-info">
          <div class="employee-avatar">${getEmployeeInitials(employee.name)}</div>
          <div class="employee-details">
            <h4>${escapeHtml(employee.name)}</h4>
            <p>${escapeHtml(employee.email)}</p>
          </div>
        </div>
      </td>
      <td>${escapeHtml(employee.department)}</td>
      <td>${escapeHtml(employee.designation)}</td>
      <td class="salary">${formatSalary(employee.salary)}</td>
      <td>${formatDate(employee.joiningDate)}</td>
      <td><span class="status-badge ${getStatusClass(employee.status)}">${escapeHtml(employee.status)}</span></td>
      <td class="action-column">
        <div class="action-buttons">
          <button type="button" class="action-btn edit-btn" data-action="edit" data-id="${employee.id}" title="Edit employee" aria-label="Edit ${escapeHtml(employee.name)}">✏️</button>
          <button type="button" class="action-btn delete-btn" data-action="delete" data-id="${employee.id}" title="Delete employee" aria-label="Delete ${escapeHtml(employee.name)}">🗑️</button>
        </div>
      </td>`;
    employeeTableBody.appendChild(row);
  });
}

function renderStatistics(statistics = {}) {
  totalEmployeesElement.textContent = statistics.totalEmployees ?? 0;
  activeEmployeesElement.textContent = statistics.activeEmployees ?? 0;
  totalDepartmentsElement.textContent = statistics.totalDepartments ?? 0;
}

function handleTableAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  if (button.dataset.action === "edit") editEmployee(button.dataset.id);
  if (button.dataset.action === "delete") openDeleteModal(button.dataset.id);
}

function editEmployee(id) {
  const employee = employees.find(item => item.id === id);
  if (!employee) return showNotification("Employee record was not found.", "error");

  employeeIdInput.value = employee.id;
  employeeNameInput.value = employee.name;
  employeeEmailInput.value = employee.email;
  employeeDepartmentInput.value = employee.department;
  employeeDesignationInput.value = employee.designation;
  employeeSalaryInput.value = employee.salary;
  employeeStatusInput.value = employee.status;
  employeeJoiningDateInput.value = String(employee.joiningDate).split("T")[0];
  formTitle.textContent = "Update Employee";
  submitButtonText.textContent = "Update Employee";
  cancelButton.classList.remove("hidden");
  clearAllValidationErrors();
  window.scrollTo({ top: 0, behavior: "smooth" });
  employeeNameInput.focus();
}

function openDeleteModal(id) {
  const employee = employees.find(item => item.id === id);
  if (!employee) return showNotification("Employee record was not found.", "error");

  employeeIdToDelete = id;
  deleteEmployeeName.textContent = employee.name;
  deleteModal.classList.remove("hidden");
  confirmDeleteButton.focus();
}

function closeDeleteModal() {
  employeeIdToDelete = null;
  deleteEmployeeName.textContent = "this employee";
  deleteModal.classList.add("hidden");
}

function filterEmployees() {
  const searchText = searchInput.value.trim().toLowerCase();
  if (!searchText) return renderEmployees(employees);

  const filteredEmployees = employees.filter(employee =>
    [
      employee.name,
      employee.email,
      employee.department,
      employee.designation,
      employee.status,
      employee.joiningDate,
      employee.salary
    ]
      .join(" ")
      .toLowerCase()
      .includes(searchText)
  );

  renderEmployees(filteredEmployees);
}

function collectEmployeeFormData() {
  return {
    name: employeeNameInput.value.trim(),
    email: employeeEmailInput.value.trim().toLowerCase(),
    department: employeeDepartmentInput.value,
    designation: employeeDesignationInput.value.trim(),
    salary: Number(employeeSalaryInput.value),
    status: employeeStatusInput.value,
    joiningDate: employeeJoiningDateInput.value
  };
}

function validateEmployeeForm() {
  const data = collectEmployeeFormData();
  let valid = true;

  if (data.name.length < 3) {
    showFieldError(employeeNameInput, "Name must contain at least 3 characters.");
    valid = false;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    showFieldError(employeeEmailInput, "Enter a valid email address.");
    valid = false;
  }

  if (!data.department) {
    showFieldError(employeeDepartmentInput, "Select an employee department.");
    valid = false;
  }

  if (data.designation.length < 2) {
    showFieldError(employeeDesignationInput, "Enter a valid designation.");
    valid = false;
  }

  if (!Number.isFinite(data.salary) || data.salary <= 0) {
    showFieldError(employeeSalaryInput, "Salary must be greater than zero.");
    valid = false;
  }

  if (!data.status) {
    showFieldError(employeeStatusInput, "Select an employment status.");
    valid = false;
  }

  if (!data.joiningDate) {
    showFieldError(employeeJoiningDateInput, "Select the joining date.");
    valid = false;
  } else if (new Date(`${data.joiningDate}T00:00:00`) > new Date()) {
    showFieldError(employeeJoiningDateInput, "Joining date cannot be in the future.");
    valid = false;
  }

  return valid;
}

function applyServerValidationErrors(details) {
  if (!details) return;

  const elementByField = {
    name: employeeNameInput,
    email: employeeEmailInput,
    department: employeeDepartmentInput,
    designation: employeeDesignationInput,
    salary: employeeSalaryInput,
    status: employeeStatusInput,
    joiningDate: employeeJoiningDateInput
  };

  Object.entries(details).forEach(([field, message]) => {
    if (elementByField[field]) showFieldError(elementByField[field], message);
  });
}

function showFieldError(inputElement, message) {
  inputElement.classList.add("input-error");
  const errorElement = document.getElementById(`${inputElement.id}Error`);
  if (errorElement) errorElement.textContent = message;
}

function clearFieldError(event) {
  const element = event.target;
  element.classList.remove("input-error");
  const errorElement = document.getElementById(`${element.id}Error`);
  if (errorElement) errorElement.textContent = "";
}

function clearAllValidationErrors() {
  employeeForm.querySelectorAll(".input-error").forEach(element => element.classList.remove("input-error"));
  employeeForm.querySelectorAll(".error-message").forEach(element => (element.textContent = ""));
}

function resetEmployeeForm() {
  employeeForm.reset();
  employeeIdInput.value = "";
  employeeStatusInput.value = "Active";
  formTitle.textContent = "Add New Employee";
  submitButtonText.textContent = "Add Employee";
  cancelButton.classList.add("hidden");
  clearAllValidationErrors();
}

function showNotification(message, type = "success") {
  clearTimeout(notificationTimer);
  notification.textContent = message;
  notification.className = `notification notification-${type}`;
  notification.classList.remove("hidden");
  notificationTimer = setTimeout(() => notification.classList.add("hidden"), 4500);
}

function showLoading(isLoading) {
  loadingIndicator.classList.toggle("hidden", !isLoading);
  if (isLoading) {
    employeeTableBody.innerHTML = "";
    emptyState.classList.add("hidden");
  }
}

function setSubmitButtonLoading(isLoading) {
  submitButton.disabled = isLoading;
  submitButtonText.textContent = isLoading
    ? "Saving..."
    : employeeIdInput.value
      ? "Update Employee"
      : "Add Employee";
}

function formatSalary(salary) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(Number(salary) || 0);
}

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(date);
}

function setMaximumJoiningDate() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  employeeJoiningDateInput.max = `${year}-${month}-${day}`;
}

function getEmployeeInitials(name) {
  return String(name ?? "")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map(part => part[0] ?? "")
    .join("")
    .toUpperCase() || "NA";
}

function getStatusClass(status) {
  if (status === "Active") return "status-active";
  if (status === "Inactive") return "status-inactive";
  if (status === "On Leave") return "status-on-leave";
  return "";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
