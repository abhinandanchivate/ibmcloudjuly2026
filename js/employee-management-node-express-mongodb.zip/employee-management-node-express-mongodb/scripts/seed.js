import process from 'node:process';
import { connectDatabase, disconnectDatabase } from '../src/config/database.js';
import { Employee } from '../src/models/employee.model.js';

const employees = [
  {
    name: 'Amit Sharma',
    email: 'amit.sharma@example.com',
    department: 'Information Technology',
    designation: 'Software Engineer',
    salary: 65000,
    status: 'Active',
    joiningDate: '2024-01-15'
  },
  {
    name: 'Priya Patil',
    email: 'priya.patil@example.com',
    department: 'Human Resources',
    designation: 'HR Executive',
    salary: 48000,
    status: 'Active',
    joiningDate: '2023-08-10'
  },
  {
    name: 'Rahul Verma',
    email: 'rahul.verma@example.com',
    department: 'Finance',
    designation: 'Finance Analyst',
    salary: 58000,
    status: 'On Leave',
    joiningDate: '2022-11-21'
  },
  {
    name: 'Sneha Kulkarni',
    email: 'sneha.kulkarni@example.com',
    department: 'Marketing',
    designation: 'Marketing Manager',
    salary: 82000,
    status: 'Active',
    joiningDate: '2021-06-05'
  },
  {
    name: 'Vikram Singh',
    email: 'vikram.singh@example.com',
    department: 'Sales',
    designation: 'Sales Executive',
    salary: 52000,
    status: 'Inactive',
    joiningDate: '2023-02-18'
  },
  {
    name: 'Neha Joshi',
    email: 'neha.joshi@example.com',
    department: 'Operations',
    designation: 'Operations Coordinator',
    salary: 55000,
    status: 'Active',
    joiningDate: '2024-04-12'
  }
];

async function seed() {
  try {
    await connectDatabase();

    if (process.env.SEED_RESET !== 'false') {
      await Employee.deleteMany({});
    }

    for (const employee of employees) {
      await Employee.updateOne(
        { email: employee.email },
        { $set: employee },
        { upsert: true, runValidators: true }
      );
    }

    console.log(`Seed completed. ${employees.length} employees are available.`);
  } catch (error) {
    console.error('Seed failed:', error);
    process.exitCode = 1;
  } finally {
    await disconnectDatabase();
  }
}

seed();
