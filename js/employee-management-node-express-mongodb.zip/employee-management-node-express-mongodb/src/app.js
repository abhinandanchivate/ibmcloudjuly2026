import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { employeeRouter } from './routes/employee.routes.js';
import { notFoundMiddleware } from './middleware/notFound.middleware.js';
import { errorMiddleware } from './middleware/error.middleware.js';

const currentFile = fileURLToPath(import.meta.url);
const currentDirectory = path.dirname(currentFile);
const publicDirectory = path.join(currentDirectory, '..', 'public');

export const app = express();

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));

app.get('/api/health', (request, response) => {
  response.status(200).json({
    success: true,
    message: 'Employee Management API is running.',
    timestamp: new Date().toISOString()
  });
});

app.use('/api/employees', employeeRouter);
app.use(express.static(publicDirectory));

app.use(notFoundMiddleware);
app.use(errorMiddleware);
