import process from 'node:process';

try {
  process.loadEnvFile('.env');
} catch (error) {
  if (error?.code !== 'ENOENT') {
    throw error;
  }
}

export const env = Object.freeze({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 3000),
  mongodbUri:
    process.env.MONGODB_URI ??
    'mongodb://localhost:27017/employee_management'
});
