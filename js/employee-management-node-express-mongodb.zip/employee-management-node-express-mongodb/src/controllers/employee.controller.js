import { employeeService } from '../services/employee.service.js';

export const employeeController = {
  async getAll(request, response) {
    const employees = await employeeService.getEmployees({
      q: request.query.q,
      status: request.query.status,
      department: request.query.department
    });

    response.status(200).json({
      success: true,
      count: employees.length,
      data: employees
    });
  },

  async getStats(request, response) {
    const statistics = await employeeService.getStatistics();

    response.status(200).json({
      success: true,
      data: statistics
    });
  },

  async getById(request, response) {
    const employee = await employeeService.getEmployeeById(request.params.id);

    response.status(200).json({
      success: true,
      data: employee
    });
  },

  async create(request, response) {
    const employee = await employeeService.createEmployee(
      request.validatedEmployee
    );

    response.status(201).json({
      success: true,
      message: 'Employee created successfully.',
      data: employee
    });
  },

  async update(request, response) {
    const employee = await employeeService.updateEmployee(
      request.params.id,
      request.validatedEmployee
    );

    response.status(200).json({
      success: true,
      message: 'Employee updated successfully.',
      data: employee
    });
  },

  async patch(request, response) {
    const employee = await employeeService.patchEmployee(
      request.params.id,
      request.validatedEmployee
    );

    response.status(200).json({
      success: true,
      message: 'Employee updated successfully.',
      data: employee
    });
  },

  async remove(request, response) {
    const employee = await employeeService.deleteEmployee(request.params.id);

    response.status(200).json({
      success: true,
      message: 'Employee deleted successfully.',
      data: employee
    });
  }
};
