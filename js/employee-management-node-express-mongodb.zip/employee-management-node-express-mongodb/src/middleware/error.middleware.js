import { env } from '../config/env.js';

function mongooseValidationDetails(error) {
  return Object.fromEntries(
    Object.entries(error.errors ?? {}).map(([field, validationError]) => [
      field,
      validationError.message
    ])
  );
}

export function errorMiddleware(error, request, response, next) {
  void next;

  let statusCode = error.statusCode ?? 500;
  let message = error.message ?? 'Internal server error.';
  let details = error.details;

  if (error.name === 'ValidationError') {
    statusCode = 400;
    message = 'Employee validation failed.';
    details = mongooseValidationDetails(error);
  }

  if (error.name === 'CastError') {
    statusCode = 400;
    message = `Invalid ${error.path}: ${error.value}`;
  }

  if (error.code === 11000) {
    statusCode = 409;
    const duplicateField = Object.keys(error.keyPattern ?? {})[0] ?? 'field';
    message = `An employee with this ${duplicateField} already exists.`;
    details = {
      [duplicateField]: `${duplicateField} must be unique.`
    };
  }

  if (statusCode >= 500) {
    console.error(error);
  }

  response.status(statusCode).json({
    success: false,
    message,
    ...(details ? { details } : {}),
    ...(env.nodeEnv === 'development' && statusCode >= 500
      ? { stack: error.stack }
      : {})
  });
}
