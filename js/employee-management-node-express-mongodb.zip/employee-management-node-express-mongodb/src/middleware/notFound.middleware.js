import { ApiError } from '../utils/ApiError.js';

export function notFoundMiddleware(request, response, next) {
  next(
    new ApiError(
      404,
      `Route not found: ${request.method} ${request.originalUrl}`
    )
  );
}
