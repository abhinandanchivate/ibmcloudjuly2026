import mongoose from 'mongoose';

export const EMPLOYEE_DEPARTMENTS = Object.freeze([
  'Information Technology',
  'Human Resources',
  'Finance',
  'Sales',
  'Marketing',
  'Operations'
]);

export const EMPLOYEE_STATUSES = Object.freeze([
  'Active',
  'Inactive',
  'On Leave'
]);

const employeeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Employee name is required.'],
      trim: true,
      minlength: [3, 'Employee name must contain at least 3 characters.'],
      maxlength: [80, 'Employee name cannot exceed 80 characters.']
    },
    email: {
      type: String,
      required: [true, 'Employee email is required.'],
      trim: true,
      lowercase: true,
      maxlength: [120, 'Employee email cannot exceed 120 characters.'],
      match: [
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        'Enter a valid employee email address.'
      ]
    },
    department: {
      type: String,
      required: [true, 'Employee department is required.'],
      enum: {
        values: EMPLOYEE_DEPARTMENTS,
        message: '{VALUE} is not a supported department.'
      }
    },
    designation: {
      type: String,
      required: [true, 'Employee designation is required.'],
      trim: true,
      minlength: [2, 'Employee designation must contain at least 2 characters.'],
      maxlength: [100, 'Employee designation cannot exceed 100 characters.']
    },
    salary: {
      type: Number,
      required: [true, 'Employee salary is required.'],
      min: [1, 'Employee salary must be greater than zero.']
    },
    status: {
      type: String,
      required: [true, 'Employee status is required.'],
      enum: {
        values: EMPLOYEE_STATUSES,
        message: '{VALUE} is not a supported employee status.'
      },
      default: 'Active'
    },
    joiningDate: {
      type: Date,
      required: [true, 'Employee joining date is required.'],
      validate: {
        validator(value) {
          if (!value) {
            return false;
          }

          const today = new Date();
          today.setHours(23, 59, 59, 999);
          return value <= today;
        },
        message: 'Employee joining date cannot be in the future.'
      }
    }
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: {
      transform(document, returnedObject) {
        returnedObject.id = returnedObject._id.toString();
        delete returnedObject._id;
      }
    }
  }
);

employeeSchema.index({ email: 1 }, { unique: true });
employeeSchema.index({ name: 1 });
employeeSchema.index({ department: 1, status: 1 });

export const Employee = mongoose.model('Employee', employeeSchema);
