import mongoose from 'mongoose';
import { Employee } from '../models/employee.model.js';

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export const employeeRepository = {
  async findAll({ q, status, department } = {}) {
    const filter = {};

    if (q) {
      const pattern = new RegExp(escapeRegex(q.trim()), 'i');
      filter.$or = [
        { name: pattern },
        { email: pattern },
        { department: pattern },
        { designation: pattern },
        { status: pattern }
      ];
    }

    if (status) {
      filter.status = status;
    }

    if (department) {
      filter.department = department;
    }

    return Employee.find(filter).sort({ name: 1, createdAt: -1 });
  },

  async findById(id) {
    if (!mongoose.isValidObjectId(id)) {
      return null;
    }

    return Employee.findById(id);
  },

  async findByEmail(email) {
    return Employee.findOne({ email: email.toLowerCase() });
  },

  async create(payload) {
    return Employee.create(payload);
  },

  async updateById(id, payload) {
    if (!mongoose.isValidObjectId(id)) {
      return null;
    }

    return Employee.findByIdAndUpdate(id, payload, {
      new: true,
      runValidators: true,
      context: 'query'
    });
  },

  async deleteById(id) {
    if (!mongoose.isValidObjectId(id)) {
      return null;
    }

    return Employee.findByIdAndDelete(id);
  },

  async getStats() {
    const [totalEmployees, activeEmployees, departments] = await Promise.all([
      Employee.countDocuments(),
      Employee.countDocuments({ status: 'Active' }),
      Employee.distinct('department')
    ]);

    return {
      totalEmployees,
      activeEmployees,
      totalDepartments: departments.length
    };
  }
};
