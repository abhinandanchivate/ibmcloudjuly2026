import { Router } from 'express';
import { employeeController } from '../controllers/employee.controller.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import {
  validateCreateEmployee,
  validatePatchEmployee,
  validateUpdateEmployee
} from '../validators/employee.validator.js';

export const employeeRouter = Router();

employeeRouter.get('/stats', asyncHandler(employeeController.getStats));
employeeRouter.get('/', asyncHandler(employeeController.getAll));
employeeRouter.get('/:id', asyncHandler(employeeController.getById));
employeeRouter.post(
  '/',
  validateCreateEmployee,
  asyncHandler(employeeController.create)
);
employeeRouter.put(
  '/:id',
  validateUpdateEmployee,
  asyncHandler(employeeController.update)
);
employeeRouter.patch(
  '/:id',
  validatePatchEmployee,
  asyncHandler(employeeController.patch)
);
employeeRouter.delete('/:id', asyncHandler(employeeController.remove));
