import { employeeRepository } from '../repositories/employee.repository.js';
import { ApiError } from '../utils/ApiError.js';

export const employeeService = {
  async getEmployees(filters) {
    return employeeRepository.findAll(filters);
  },

  async getEmployeeById(id) {
    const employee = await employeeRepository.findById(id);

    if (!employee) {
      throw new ApiError(404, `Employee not found with ID: ${id}`);
    }

    return employee;
  },

  async createEmployee(payload) {
    const existingEmployee = await employeeRepository.findByEmail(payload.email);

    if (existingEmployee) {
      throw new ApiError(409, 'An employee with this email already exists.', {
        email: 'Employee email must be unique.'
      });
    }

    return employeeRepository.create(payload);
  },

  async updateEmployee(id, payload) {
    const existingEmployee = await employeeRepository.findByEmail(payload.email);

    if (existingEmployee && existingEmployee.id !== id) {
      throw new ApiError(409, 'Another employee already uses this email.', {
        email: 'Employee email must be unique.'
      });
    }

    const updatedEmployee = await employeeRepository.updateById(id, payload);

    if (!updatedEmployee) {
      throw new ApiError(404, `Employee not found with ID: ${id}`);
    }

    return updatedEmployee;
  },

  async patchEmployee(id, payload) {
    if (Object.keys(payload).length === 0) {
      throw new ApiError(400, 'Provide at least one employee field to update.');
    }

    if (payload.email) {
      const existingEmployee = await employeeRepository.findByEmail(payload.email);

      if (existingEmployee && existingEmployee.id !== id) {
        throw new ApiError(409, 'Another employee already uses this email.', {
          email: 'Employee email must be unique.'
        });
      }
    }

    const updatedEmployee = await employeeRepository.updateById(id, payload);

    if (!updatedEmployee) {
      throw new ApiError(404, `Employee not found with ID: ${id}`);
    }

    return updatedEmployee;
  },

  async deleteEmployee(id) {
    const deletedEmployee = await employeeRepository.deleteById(id);

    if (!deletedEmployee) {
      throw new ApiError(404, `Employee not found with ID: ${id}`);
    }

    return deletedEmployee;
  },

  async getStatistics() {
    return employeeRepository.getStats();
  }
};
