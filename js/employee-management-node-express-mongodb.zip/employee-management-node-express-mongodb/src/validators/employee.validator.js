import {
  EMPLOYEE_DEPARTMENTS,
  EMPLOYEE_STATUSES
} from '../models/employee.model.js';
import { ApiError } from '../utils/ApiError.js';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const allowedFields = new Set([
  'name',
  'email',
  'department',
  'designation',
  'salary',
  'status',
  'joiningDate'
]);

function normalizePayload(payload) {
  const normalized = {};

  for (const [key, value] of Object.entries(payload ?? {})) {
    if (!allowedFields.has(key)) {
      continue;
    }

    normalized[key] = typeof value === 'string' ? value.trim() : value;
  }

  if (typeof normalized.email === 'string') {
    normalized.email = normalized.email.toLowerCase();
  }

  if (normalized.salary !== undefined) {
    normalized.salary = Number(normalized.salary);
  }

  return normalized;
}

function collectErrors(payload, partial) {
  const errors = {};

  function shouldValidate(field) {
    return !partial || Object.hasOwn(payload, field);
  }

  if (shouldValidate('name')) {
    if (!payload.name) {
      errors.name = 'Employee name is required.';
    } else if (payload.name.length < 3) {
      errors.name = 'Employee name must contain at least 3 characters.';
    } else if (payload.name.length > 80) {
      errors.name = 'Employee name cannot exceed 80 characters.';
    }
  }

  if (shouldValidate('email')) {
    if (!payload.email) {
      errors.email = 'Employee email is required.';
    } else if (!EMAIL_PATTERN.test(payload.email)) {
      errors.email = 'Enter a valid employee email address.';
    }
  }

  if (shouldValidate('department')) {
    if (!EMPLOYEE_DEPARTMENTS.includes(payload.department)) {
      errors.department = 'Select a supported employee department.';
    }
  }

  if (shouldValidate('designation')) {
    if (!payload.designation) {
      errors.designation = 'Employee designation is required.';
    } else if (payload.designation.length < 2) {
      errors.designation = 'Employee designation must contain at least 2 characters.';
    }
  }

  if (shouldValidate('salary')) {
    if (!Number.isFinite(payload.salary) || payload.salary <= 0) {
      errors.salary = 'Employee salary must be greater than zero.';
    }
  }

  if (shouldValidate('status')) {
    if (!EMPLOYEE_STATUSES.includes(payload.status)) {
      errors.status = 'Select a supported employee status.';
    }
  }

  if (shouldValidate('joiningDate')) {
    if (!payload.joiningDate) {
      errors.joiningDate = 'Employee joining date is required.';
    } else {
      const joiningDate = new Date(payload.joiningDate);
      const today = new Date();
      today.setHours(23, 59, 59, 999);

      if (Number.isNaN(joiningDate.getTime())) {
        errors.joiningDate = 'Enter a valid joining date.';
      } else if (joiningDate > today) {
        errors.joiningDate = 'Employee joining date cannot be in the future.';
      }
    }
  }

  return errors;
}

function createValidationMiddleware(partial = false) {
  return function validateEmployeePayload(request, response, next) {
    const normalizedPayload = normalizePayload(request.body);
    const errors = collectErrors(normalizedPayload, partial);

    if (Object.keys(errors).length > 0) {
      return next(new ApiError(400, 'Employee validation failed.', errors));
    }

    request.validatedEmployee = normalizedPayload;
    return next();
  };
}

export const validateCreateEmployee = createValidationMiddleware(false);
export const validateUpdateEmployee = createValidationMiddleware(false);
export const validatePatchEmployee = createValidationMiddleware(true);
