# Final Working Local Kubernetes Guide

## 1. Install prerequisites

```bash
brew install kubectl
brew install minikube
```

Docker Desktop must be running.

## 2. Run the complete LOCAL environment

From anywhere:

```bash
/absolute/path/to/employee-fullstack-kubernetes-final-working/RUN_LOCAL_K8S.command
```

Or from the project root:

```bash
./RUN_LOCAL_K8S.command
```

This starts Minikube if needed, builds both Docker images, loads them into
Minikube, deploys PostgreSQL, Spring Boot, and Angular, and waits for readiness.

## 3. Expose the application

```bash
./scripts/k8s-port-forward.sh local
```

Open:

```text
Angular     http://localhost:4200
Spring Boot http://localhost:9000
Health      http://localhost:9000/actuator/health
```

Login:

```text
admin@example.com
Admin@123
```

## 4. Check status

```bash
./scripts/k8s-status.sh local
```

## 5. Logs

```bash
./scripts/k8s-logs.sh local backend
./scripts/k8s-logs.sh local postgres
./scripts/k8s-logs.sh local frontend
```

## Other environments

DEV:

```bash
./scripts/k8s-build-and-deploy.sh dev
./scripts/k8s-port-forward.sh dev
```

TEST:

```bash
./scripts/k8s-build-and-deploy.sh test
./scripts/k8s-port-forward.sh test
```

PROD-like local simulation:

```bash
./scripts/k8s-build-and-deploy.sh prod
./scripts/k8s-port-forward.sh prod
```

Ports:

```text
LOCAL  Angular 4200 / Backend 9000
DEV    Angular 4201 / Backend 9001
TEST   Angular 4202 / Backend 9002
PROD   Angular 4203 / Backend 9003
```

## Important networking rule

Inside Kubernetes:

```text
frontend -> backend:8080
backend  -> postgres:5432
```

Do not use host ports for pod-to-pod communication.
