# Kubernetes Local Multi-Environment Guide

This is the Kubernetes version of the same application:

```text
Browser
   |
   v
Angular + Nginx
   |
   | /api
   v
Spring Boot + Spring Security + JWT
   |
   v
PostgreSQL
```

The local Kubernetes target is **Minikube using the Docker driver**.

## Environment layout

All four environments can run on the same local Minikube cluster because
each uses its own Kubernetes namespace:

| Environment | Namespace | Spring profile | Frontend port-forward | Backend port-forward |
|---|---|---|---:|---:|
| local | employee-local | local | 4200 | 9000 |
| dev | employee-dev | dev | 4201 | 9001 |
| test | employee-test | test | 4202 | 9002 |
| prod-like | employee-prod | prod | 4203 | 9003 |

`prod` here means **production-like configuration on your laptop**.
It is not a production-grade Kubernetes platform.

## Project layout

```text
k8s/
├── base/
│   ├── kustomization.yaml
│   ├── postgres-pvc.yaml
│   ├── postgres-deployment.yaml
│   ├── postgres-service.yaml
│   ├── backend-deployment.yaml
│   ├── backend-service.yaml
│   ├── frontend-deployment.yaml
│   └── frontend-service.yaml
│
└── overlays/
    ├── local/
    │   ├── namespace.yaml
    │   └── kustomization.yaml
    ├── dev/
    │   ├── namespace.yaml
    │   └── kustomization.yaml
    ├── test/
    │   ├── namespace.yaml
    │   └── kustomization.yaml
    └── prod/
        ├── namespace.yaml
        ├── backend-resources.yaml
        └── kustomization.yaml
```

## Install prerequisites on macOS

```bash
brew install kubectl
brew install minikube
```

Docker Desktop should already be running.

Check:

```bash
docker version
kubectl version --client
minikube version
```

## 1. Start Minikube

```bash
./scripts/k8s-start-minikube.sh
```

Equivalent command:

```bash
minikube start --driver=docker --cpus=4 --memory=6144
```

## 2. Build and deploy LOCAL

```bash
./scripts/k8s-build-and-deploy.sh local
```

This:

1. builds `employee-backend:local`
2. builds `employee-frontend:local`
3. loads both images into Minikube
4. applies `k8s/overlays/local`
5. waits for all Deployments

## 3. Access LOCAL

Run:

```bash
./scripts/k8s-port-forward.sh local
```

Open:

```text
Angular:     http://localhost:4200
Spring Boot: http://localhost:9000
Health:      http://localhost:9000/actuator/health
```

Admin:

```text
admin@example.com
Admin@123
```

## Deploy DEV

```bash
./scripts/k8s-build-and-deploy.sh dev
./scripts/k8s-port-forward.sh dev
```

URLs:

```text
Frontend: http://localhost:4201
Backend:  http://localhost:9001
```

Admin password:

```text
DevAdmin@123
```

## Deploy TEST

```bash
./scripts/k8s-build-and-deploy.sh test
./scripts/k8s-port-forward.sh test
```

URLs:

```text
Frontend: http://localhost:4202
Backend:  http://localhost:9002
```

Admin password:

```text
TestAdmin@123
```

The Spring `test` profile uses `ddl-auto=create-drop`, so it is intentionally
ephemeral at the application-schema level.

## Deploy PROD-LIKE locally

```bash
./scripts/k8s-build-and-deploy.sh prod
./scripts/k8s-port-forward.sh prod
```

URLs:

```text
Frontend: http://localhost:4203
Backend:  http://localhost:9003
```

Admin password:

```text
ProdDemo@123
```

The prod-like overlay runs two backend replicas and two frontend replicas.

## Run all environments on the same Minikube cluster

```bash
./scripts/k8s-build-and-deploy.sh local
./scripts/k8s-build-and-deploy.sh dev
./scripts/k8s-build-and-deploy.sh test
./scripts/k8s-build-and-deploy.sh prod
```

Then:

```bash
kubectl get namespaces

kubectl get pods -n employee-local
kubectl get pods -n employee-dev
kubectl get pods -n employee-test
kubectl get pods -n employee-prod
```

Each environment has its own PostgreSQL Deployment and PVC, so data is isolated
by namespace.

## Useful commands

Render an overlay without deploying:

```bash
kubectl kustomize k8s/overlays/local
```

Deploy directly:

```bash
kubectl apply -k k8s/overlays/local
```

Check:

```bash
kubectl get all -n employee-local
kubectl get pvc -n employee-local
```

Backend logs:

```bash
kubectl logs -n employee-local deployment/backend -f
```

PostgreSQL logs:

```bash
kubectl logs -n employee-local deployment/postgres -f
```

Describe backend:

```bash
kubectl describe deployment backend -n employee-local
```

Shell into a backend pod:

```bash
kubectl exec -it   -n employee-local   deployment/backend   -- sh
```

Test internal service discovery:

```bash
kubectl exec -it   -n employee-local   deployment/backend   -- sh
```

Inside the container, PostgreSQL is addressed as:

```text
postgres:5432
```

This is the Kubernetes equivalent of the Docker Compose service-name approach.

## Remove one environment

```bash
./scripts/k8s-delete.sh local
```

or:

```bash
kubectl delete namespace employee-local
```

Deleting the namespace also removes its PVC and data.

## Stop Minikube

```bash
minikube stop
```

Delete the entire local cluster:

```bash
minikube delete
```

## Important Secrets note

The passwords and JWT keys included in these overlays are intentionally
**demo-only local values** so the project works immediately in a classroom or
local lab.

Do not commit real production credentials into Kubernetes YAML/Kustomize files.
For real deployments, create secrets through your secret-management process and
restrict access with Kubernetes RBAC.
