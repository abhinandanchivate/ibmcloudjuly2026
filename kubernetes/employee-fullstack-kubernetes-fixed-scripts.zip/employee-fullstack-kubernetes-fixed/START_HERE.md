# Start Here

This version fixes the old `./backend not found` problem.

All scripts calculate `PROJECT_ROOT` from the script file itself, so they can be run from any working directory.

## Run local Kubernetes

```bash
chmod +x RUN_LOCAL_K8S.command scripts/*.sh
./RUN_LOCAL_K8S.command
```

Then:

```bash
./scripts/k8s-port-forward.sh local
```

Open:

- Angular: http://localhost:4200
- Spring Boot: http://localhost:9000
- Health: http://localhost:9000/actuator/health

Login:

- admin@example.com
- Admin@123

You can also run the build script by absolute path from any directory:

```bash
/usr/bin/env bash "/path/to/project/scripts/k8s-build-and-deploy.sh" local
```
