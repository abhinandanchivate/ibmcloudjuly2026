#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
resolve_environment() {
  local env="${1:-local}"
  case "${env}" in
    local) NAMESPACE="employee-local"; FRONTEND_PORT=4200; BACKEND_PORT=9000 ;;
    dev)   NAMESPACE="employee-dev";   FRONTEND_PORT=4201; BACKEND_PORT=9001 ;;
    test)  NAMESPACE="employee-test";  FRONTEND_PORT=4202; BACKEND_PORT=9002 ;;
    prod)  NAMESPACE="employee-prod";  FRONTEND_PORT=4203; BACKEND_PORT=9003 ;;
    *) echo "ERROR: Environment must be local, dev, test, or prod"; exit 1 ;;
  esac
  ENVIRONMENT="${env}"
  OVERLAY_DIR="${PROJECT_ROOT}/k8s/overlays/${ENVIRONMENT}"
}
require_command() {
  command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' is not installed or not in PATH."; exit 1; }
}
ensure_minikube_running() {
  require_command docker; require_command kubectl; require_command minikube
  docker info >/dev/null 2>&1 || { echo "ERROR: Docker Desktop is not running."; exit 1; }
  if ! minikube status >/dev/null 2>&1; then
    echo "Minikube is not running. Starting it..."
    minikube start --driver=docker --cpus="${MINIKUBE_CPUS:-4}" --memory="${MINIKUBE_MEMORY:-6144}"
  fi
}
