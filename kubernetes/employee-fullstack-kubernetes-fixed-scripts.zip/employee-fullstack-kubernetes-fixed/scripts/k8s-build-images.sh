#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
resolve_environment "${1:-local}"
ensure_minikube_running

echo "Project root : ${PROJECT_ROOT}"
echo "Environment  : ${ENVIRONMENT}"
echo "Backend path : ${PROJECT_ROOT}/backend"
echo "Frontend path: ${PROJECT_ROOT}/frontend"

[[ -f "${PROJECT_ROOT}/backend/Dockerfile" ]] || { echo "ERROR: backend/Dockerfile not found"; exit 1; }
[[ -f "${PROJECT_ROOT}/frontend/Dockerfile" ]] || { echo "ERROR: frontend/Dockerfile not found"; exit 1; }

docker build -t "employee-backend:${ENVIRONMENT}" "${PROJECT_ROOT}/backend"
docker build -t "employee-frontend:${ENVIRONMENT}" "${PROJECT_ROOT}/frontend"

minikube image load "employee-backend:${ENVIRONMENT}"
minikube image load "employee-frontend:${ENVIRONMENT}"

echo "Images loaded successfully."
