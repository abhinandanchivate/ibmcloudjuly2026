#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
resolve_environment "${1:-local}"
kubectl delete namespace "${NAMESPACE}" --ignore-not-found=true
