#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
resolve_environment "${1:-local}"
ensure_minikube_running

[[ -f "${OVERLAY_DIR}/kustomization.yaml" ]] || { echo "ERROR: ${OVERLAY_DIR}/kustomization.yaml not found"; exit 1; }

echo "Deploying ${ENVIRONMENT}"
echo "Namespace: ${NAMESPACE}"
echo "Overlay  : ${OVERLAY_DIR}"

kubectl kustomize "${OVERLAY_DIR}" >/dev/null
kubectl apply -k "${OVERLAY_DIR}"
kubectl rollout status deployment/postgres -n "${NAMESPACE}" --timeout=240s
kubectl rollout status deployment/backend -n "${NAMESPACE}" --timeout=300s
kubectl rollout status deployment/frontend -n "${NAMESPACE}" --timeout=240s
kubectl get pods -n "${NAMESPACE}" -o wide
kubectl get svc -n "${NAMESPACE}"
kubectl get pvc -n "${NAMESPACE}"
