#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
resolve_environment "${1:-local}"

COMPONENT="${2:-backend}"

case "${COMPONENT}" in
  backend|frontend|postgres) ;;
  *)
    echo "Usage: $0 {local|dev|test|prod} {backend|frontend|postgres}"
    exit 1
    ;;
esac

kubectl logs \
  -n "${NAMESPACE}" \
  deployment/"${COMPONENT}" \
  --tail=200 \
  -f
