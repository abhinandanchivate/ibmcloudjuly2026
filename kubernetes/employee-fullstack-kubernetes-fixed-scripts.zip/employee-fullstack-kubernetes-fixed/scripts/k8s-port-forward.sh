#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
resolve_environment "${1:-local}"
require_command kubectl

echo "Frontend: http://localhost:${FRONTEND_PORT}"
echo "Backend : http://localhost:${BACKEND_PORT}"
echo "Health  : http://localhost:${BACKEND_PORT}/actuator/health"
echo "Press Ctrl+C to stop."

kubectl port-forward -n "${NAMESPACE}" service/frontend "${FRONTEND_PORT}:80" & FPID=$!
kubectl port-forward -n "${NAMESPACE}" service/backend "${BACKEND_PORT}:8080" & BPID=$!
cleanup(){ kill "${FPID}" "${BPID}" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
wait
