#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"${SCRIPT_DIR}/k8s-start-minikube.sh"
"${SCRIPT_DIR}/k8s-build-and-deploy.sh" local

echo
echo "LOCAL deployment complete."
echo "Next run: ${SCRIPT_DIR}/k8s-port-forward.sh local"
echo "Angular: http://localhost:4200"
echo "Backend: http://localhost:9000"
echo "Health : http://localhost:9000/actuator/health"
