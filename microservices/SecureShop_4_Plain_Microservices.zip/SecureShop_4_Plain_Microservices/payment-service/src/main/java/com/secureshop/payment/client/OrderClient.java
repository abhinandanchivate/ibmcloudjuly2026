package com.secureshop.payment.client;
import com.secureshop.payment.exception.UpstreamServiceException; import org.springframework.beans.factory.annotation.Value; import org.springframework.http.HttpStatusCode; import org.springframework.stereotype.Component; import org.springframework.web.client.*; import java.math.BigDecimal; import java.util.*;
@Component public class OrderClient{
 private final RestClient client; public OrderClient(RestClient.Builder b,@Value("${services.order.base-url}")String url){client=b.baseUrl(url).build();}
 public OrderPaymentContext context(UUID id){try{return Objects.requireNonNull(client.get().uri("/internal/v1/orders/{id}/payment-context",id).retrieve().onStatus(HttpStatusCode::isError,(req,res)->{throw new UpstreamServiceException("Order Service rejected payment context with status "+res.getStatusCode(),null);}).body(OrderPaymentContext.class));}catch(RestClientException e){throw new UpstreamServiceException("Order Service is unavailable.",e);}}
 public void success(UUID id,String paymentId,String ref){post(id,"payment-success",new PaymentOutcomeRequest(paymentId,ref));}
 public void failed(UUID id,String paymentId,String ref){post(id,"payment-failed",new PaymentOutcomeRequest(paymentId,ref));}
 public void refund(UUID id,String refundId,BigDecimal amount,String ref){post(id,"refund-completed",new RefundOutcomeRequest(refundId,amount,ref));}
 private void post(UUID id,String action,Object body){try{client.post().uri("/internal/v1/orders/{id}/"+action,id).body(body).retrieve().onStatus(HttpStatusCode::isError,(req,res)->{throw new UpstreamServiceException("Order Service request failed with status "+res.getStatusCode(),null);}).toBodilessEntity();}catch(RestClientException e){throw new UpstreamServiceException("Order Service is unavailable.",e);}}
}
