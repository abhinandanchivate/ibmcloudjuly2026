# SecureShop — Four Plain Independent Microservices

This bundle contains exactly four independent Spring Boot projects:

1. `identity-service`
2. `catalog-service`
3. `order-service`
4. `payment-service`

Each folder is imported and built separately. There is no root Maven project and no shared source module.

## Intentionally excluded

- Spring Security and JWT
- Eureka Client or any service registry
- Config Client or Config Server integration
- API Gateway integration
- Spring Cloud dependencies

## Included

- Spring Boot REST APIs
- Bean Validation
- Spring Data JPA
- PostgreSQL
- Manual DTO/entity mappers
- Global exception handling
- Correlation IDs
- Pagination
- Optimistic locking
- Direct service-to-service HTTP calls using configurable URLs

## Default ports

| Service | Port | PostgreSQL host port |
|---|---:|---:|
| Identity | 8081 | 5433 |
| Catalog | 8082 | 5434 |
| Order | 8083 | 5435 |
| Payment | 8084 | 5436 |

Start each service's PostgreSQL container with `docker compose up -d`, then run `mvn spring-boot:run` inside that service folder.
