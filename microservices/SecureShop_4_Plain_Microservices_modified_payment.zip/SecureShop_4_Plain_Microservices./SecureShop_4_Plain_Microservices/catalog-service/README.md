# Catalog Service

Product CRUD plus inventory validation, reservation, and release. No Spring Cloud or Spring Security dependencies.

Main endpoints: `/api/v1/products/**` and `/internal/v1/catalog/**`.
