package com.secureshop.catalog.api;

public record FieldViolation(String field, String message, Object rejectedValue) {
}
