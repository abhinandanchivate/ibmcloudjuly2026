package com.secureshop.catalog.api;
import jakarta.validation.constraints.NotNull;
public record InventoryAdjustmentRequest(@NotNull Integer change, String reason){}
