package com.secureshop.catalog.api;
import jakarta.validation.Valid; import jakarta.validation.constraints.*; import java.util.List; import java.util.UUID;
public record InventoryCommandRequest(@NotNull UUID orderId,@NotEmpty List<@Valid OrderItemRequest> items){}
