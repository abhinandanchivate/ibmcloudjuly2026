package com.secureshop.catalog.api;
import java.util.UUID;
public record InventoryResultResponse(UUID orderId,String result){}
