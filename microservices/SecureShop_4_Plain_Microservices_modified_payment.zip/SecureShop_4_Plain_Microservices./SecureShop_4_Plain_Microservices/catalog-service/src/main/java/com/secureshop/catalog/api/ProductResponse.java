package com.secureshop.catalog.api;
import com.secureshop.catalog.domain.ProductStatus; import java.math.BigDecimal; import java.time.Instant; import java.util.UUID;
public record ProductResponse(UUID id,String sku,String name,String description,BigDecimal price,String currency,
 int availableQuantity,int reservedQuantity,int sellableQuantity,ProductStatus status,Instant createdAt,Instant updatedAt,long version){}
