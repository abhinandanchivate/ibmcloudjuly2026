package com.secureshop.catalog.api;
import jakarta.validation.constraints.*; import java.math.BigDecimal;
public record ProductUpdateRequest(@NotBlank @Size(max=180) String name,@Size(max=2000) String description,
 @NotNull @DecimalMin("0.01") BigDecimal price,@NotBlank @Pattern(regexp="^[A-Z]{3}$") String currency){}
