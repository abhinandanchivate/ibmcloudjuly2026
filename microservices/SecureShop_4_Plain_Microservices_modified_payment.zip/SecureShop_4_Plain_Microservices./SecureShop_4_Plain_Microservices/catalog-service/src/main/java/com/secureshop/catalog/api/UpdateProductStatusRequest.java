package com.secureshop.catalog.api;
import com.secureshop.catalog.domain.ProductStatus; import jakarta.validation.constraints.NotNull;
public record UpdateProductStatusRequest(@NotNull ProductStatus status){}
