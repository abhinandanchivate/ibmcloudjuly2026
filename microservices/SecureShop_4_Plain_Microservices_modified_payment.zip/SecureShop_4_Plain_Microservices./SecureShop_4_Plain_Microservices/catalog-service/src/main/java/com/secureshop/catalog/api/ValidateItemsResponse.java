package com.secureshop.catalog.api;
import java.util.List;
public record ValidateItemsResponse(List<ValidatedItemResponse> items){}
