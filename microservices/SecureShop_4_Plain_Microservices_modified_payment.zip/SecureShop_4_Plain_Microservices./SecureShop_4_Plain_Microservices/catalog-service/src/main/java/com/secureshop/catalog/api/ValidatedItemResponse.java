package com.secureshop.catalog.api;
import java.math.BigDecimal; import java.util.UUID;
public record ValidatedItemResponse(UUID productId,String sku,String name,BigDecimal unitPrice,String currency,int quantity){}
