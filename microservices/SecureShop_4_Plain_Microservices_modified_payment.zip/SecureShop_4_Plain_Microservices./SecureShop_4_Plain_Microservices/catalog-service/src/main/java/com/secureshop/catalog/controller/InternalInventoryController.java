package com.secureshop.catalog.controller;
import com.secureshop.catalog.api.*; import com.secureshop.catalog.service.CatalogService; import jakarta.validation.Valid; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/internal/v1/catalog") public class InternalInventoryController{
 private final CatalogService service; public InternalInventoryController(CatalogService s){service=s;}
 @PostMapping("/items/validate") public ValidateItemsResponse validate(@Valid @RequestBody InventoryCommandRequest r){return service.validate(r.items());}
 @PostMapping("/inventory/reserve") public InventoryResultResponse reserve(@Valid @RequestBody InventoryCommandRequest r){return service.reserve(r);}
 @PostMapping("/inventory/release") public InventoryResultResponse release(@Valid @RequestBody InventoryCommandRequest r){return service.release(r);}
}
