package com.secureshop.catalog.controller;
import com.secureshop.catalog.api.*; import com.secureshop.catalog.domain.ProductStatus; import com.secureshop.catalog.service.CatalogService; import jakarta.validation.Valid;
import org.springframework.data.domain.*; import org.springframework.data.web.PageableDefault; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.UUID;
@RestController @RequestMapping("/api/v1/products") public class ProductController{
 private final CatalogService service; public ProductController(CatalogService s){service=s;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public ProductResponse create(@Valid @RequestBody ProductCreateRequest r){return service.create(r);}
 @GetMapping public PageResponse<ProductResponse> list(@RequestParam(required=false)String query,@RequestParam(required=false)ProductStatus status,@PageableDefault(size=20,sort="createdAt",direction=Sort.Direction.DESC)Pageable page){return service.list(query,status,page);}
 @GetMapping("/{id}") public ProductResponse get(@PathVariable UUID id){return service.get(id);}
 @PutMapping("/{id}") public ProductResponse update(@PathVariable UUID id,@Valid @RequestBody ProductUpdateRequest r){return service.update(id,r);}
 @PatchMapping("/{id}/status") public ProductResponse status(@PathVariable UUID id,@Valid @RequestBody UpdateProductStatusRequest r){return service.status(id,r);}
 @PatchMapping("/{id}/inventory") public ProductResponse inventory(@PathVariable UUID id,@Valid @RequestBody InventoryAdjustmentRequest r){return service.adjust(id,r);}
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable UUID id){service.delete(id);}
}
