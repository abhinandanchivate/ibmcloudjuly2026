package com.secureshop.catalog.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name="inventory_reservations", uniqueConstraints=@UniqueConstraint(name="uk_reservation_order_product", columnNames={"order_id","product_id"}))
public class InventoryReservation {
    @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
    @Column(name="order_id", nullable=false) private UUID orderId;
    @Column(name="product_id", nullable=false) private UUID productId;
    @Column(nullable=false) private int quantity;
    @Enumerated(EnumType.STRING) @Column(nullable=false,length=20) private ReservationStatus status;
    @Column(nullable=false,updatable=false) private Instant createdAt;
    @Column(nullable=false) private Instant updatedAt;
    @PrePersist void prePersist(){Instant now=Instant.now();createdAt=now;updatedAt=now;}
    @PreUpdate void preUpdate(){updatedAt=Instant.now();}
    public UUID getId(){return id;} public UUID getOrderId(){return orderId;} public void setOrderId(UUID v){orderId=v;}
    public UUID getProductId(){return productId;} public void setProductId(UUID v){productId=v;}
    public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
    public ReservationStatus getStatus(){return status;} public void setStatus(ReservationStatus v){status=v;}
}
