package com.secureshop.catalog.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "products", uniqueConstraints = @UniqueConstraint(name = "uk_product_sku", columnNames = "sku"))
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(nullable = false, length = 60) private String sku;
    @Column(nullable = false, length = 180) private String name;
    @Column(length = 2000) private String description;
    @Column(nullable = false, precision = 14, scale = 2) private BigDecimal price;
    @Column(nullable = false, length = 3) private String currency;
    @Column(nullable = false) private int availableQuantity;
    @Column(nullable = false) private int reservedQuantity;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private ProductStatus status = ProductStatus.ACTIVE;
    @Column(nullable = false) private boolean deleted;
    @Column(nullable = false, updatable = false) private Instant createdAt;
    @Column(nullable = false) private Instant updatedAt;
    @Version private long version;

    @PrePersist void prePersist(){Instant now=Instant.now();createdAt=now;updatedAt=now;}
    @PreUpdate void preUpdate(){updatedAt=Instant.now();}

    public UUID getId(){return id;} public String getSku(){return sku;} public void setSku(String sku){this.sku=sku;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
    public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal price){this.price=price;}
    public String getCurrency(){return currency;} public void setCurrency(String currency){this.currency=currency;}
    public int getAvailableQuantity(){return availableQuantity;} public void setAvailableQuantity(int q){this.availableQuantity=q;}
    public int getReservedQuantity(){return reservedQuantity;} public void setReservedQuantity(int q){this.reservedQuantity=q;}
    public ProductStatus getStatus(){return status;} public void setStatus(ProductStatus status){this.status=status;}
    public boolean isDeleted(){return deleted;} public void setDeleted(boolean deleted){this.deleted=deleted;}
    public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public long getVersion(){return version;}
}
