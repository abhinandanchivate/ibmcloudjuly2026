package com.secureshop.catalog.domain;
public enum ProductStatus { ACTIVE, INACTIVE }
