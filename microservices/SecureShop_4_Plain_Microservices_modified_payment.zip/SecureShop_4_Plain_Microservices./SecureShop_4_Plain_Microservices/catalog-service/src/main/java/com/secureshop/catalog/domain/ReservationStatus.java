package com.secureshop.catalog.domain;
public enum ReservationStatus { RESERVED, RELEASED }
