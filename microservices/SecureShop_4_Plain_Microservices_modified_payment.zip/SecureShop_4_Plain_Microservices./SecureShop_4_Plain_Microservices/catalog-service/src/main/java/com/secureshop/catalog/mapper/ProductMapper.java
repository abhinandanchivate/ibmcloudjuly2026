package com.secureshop.catalog.mapper;
import com.secureshop.catalog.api.*; import com.secureshop.catalog.domain.Product; import org.springframework.stereotype.Component;
@Component public class ProductMapper{
 public Product toEntity(ProductCreateRequest r){Product p=new Product();p.setSku(r.sku().trim().toUpperCase());p.setName(r.name().trim());p.setDescription(r.description());p.setPrice(r.price());p.setCurrency(r.currency());p.setAvailableQuantity(r.availableQuantity());return p;}
 public void update(Product p,ProductUpdateRequest r){p.setName(r.name().trim());p.setDescription(r.description());p.setPrice(r.price());p.setCurrency(r.currency());}
 public ProductResponse toResponse(Product p){return new ProductResponse(p.getId(),p.getSku(),p.getName(),p.getDescription(),p.getPrice(),p.getCurrency(),p.getAvailableQuantity(),p.getReservedQuantity(),p.getAvailableQuantity()-p.getReservedQuantity(),p.getStatus(),p.getCreatedAt(),p.getUpdatedAt(),p.getVersion());}
}
