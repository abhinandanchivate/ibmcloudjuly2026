package com.secureshop.catalog.repository;
import com.secureshop.catalog.domain.InventoryReservation; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface InventoryReservationRepository extends JpaRepository<InventoryReservation,UUID>{
 List<InventoryReservation> findByOrderId(UUID orderId);
 Optional<InventoryReservation> findByOrderIdAndProductId(UUID orderId,UUID productId);
}
