package com.secureshop.catalog.repository;
import com.secureshop.catalog.domain.*; import jakarta.persistence.LockModeType; import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*; import org.springframework.data.repository.query.Param; import java.util.*;
public interface ProductRepository extends JpaRepository<Product,UUID>{
 boolean existsBySkuIgnoreCaseAndDeletedFalse(String sku);
 Optional<Product> findByIdAndDeletedFalse(UUID id);
 @Query("select p from Product p where p.deleted=false and (:status is null or p.status=:status) and (:q is null or lower(p.sku) like lower(concat('%',:q,'%')) or lower(p.name) like lower(concat('%',:q,'%')))")
 Page<Product> search(@Param("q") String q,@Param("status") ProductStatus status,Pageable pageable);
 @Lock(LockModeType.PESSIMISTIC_WRITE)
 @Query("select p from Product p where p.id in :ids and p.deleted=false")
 List<Product> findAllForUpdate(@Param("ids") Collection<UUID> ids);
}
