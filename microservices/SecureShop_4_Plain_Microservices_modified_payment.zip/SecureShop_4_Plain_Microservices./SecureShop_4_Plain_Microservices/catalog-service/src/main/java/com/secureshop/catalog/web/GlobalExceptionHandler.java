package com.secureshop.catalog.web;

import com.secureshop.catalog.api.ApiError;
import com.secureshop.catalog.api.FieldViolation;
import com.secureshop.catalog.exception.BusinessException;
import com.secureshop.catalog.exception.ResourceNotFoundException;
import com.secureshop.catalog.exception.UpstreamServiceException;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.List;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    ResponseEntity<ApiError> handleNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        return response(HttpStatus.NOT_FOUND, ex.getCode(), ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(BusinessException.class)
    ResponseEntity<ApiError> handleBusiness(BusinessException ex, HttpServletRequest request) {
        return response(ex.getStatus(), ex.getCode(), ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest request) {
        List<FieldViolation> errors = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> new FieldViolation(error.getField(), error.getDefaultMessage(), error.getRejectedValue()))
                .toList();
        return response(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED",
                "Request validation failed.", request, errors);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ApiError> handleUnreadable(HttpMessageNotReadableException ex, HttpServletRequest request) {
        return response(HttpStatus.BAD_REQUEST, "MALFORMED_REQUEST",
                "Request body is missing or malformed.", request, List.of());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<ApiError> handleIntegrity(DataIntegrityViolationException ex, HttpServletRequest request) {
        return response(HttpStatus.CONFLICT, "DATA_INTEGRITY_VIOLATION",
                "The requested operation conflicts with existing data.", request, List.of());
    }

    @ExceptionHandler(UpstreamServiceException.class)
    ResponseEntity<ApiError> handleUpstream(UpstreamServiceException ex, HttpServletRequest request) {
        return response(HttpStatus.SERVICE_UNAVAILABLE, "UPSTREAM_SERVICE_UNAVAILABLE",
                ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiError> handleUnexpected(Exception ex, HttpServletRequest request) {
        return response(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_SERVER_ERROR",
                "An unexpected error occurred.", request, List.of());
    }

    private ResponseEntity<ApiError> response(HttpStatus status, String code, String message,
                                               HttpServletRequest request, List<FieldViolation> fields) {
        ApiError body = new ApiError(Instant.now(), status.value(), status.getReasonPhrase(), code,
                message, request.getRequestURI(), MDC.get("correlationId"), fields);
        return ResponseEntity.status(status).body(body);
    }
}
