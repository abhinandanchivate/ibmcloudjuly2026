# Identity Service

Independent profile/account-management microservice. It does not authenticate users and contains no Spring Security dependency.

## Endpoints

- `POST /api/v1/users`
- `GET /api/v1/users`
- `GET /api/v1/users/{id}`
- `PUT /api/v1/users/{id}`
- `PATCH /api/v1/users/{id}/status`
- `DELETE /api/v1/users/{id}`

Run PostgreSQL with `docker compose up -d`, then start with `mvn spring-boot:run`.
