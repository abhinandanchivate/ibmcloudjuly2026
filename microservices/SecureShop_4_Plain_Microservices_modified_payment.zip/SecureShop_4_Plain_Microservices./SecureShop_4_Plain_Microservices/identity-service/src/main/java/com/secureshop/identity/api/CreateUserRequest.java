package com.secureshop.identity.api;

import jakarta.validation.constraints.*;

public record CreateUserRequest(
        @NotBlank @Email @Size(max = 180) String email,
        @NotBlank @Size(max = 80) String firstName,
        @NotBlank @Size(max = 80) String lastName,
        @Pattern(regexp = "^$|^[0-9+() -]{7,25}$", message = "phone format is invalid") String phone) {
}
