package com.secureshop.identity.api;

public record FieldViolation(String field, String message, Object rejectedValue) {
}
