package com.secureshop.identity.api;

import com.secureshop.identity.domain.AccountStatus;
import java.time.Instant;
import java.util.UUID;

public record UserResponse(UUID id, String email, String firstName, String lastName, String phone,
                           AccountStatus status, Instant createdAt, Instant updatedAt, long version) {
}
