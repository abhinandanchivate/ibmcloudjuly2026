package com.secureshop.identity.domain;

public enum AccountStatus {
    ACTIVE, INACTIVE, SUSPENDED
}
