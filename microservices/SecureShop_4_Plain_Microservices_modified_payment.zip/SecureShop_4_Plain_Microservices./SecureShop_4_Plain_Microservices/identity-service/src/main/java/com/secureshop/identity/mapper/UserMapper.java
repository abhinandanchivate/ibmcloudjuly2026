package com.secureshop.identity.mapper;

import com.secureshop.identity.api.*;
import com.secureshop.identity.domain.UserAccount;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {
    public UserAccount toEntity(CreateUserRequest request) {
        UserAccount user = new UserAccount();
        apply(user, request.email(), request.firstName(), request.lastName(), request.phone());
        return user;
    }

    public void update(UserAccount user, UpdateUserRequest request) {
        apply(user, request.email(), request.firstName(), request.lastName(), request.phone());
    }

    private void apply(UserAccount user, String email, String firstName, String lastName, String phone) {
        user.setEmail(email.trim().toLowerCase());
        user.setFirstName(firstName.trim());
        user.setLastName(lastName.trim());
        user.setPhone(phone == null || phone.isBlank() ? null : phone.trim());
    }

    public UserResponse toResponse(UserAccount user) {
        return new UserResponse(user.getId(), user.getEmail(), user.getFirstName(), user.getLastName(),
                user.getPhone(), user.getStatus(), user.getCreatedAt(), user.getUpdatedAt(), user.getVersion());
    }
}
