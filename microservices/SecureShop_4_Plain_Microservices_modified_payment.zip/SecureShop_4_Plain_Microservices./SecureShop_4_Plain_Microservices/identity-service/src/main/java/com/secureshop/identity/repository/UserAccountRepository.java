package com.secureshop.identity.repository;

import com.secureshop.identity.domain.AccountStatus;
import com.secureshop.identity.domain.UserAccount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;
import java.util.UUID;

public interface UserAccountRepository extends JpaRepository<UserAccount, UUID> {
    boolean existsByEmailIgnoreCaseAndDeletedFalse(String email);
    boolean existsByEmailIgnoreCaseAndIdNotAndDeletedFalse(String email, UUID id);
    Optional<UserAccount> findByIdAndDeletedFalse(UUID id);

    @Query("""
            select u from UserAccount u
            where u.deleted = false
              and (:status is null or u.status = :status)
              and (:query is null or lower(u.email) like lower(concat('%', :query, '%'))
                   or lower(u.firstName) like lower(concat('%', :query, '%'))
                   or lower(u.lastName) like lower(concat('%', :query, '%')))
            """)
    Page<UserAccount> search(@Param("query") String query, @Param("status") AccountStatus status, Pageable pageable);
}
