package com.secureshop.identity.service;

import com.secureshop.identity.api.*;
import com.secureshop.identity.domain.AccountStatus;
import com.secureshop.identity.domain.UserAccount;
import com.secureshop.identity.exception.BusinessException;
import com.secureshop.identity.exception.ResourceNotFoundException;
import com.secureshop.identity.mapper.UserMapper;
import com.secureshop.identity.repository.UserAccountRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Locale;
import java.util.UUID;

@Service
public class UserService {
    private final UserAccountRepository repository;
    private final UserMapper mapper;

    public UserService(UserAccountRepository repository, UserMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Transactional
    public UserResponse create(CreateUserRequest request) {
        String email = normalize(request.email());
        if (repository.existsByEmailIgnoreCaseAndDeletedFalse(email)) {
            throw new BusinessException(HttpStatus.CONFLICT, "EMAIL_ALREADY_EXISTS", "Email is already registered.");
        }
        UserAccount user = mapper.toEntity(request);
        return mapper.toResponse(repository.save(user));
    }

    @Transactional(readOnly = true)
    public UserResponse get(UUID id) {
        return mapper.toResponse(find(id));
    }

    @Transactional(readOnly = true)
    public PageResponse<UserResponse> list(String query, AccountStatus status, Pageable pageable) {
        String normalized = query == null || query.isBlank() ? null : query.trim();
        return PageResponse.from(repository.search(normalized, status, pageable).map(mapper::toResponse));
    }

    @Transactional
    public UserResponse update(UUID id, UpdateUserRequest request) {
        UserAccount user = find(id);
        String email = normalize(request.email());
        if (repository.existsByEmailIgnoreCaseAndIdNotAndDeletedFalse(email, id)) {
            throw new BusinessException(HttpStatus.CONFLICT, "EMAIL_ALREADY_EXISTS", "Email is already registered.");
        }
        mapper.update(user, request);
        return mapper.toResponse(user);
    }

    @Transactional
    public UserResponse updateStatus(UUID id, UpdateAccountStatusRequest request) {
        UserAccount user = find(id);
        user.setStatus(request.status());
        return mapper.toResponse(user);
    }

    @Transactional
    public void delete(UUID id) {
        UserAccount user = find(id);
        user.setDeleted(true);
        user.setStatus(AccountStatus.INACTIVE);
    }

    private UserAccount find(UUID id) {
        return repository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "User does not exist."));
    }

    private String normalize(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }
}
