# Order Service

Order lifecycle microservice. It calls Catalog Service directly through `services.catalog.base-url`; no Eureka, Config Client, API Gateway, or Spring Security is used.
