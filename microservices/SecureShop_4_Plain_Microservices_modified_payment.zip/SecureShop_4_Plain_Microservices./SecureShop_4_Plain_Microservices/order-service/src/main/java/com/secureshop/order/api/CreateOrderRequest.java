package com.secureshop.order.api; import jakarta.validation.Valid; import jakarta.validation.constraints.*; import java.util.*;
public record CreateOrderRequest(@NotNull UUID customerId,@NotBlank @Size(max=500) String shippingAddress,@NotEmpty List<@Valid OrderItemRequest> items){}
