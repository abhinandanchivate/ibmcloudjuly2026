package com.secureshop.order.api;

public record FieldViolation(String field, String message, Object rejectedValue) {
}
