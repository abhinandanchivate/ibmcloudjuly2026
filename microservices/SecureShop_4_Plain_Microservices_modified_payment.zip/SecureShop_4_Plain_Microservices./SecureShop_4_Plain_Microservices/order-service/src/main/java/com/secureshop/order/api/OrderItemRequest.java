package com.secureshop.order.api; import jakarta.validation.constraints.*; import java.util.UUID;
public record OrderItemRequest(@NotNull UUID productId,@Min(1) int quantity){}
