package com.secureshop.order.api; import java.math.BigDecimal; import java.util.UUID;
public record OrderItemResponse(UUID productId,String sku,String productName,BigDecimal unitPrice,int quantity,BigDecimal subtotal){}
