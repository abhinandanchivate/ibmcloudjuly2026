package com.secureshop.order.api; import java.math.BigDecimal; import java.util.UUID;
public record OrderPaymentContext(UUID orderId,UUID customerId,BigDecimal payableAmount,String currency,boolean paymentEligible){}
