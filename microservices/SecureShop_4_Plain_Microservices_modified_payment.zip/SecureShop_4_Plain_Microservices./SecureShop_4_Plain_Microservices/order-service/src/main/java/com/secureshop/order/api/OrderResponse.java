package com.secureshop.order.api; import com.secureshop.order.domain.OrderStatus; import java.math.BigDecimal; import java.time.Instant; import java.util.*;
public record OrderResponse(UUID id,UUID customerId,OrderStatus status,BigDecimal totalAmount,String currency,String shippingAddress,List<OrderItemResponse> items,Instant createdAt,Instant updatedAt,long version){}
