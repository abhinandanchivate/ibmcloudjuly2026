package com.secureshop.order.api; import jakarta.validation.constraints.NotBlank;
public record PaymentOutcomeRequest(@NotBlank String paymentId,String providerReference){}
