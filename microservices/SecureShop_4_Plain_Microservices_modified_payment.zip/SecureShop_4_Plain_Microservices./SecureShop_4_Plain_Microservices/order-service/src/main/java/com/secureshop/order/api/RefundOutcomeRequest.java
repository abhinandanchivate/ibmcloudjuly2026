package com.secureshop.order.api; import jakarta.validation.constraints.*; import java.math.BigDecimal;
public record RefundOutcomeRequest(@NotBlank String refundId,@NotNull @DecimalMin("0.01") BigDecimal amount,String providerReference){}
