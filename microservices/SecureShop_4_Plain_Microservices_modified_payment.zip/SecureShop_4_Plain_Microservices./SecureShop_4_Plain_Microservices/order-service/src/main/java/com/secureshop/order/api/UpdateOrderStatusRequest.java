package com.secureshop.order.api; import com.secureshop.order.domain.OrderStatus; import jakarta.validation.constraints.NotNull;
public record UpdateOrderStatusRequest(@NotNull OrderStatus status){}
