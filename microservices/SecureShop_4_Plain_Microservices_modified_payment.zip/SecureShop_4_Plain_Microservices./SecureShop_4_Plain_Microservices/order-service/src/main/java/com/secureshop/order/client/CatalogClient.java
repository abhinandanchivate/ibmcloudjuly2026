package com.secureshop.order.client;
import com.secureshop.order.api.OrderItemRequest; import com.secureshop.order.exception.*; import org.springframework.beans.factory.annotation.Value; import org.springframework.http.HttpStatusCode; import org.springframework.stereotype.Component; import org.springframework.web.client.*; import java.util.*;
@Component public class CatalogClient{
 private final RestClient client;
 public CatalogClient(RestClient.Builder builder,@Value("${services.catalog.base-url}")String url){client=builder.baseUrl(url).build();}
 public List<ValidatedCatalogItem> validate(UUID orderId,List<OrderItemRequest> items){CatalogCommandRequest r=request(orderId,items);try{return Objects.requireNonNull(client.post().uri("/internal/v1/catalog/items/validate").body(r).retrieve().onStatus(HttpStatusCode::isError,(req,res)->{throw new UpstreamServiceException("Catalog Service rejected item validation with status "+res.getStatusCode(),null);}).body(ValidateCatalogResponse.class)).items();}catch(RestClientException e){throw new UpstreamServiceException("Catalog Service is unavailable.",e);}}
 public void reserve(UUID orderId,List<OrderItemRequest> items){post("/internal/v1/catalog/inventory/reserve",request(orderId,items));}
 public void release(UUID orderId,List<OrderItemRequest> items){post("/internal/v1/catalog/inventory/release",request(orderId,items));}
 private void post(String path,CatalogCommandRequest r){try{client.post().uri(path).body(r).retrieve().onStatus(HttpStatusCode::isError,(req,res)->{throw new UpstreamServiceException("Catalog Service request failed with status "+res.getStatusCode(),null);}).toBodilessEntity();}catch(RestClientException e){throw new UpstreamServiceException("Catalog Service is unavailable.",e);}}
 private CatalogCommandRequest request(UUID id,List<OrderItemRequest> items){return new CatalogCommandRequest(id,items.stream().map(i->new CatalogItemRequest(i.productId(),i.quantity())).toList());}
}
