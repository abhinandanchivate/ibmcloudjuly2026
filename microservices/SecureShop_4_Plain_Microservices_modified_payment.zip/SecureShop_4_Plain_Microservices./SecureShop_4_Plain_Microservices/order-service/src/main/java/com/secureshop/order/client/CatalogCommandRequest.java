package com.secureshop.order.client;

import java.util.List;
import java.util.UUID;

public record CatalogCommandRequest(UUID orderId, List<CatalogItemRequest> items) {
}
