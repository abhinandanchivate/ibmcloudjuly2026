package com.secureshop.order.client;

import java.util.UUID;

public record CatalogItemRequest(UUID productId, int quantity) {
}
