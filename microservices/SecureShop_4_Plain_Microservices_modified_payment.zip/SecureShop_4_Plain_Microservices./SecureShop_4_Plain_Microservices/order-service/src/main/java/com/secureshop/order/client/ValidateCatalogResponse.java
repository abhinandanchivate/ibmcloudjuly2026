package com.secureshop.order.client;

import java.util.List;

public record ValidateCatalogResponse(List<ValidatedCatalogItem> items) {
}
