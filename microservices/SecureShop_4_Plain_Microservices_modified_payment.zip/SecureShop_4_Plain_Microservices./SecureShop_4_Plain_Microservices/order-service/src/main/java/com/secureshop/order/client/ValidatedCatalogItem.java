package com.secureshop.order.client;

import java.math.BigDecimal;
import java.util.UUID;

public record ValidatedCatalogItem(UUID productId, String sku, String name,
                                   BigDecimal unitPrice, String currency, int quantity) {
}
