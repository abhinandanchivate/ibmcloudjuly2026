package com.secureshop.order.controller; import com.secureshop.order.api.*; import com.secureshop.order.service.OrderService; import jakarta.validation.Valid; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.UUID;
@RestController @RequestMapping("/internal/v1/orders") public class InternalOrderController{private final OrderService service;public InternalOrderController(OrderService s){service=s;}
 @GetMapping("/{id}/payment-context") public OrderPaymentContext context(@PathVariable UUID id){return service.context(id);}
 @PostMapping("/{id}/payment-success") @ResponseStatus(HttpStatus.NO_CONTENT) public void success(@PathVariable UUID id,@Valid @RequestBody PaymentOutcomeRequest r){service.paymentSuccess(id,r);}
 @PostMapping("/{id}/payment-failed") @ResponseStatus(HttpStatus.NO_CONTENT) public void failed(@PathVariable UUID id,@Valid @RequestBody PaymentOutcomeRequest r){service.paymentFailed(id,r);}
 @PostMapping("/{id}/refund-completed") @ResponseStatus(HttpStatus.NO_CONTENT) public void refund(@PathVariable UUID id,@Valid @RequestBody RefundOutcomeRequest r){service.refunded(id,r);}}
