package com.secureshop.order.controller; import com.secureshop.order.api.*; import com.secureshop.order.service.OrderService; import jakarta.validation.Valid; import org.springframework.data.domain.*; import org.springframework.data.web.PageableDefault; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.UUID;
@RestController @RequestMapping("/api/v1/orders") public class OrderController{private final OrderService service;public OrderController(OrderService s){service=s;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public OrderResponse create(@Valid @RequestBody CreateOrderRequest r){return service.create(r);}
 @GetMapping public PageResponse<OrderResponse> list(@RequestParam(required=false)UUID customerId,@PageableDefault(size=20,sort="createdAt",direction=Sort.Direction.DESC)Pageable p){return service.list(customerId,p);}
 @GetMapping("/{id}") public OrderResponse get(@PathVariable UUID id){return service.get(id);}
 @PatchMapping("/{id}/cancel") public OrderResponse cancel(@PathVariable UUID id){return service.cancel(id);}
 @PatchMapping("/{id}/status") public OrderResponse status(@PathVariable UUID id,@Valid @RequestBody UpdateOrderStatusRequest r){return service.status(id,r);}}
