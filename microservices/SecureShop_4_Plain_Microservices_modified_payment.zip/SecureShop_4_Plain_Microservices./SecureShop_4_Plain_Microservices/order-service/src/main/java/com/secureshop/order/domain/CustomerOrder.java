package com.secureshop.order.domain;
import jakarta.persistence.*; import java.math.BigDecimal; import java.time.Instant; import java.util.*;
@Entity @Table(name="customer_orders") public class CustomerOrder{
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(nullable=false) private UUID customerId;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private OrderStatus status;
 @Column(nullable=false,precision=14,scale=2) private BigDecimal totalAmount;
 @Column(nullable=false,length=3) private String currency;
 @Column(nullable=false,length=500) private String shippingAddress;
 @OneToMany(mappedBy="order",cascade=CascadeType.ALL,orphanRemoval=true) private List<OrderItem> items=new ArrayList<>();
 @Column(nullable=false,updatable=false) private Instant createdAt; @Column(nullable=false) private Instant updatedAt; @Version private long version;
 @PrePersist void prePersist(){Instant n=Instant.now();createdAt=n;updatedAt=n;} @PreUpdate void preUpdate(){updatedAt=Instant.now();}
 public void addItem(OrderItem i){items.add(i);i.setOrder(this);} public UUID getId(){return id;} public UUID getCustomerId(){return customerId;} public void setCustomerId(UUID v){customerId=v;}
 public OrderStatus getStatus(){return status;} public void setStatus(OrderStatus v){status=v;} public BigDecimal getTotalAmount(){return totalAmount;} public void setTotalAmount(BigDecimal v){totalAmount=v;}
 public String getCurrency(){return currency;} public void setCurrency(String v){currency=v;} public String getShippingAddress(){return shippingAddress;} public void setShippingAddress(String v){shippingAddress=v;}
 public List<OrderItem> getItems(){return items;} public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public long getVersion(){return version;}
}
