package com.secureshop.order.domain;
import jakarta.persistence.*; import java.math.BigDecimal; import java.util.UUID;
@Entity @Table(name="order_items") public class OrderItem{
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="order_id",nullable=false) private CustomerOrder order;
 @Column(nullable=false) private UUID productId; @Column(nullable=false,length=60) private String sku; @Column(nullable=false,length=180) private String productName;
 @Column(nullable=false,precision=14,scale=2) private BigDecimal unitPrice; @Column(nullable=false) private int quantity; @Column(nullable=false,precision=14,scale=2) private BigDecimal subtotal;
 public UUID getId(){return id;} public CustomerOrder getOrder(){return order;} public void setOrder(CustomerOrder v){order=v;} public UUID getProductId(){return productId;} public void setProductId(UUID v){productId=v;}
 public String getSku(){return sku;} public void setSku(String v){sku=v;} public String getProductName(){return productName;} public void setProductName(String v){productName=v;}
 public BigDecimal getUnitPrice(){return unitPrice;} public void setUnitPrice(BigDecimal v){unitPrice=v;} public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;} public BigDecimal getSubtotal(){return subtotal;} public void setSubtotal(BigDecimal v){subtotal=v;}
}
