package com.secureshop.order.domain;
public enum OrderStatus { PAYMENT_PENDING, PAID, PAYMENT_FAILED, CANCELLED, REFUNDED }
