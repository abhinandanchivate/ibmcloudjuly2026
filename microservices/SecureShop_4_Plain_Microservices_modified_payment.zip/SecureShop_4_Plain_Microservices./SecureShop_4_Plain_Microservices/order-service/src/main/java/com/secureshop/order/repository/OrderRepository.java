package com.secureshop.order.repository; import com.secureshop.order.domain.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.UUID;
public interface OrderRepository extends JpaRepository<CustomerOrder,UUID>{Page<CustomerOrder> findByCustomerId(UUID customerId,Pageable pageable);}
