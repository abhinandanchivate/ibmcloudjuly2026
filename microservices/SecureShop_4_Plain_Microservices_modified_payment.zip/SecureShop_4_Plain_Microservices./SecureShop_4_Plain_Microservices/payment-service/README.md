# Payment Service

Payment and refund microservice. It calls Order Service directly through `services.order.base-url`; no Eureka, Config Client, API Gateway, or Spring Security is used.
