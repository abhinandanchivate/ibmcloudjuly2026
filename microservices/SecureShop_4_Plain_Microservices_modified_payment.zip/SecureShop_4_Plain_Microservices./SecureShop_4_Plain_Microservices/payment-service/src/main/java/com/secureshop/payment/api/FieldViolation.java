package com.secureshop.payment.api;

public record FieldViolation(String field, String message, Object rejectedValue) {
}
