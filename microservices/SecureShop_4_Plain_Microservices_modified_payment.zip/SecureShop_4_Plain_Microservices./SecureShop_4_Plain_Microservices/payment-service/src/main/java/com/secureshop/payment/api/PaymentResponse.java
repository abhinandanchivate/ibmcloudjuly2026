package com.secureshop.payment.api; import com.secureshop.payment.domain.PaymentStatus; import java.math.BigDecimal; import java.time.Instant; import java.util.UUID;
public record PaymentResponse(UUID id,UUID orderId,UUID customerId,BigDecimal amount,String currency,PaymentStatus status,String providerReference,Instant createdAt,Instant updatedAt,long version){}
