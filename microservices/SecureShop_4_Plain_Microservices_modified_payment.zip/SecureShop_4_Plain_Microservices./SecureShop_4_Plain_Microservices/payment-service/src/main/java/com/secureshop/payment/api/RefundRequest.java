package com.secureshop.payment.api; import jakarta.validation.constraints.*; import java.math.BigDecimal;
public record RefundRequest(@NotNull @DecimalMin("0.01") BigDecimal amount,@Size(max=500) String reason){}
