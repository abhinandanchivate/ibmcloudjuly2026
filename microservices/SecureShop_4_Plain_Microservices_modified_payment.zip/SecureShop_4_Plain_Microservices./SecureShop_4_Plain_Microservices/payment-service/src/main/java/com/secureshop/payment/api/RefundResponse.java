package com.secureshop.payment.api; import com.secureshop.payment.domain.RefundStatus; import java.math.BigDecimal; import java.time.Instant; import java.util.UUID;
public record RefundResponse(UUID id,UUID paymentId,BigDecimal amount,RefundStatus status,String reason,Instant createdAt){}
