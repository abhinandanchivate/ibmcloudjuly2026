package com.secureshop.payment.api; import com.secureshop.payment.domain.PaymentStatus; import jakarta.validation.constraints.*;
public record UpdatePaymentStatusRequest(@NotNull PaymentStatus status,@Size(max=100) String providerReference){}
