package com.secureshop.payment.client;

import java.math.BigDecimal;
import java.util.UUID;

public record OrderPaymentContext(UUID orderId, UUID customerId, BigDecimal payableAmount,
                                  String currency, boolean paymentEligible) {
}
