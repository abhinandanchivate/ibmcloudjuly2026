package com.secureshop.payment.client;

public record PaymentOutcomeRequest(String paymentId, String providerReference) {
}
