package com.secureshop.payment.client;

import java.math.BigDecimal;

public record RefundOutcomeRequest(String refundId, BigDecimal amount, String providerReference) {
}
