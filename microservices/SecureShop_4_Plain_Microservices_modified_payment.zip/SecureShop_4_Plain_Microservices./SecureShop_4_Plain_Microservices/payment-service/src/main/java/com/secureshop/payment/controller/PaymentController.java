package com.secureshop.payment.controller;
import com.secureshop.payment.api.*;
import com.secureshop.payment.domain.PaymentStatus;
import com.secureshop.payment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController{
 private final PaymentService service;
 public PaymentController(PaymentService s){
  service=s;
 }
 @PostMapping @ResponseStatus(HttpStatus.CREATED)
 public PaymentResponse create(@Valid @RequestBody CreatePaymentRequest r,@RequestHeader("Idempotency-Key")String key){
  return service.create(r,key);
 }
 @GetMapping
 public PageResponse<PaymentResponse> list(
         @RequestParam(required=false)UUID orderId,
         @RequestParam(required=false)UUID customerId,
         @RequestParam(required=false)PaymentStatus status,
         @PageableDefault(size=20,sort="createdAt",direction=Sort.Direction.DESC)Pageable p){
  return service.list(orderId,customerId,status,p);
 }
 @GetMapping("/{id}")
 public PaymentResponse get(
         @PathVariable UUID id){
  return service.get(id);
 }
 @PatchMapping("/{id}/status")
 public PaymentResponse status(
         @PathVariable UUID id,
         @Valid @RequestBody UpdatePaymentStatusRequest r){
  return service.updateStatus(id,r);
 }
 @PostMapping("/{id}/refunds")
 @ResponseStatus(HttpStatus.CREATED) public RefundResponse refund(
         @PathVariable UUID id,@Valid @RequestBody RefundRequest r,@RequestHeader("Idempotency-Key")String key){
  return service.refund(id,r,key);
 }
 @GetMapping("/{id}/refunds")
 public List<RefundResponse> refunds(@PathVariable UUID id){
  return service.refunds(id);
 }
}
