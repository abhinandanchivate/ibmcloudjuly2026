package com.secureshop.payment.domain; import jakarta.persistence.*; import java.math.BigDecimal; import java.time.Instant; import java.util.UUID;
@Entity @Table(name="payments",uniqueConstraints=@UniqueConstraint(name="uk_payment_idempotency",columnNames="idempotency_key")) public class Payment{
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id; @Column(nullable=false) private UUID orderId; @Column(nullable=false) private UUID customerId;
 @Column(nullable=false,precision=14,scale=2) private BigDecimal amount; @Column(nullable=false,length=3) private String currency;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private PaymentStatus status; @Column(name="idempotency_key", nullable=false, length=100) private String idempotencyKey; @Column(length=100) private String providerReference;
 @Column(nullable=false,updatable=false) private Instant createdAt; @Column(nullable=false) private Instant updatedAt; @Version private long version;
 @PrePersist void prePersist(){Instant n=Instant.now();createdAt=n;updatedAt=n;} @PreUpdate void preUpdate(){updatedAt=Instant.now();}
 public UUID getId(){return id;} public UUID getOrderId(){return orderId;} public void setOrderId(UUID v){orderId=v;} public UUID getCustomerId(){return customerId;} public void setCustomerId(UUID v){customerId=v;}
 public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;} public String getCurrency(){return currency;} public void setCurrency(String v){currency=v;}
 public PaymentStatus getStatus(){return status;} public void setStatus(PaymentStatus v){status=v;} public String getIdempotencyKey(){return idempotencyKey;} public void setIdempotencyKey(String v){idempotencyKey=v;}
 public String getProviderReference(){return providerReference;} public void setProviderReference(String v){providerReference=v;} public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public long getVersion(){return version;}
}
