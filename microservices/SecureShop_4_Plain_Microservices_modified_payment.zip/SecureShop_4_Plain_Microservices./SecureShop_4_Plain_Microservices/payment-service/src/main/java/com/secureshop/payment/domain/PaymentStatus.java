package com.secureshop.payment.domain; public enum PaymentStatus { PENDING, SUCCESS, FAILED, REFUNDED, PARTIALLY_REFUNDED }
