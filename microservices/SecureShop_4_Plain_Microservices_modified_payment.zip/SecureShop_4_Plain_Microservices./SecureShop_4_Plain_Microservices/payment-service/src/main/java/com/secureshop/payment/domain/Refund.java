package com.secureshop.payment.domain; import jakarta.persistence.*; import java.math.BigDecimal; import java.time.Instant; import java.util.UUID;
@Entity @Table(name="refunds",uniqueConstraints=@UniqueConstraint(name="uk_refund_idempotency",columnNames="idempotency_key")) public class Refund{
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id; @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="payment_id") private Payment payment;
 @Column(nullable=false,precision=14,scale=2) private BigDecimal amount; @Enumerated(EnumType.STRING) @Column(nullable=false,length=20) private RefundStatus status;
 @Column(name="idempotency_key", nullable=false, length=100) private String idempotencyKey; @Column(length=500) private String reason; @Column(nullable=false,updatable=false) private Instant createdAt;
 @PrePersist void prePersist(){createdAt=Instant.now();}
 public UUID getId(){return id;} public Payment getPayment(){return payment;} public void setPayment(Payment v){payment=v;} public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
 public RefundStatus getStatus(){return status;} public void setStatus(RefundStatus v){status=v;} public String getIdempotencyKey(){return idempotencyKey;} public void setIdempotencyKey(String v){idempotencyKey=v;} public String getReason(){return reason;} public void setReason(String v){reason=v;} public Instant getCreatedAt(){return createdAt;}
}
