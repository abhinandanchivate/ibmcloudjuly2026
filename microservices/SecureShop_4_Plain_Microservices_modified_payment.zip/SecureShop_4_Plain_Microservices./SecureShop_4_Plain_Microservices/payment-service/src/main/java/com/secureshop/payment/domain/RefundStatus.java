package com.secureshop.payment.domain; public enum RefundStatus { COMPLETED }
