package com.secureshop.payment.repository; import com.secureshop.payment.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface RefundRepository extends JpaRepository<Refund,UUID>{Optional<Refund> findByIdempotencyKey(String key);List<Refund> findByPaymentIdOrderByCreatedAtDesc(UUID paymentId);List<Refund> findByPaymentId(UUID paymentId);}
