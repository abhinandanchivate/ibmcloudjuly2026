# SecureShop Microservices

A complete training-oriented e-commerce microservices implementation based on the SecureShop case-study document.

## Technology baseline

- Java 21
- Spring Boot 4.1.0
- Spring Framework 7.x (managed by Spring Boot)
- Spring Cloud 2025.1.2
- Spring Security 7.x (managed by Spring Boot)
- Spring Data JPA and Hibernate
- PostgreSQL 17 for local development
- Netflix Eureka service discovery
- Spring Cloud Config Server using a native classpath repository
- Spring Cloud Gateway Server WebFlux
- OpenFeign for synchronous internal communication
- JWT access tokens, opaque rotating refresh tokens, BCrypt password hashing
- Maven multi-module build

## Modules

| Module | Purpose | Port |
|---|---|---:|
| `secure-shop-common-web` | Shared error contract, exception handling, JWT utilities, correlation ID filter, service-token support | Library |
| `config-server` | Centralized external configuration | 8888 |
| `discovery-server` | Eureka registry and dashboard | 8761 |
| `api-gateway` | Public entry point, JWT validation, routing and upstream error normalization | 8080 |
| `identity-service` | Registration, login, token lifecycle, profile and user administration | 8081 |
| `catalog-service` | Product catalogue, pricing, status and inventory management | 8082 |
| `order-service` | Order lifecycle, ownership rules and stock coordination | 8083 |
| `payment-service` | Payment initiation, signed callback, reconciliation and refunds | 8084 |

Each business service owns a separate PostgreSQL database:

- `secureshop_identity`
- `secureshop_catalog`
- `secureshop_order`
- `secureshop_payment`

No business service directly reads another service's tables.

## Architecture

```mermaid
flowchart LR
    Client[Web / Mobile / Postman] --> Gateway[API Gateway :8080]
    Gateway --> Identity[Identity Service :8081]
    Gateway --> Catalog[Catalog Service :8082]
    Gateway --> Order[Order Service :8083]
    Gateway --> Payment[Payment Service :8084]

    Order -- SYSTEM_SERVICE JWT --> Catalog
    Payment -- SYSTEM_SERVICE JWT --> Order
    Provider[Payment Provider] --> Payment

    Identity --> IDDB[(Identity DB)]
    Catalog --> CATDB[(Catalog DB)]
    Order --> ORDDB[(Order DB)]
    Payment --> PAYDB[(Payment DB)]

    Config[Config Server :8888] -. configuration .-> Gateway
    Config -. configuration .-> Identity
    Config -. configuration .-> Catalog
    Config -. configuration .-> Order
    Config -. configuration .-> Payment

    Eureka[Eureka :8761] -. discovery .-> Gateway
    Eureka -. discovery .-> Identity
    Eureka -. discovery .-> Catalog
    Eureka -. discovery .-> Order
    Eureka -. discovery .-> Payment
```

## Security model

### Roles

- `CUSTOMER`: self-service profile, own orders and own payments
- `CATALOG_MANAGER`: product and inventory administration
- `ORDER_SUPPORT`: order administration
- `PAYMENT_AUDITOR`: payment visibility and refund-list visibility
- `ADMIN`: user administration and privileged business actions
- `SYSTEM_SERVICE`: internal service-to-service endpoints only

Registration grants `CUSTOMER`. The optional bootstrap account is granted `ADMIN`.

### Token design

- Access token: signed HS256 JWT, default lifetime 15 minutes
- Refresh token: random opaque secret, SHA-256 hash stored in Identity DB, default lifetime 7 days
- Refresh operation: rotates the token and revokes the previous token
- Logout: revokes the supplied refresh token after ownership validation
- Internal calls: short-lived JWT with `SYSTEM_SERVICE`, default lifetime 2 minutes
- Every service validates issuer and audience independently, even after gateway validation

For production, replace the shared HMAC secret with asymmetric keys or an external authorization server and protect private keys through a secret manager or KMS.

## Global API error contract

All MVC services return the same structure:

```json
{
  "timestamp": "2026-07-29T06:30:00Z",
  "status": 422,
  "error": "Unprocessable Content",
  "code": "CATALOG_STOCK_INSUFFICIENT",
  "message": "Requested quantity exceeds available stock.",
  "path": "/api/v1/orders",
  "correlationId": "7f6d3e28-91f0-4d13-a0ae-37b802e45854",
  "details": null
}
```

Validation failures use `details` as a list of field violations. Gateway authentication, authorization, timeout and unavailable-service failures use the same top-level fields.

## Included operational safeguards

- Case-insensitive email and SKU checks
- Soft deletion for users and products
- Optimistic entity versioning
- Pessimistic locking for stock changes
- Order-scoped idempotent stock reservation and release
- Compensating stock release when order persistence fails
- Payment and refund idempotency keys
- Signed provider callback using HMAC-SHA256
- Order status history, identity audit events, inventory movements and payment audit events
- Correlation ID propagation through the gateway and downstream calls
- Feign error translation into the common API error format
- Ownership checks inside services, not only in the gateway

## Prerequisites

- JDK 21
- Maven 3.9+
- Docker Desktop or Docker Engine with Compose
- `openssl` for the optional secret-generation script

## Local setup

### 1. Create environment variables

```bash
cp .env.example .env
./scripts/generate-secrets.sh
```

Copy the generated values into `.env`. Do not commit `.env`.

To load the file in a Unix-like shell:

```bash
set -a
. ./.env
set +a
```

### 2. Start PostgreSQL

```bash
docker compose up -d postgres
docker compose ps
```

The initialization script creates all four databases on the first database-volume initialization.

To recreate the databases from scratch:

```bash
docker compose down -v
docker compose up -d postgres
```

### 3. Build all modules

```bash
mvn clean install
```

`install` is used so each later `spring-boot:run` command can resolve the shared `secure-shop-common-web` module from the local Maven repository.

### 4. Start infrastructure

Open separate terminals from the project root:

```bash
mvn -pl config-server spring-boot:run
mvn -pl discovery-server spring-boot:run
```

Config Server: `http://localhost:8888/identity-service/default`

Eureka dashboard: `http://localhost:8761` using `EUREKA_USERNAME` and `EUREKA_PASSWORD`.

### 5. Start the gateway and business services

```bash
mvn -pl identity-service spring-boot:run
mvn -pl catalog-service spring-boot:run
mvn -pl order-service spring-boot:run
mvn -pl payment-service spring-boot:run
mvn -pl api-gateway spring-boot:run
```

All public calls should use the gateway at `http://localhost:8080`.

## Recommended startup order

1. PostgreSQL
2. Config Server
3. Eureka Server
4. Identity and Catalog
5. Order
6. Payment
7. API Gateway

## First login

When both bootstrap variables are set, Identity Service creates the administrator only when the email does not already exist:

```text
BOOTSTRAP_ADMIN_EMAIL=admin@secureshop.local
BOOTSTRAP_ADMIN_PASSWORD=ChangeMe-Admin-123!
```

Login through the gateway:

```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{
    "email": "admin@secureshop.local",
    "password": "ChangeMe-Admin-123!"
  }'
```

## End-to-end demo flow

1. Log in as bootstrap administrator.
2. Create a product using the administrator token.
3. Register a customer.
4. Log in as the customer.
5. Create an order using the product ID.
6. Initiate a payment with an `Idempotency-Key` header.
7. Generate the provider callback signature for `paymentId|status|providerReference`.
8. Send the provider callback directly to Payment Service on port 8084 because provider callbacks are intentionally not routed by the public gateway.
9. Confirm that Order Service moved the order to `PAYMENT_CONFIRMED`.
10. Use administrator payment endpoints to refund the payment when required.

A ready-to-import collection is available at `postman/SecureShop.postman_collection.json`. A plain HTTP client script is available at `docs/sample-requests.http`.

## Provider callback signature

The signature is lowercase hexadecimal HMAC-SHA256 over this exact payload:

```text
paymentId|status|providerReference
```

Example:

```bash
PAYLOAD="$PAYMENT_ID|SUCCESS|provider-demo-001"
SIGNATURE=$(printf '%s' "$PAYLOAD" | openssl dgst -sha256 -hmac "$PAYMENT_PROVIDER_SECRET" -hex | awk '{print $2}')
```

Send it as `X-Provider-Signature`.

## Configuration

Centralized configuration is stored under:

```text
config-server/src/main/resources/config-repo/
```

The services default to `http://localhost:8888`. Override this with:

```text
CONFIG_SERVER_URL=http://config-host:8888
```

Eureka host and port can be overridden with `EUREKA_HOST` and `EUREKA_PORT`.

## Important training versus production choices

This project deliberately uses `spring.jpa.hibernate.ddl-auto=update` to simplify a classroom lab. For production:

- Use Flyway or Liquibase migrations.
- Use PostgreSQL schemas/users with minimum privileges per service.
- Use an external identity provider or asymmetric JWT keys.
- Put secrets in Vault, AWS Secrets Manager, Azure Key Vault or an equivalent system.
- Use an outbox pattern and a message broker for reliable cross-service workflows.
- Add Resilience4j circuit breakers, retry policies and bulkheads where safe.
- Add OpenTelemetry tracing, centralized logs, metrics and alerting.
- Replace the demo provider reference generation and synchronous callback simulation with a real payment-provider adapter.
- Add contract tests, Testcontainers integration tests and load/security testing.

## Documentation map

- `docs/endpoint-coverage.md`: complete endpoint and authorization list
- `docs/sample-requests.http`: executable examples for IntelliJ HTTP Client or VS Code REST Client
- `docs/implementation-notes.md`: domain rules, consistency decisions and extension points
- `postman/SecureShop.postman_collection.json`: Postman workflow collection

