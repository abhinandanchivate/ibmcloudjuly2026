package com.secureshop.catalog; import org.springframework.boot.*; import org.springframework.boot.autoconfigure.SpringBootApplication; import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
@SpringBootApplication(scanBasePackages={"com.secureshop.catalog","com.secureshop.common"}) @EnableMethodSecurity
public class CatalogServiceApplication {public static void main(String[] args){SpringApplication.run(CatalogServiceApplication.class,args);}}
