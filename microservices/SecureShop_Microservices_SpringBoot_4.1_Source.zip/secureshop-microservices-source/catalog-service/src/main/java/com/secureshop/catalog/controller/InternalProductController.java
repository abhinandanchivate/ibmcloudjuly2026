package com.secureshop.catalog.controller;

import com.secureshop.catalog.api.StockRequest;
import com.secureshop.catalog.api.ValidateItemsRequest;
import com.secureshop.catalog.api.ValidateItemsResponse;
import com.secureshop.catalog.service.CatalogService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/v1/products")
public class InternalProductController {
    private final CatalogService service;

    public InternalProductController(CatalogService service) {
        this.service = service;
    }

    @PostMapping("/validate-items")
    public ValidateItemsResponse validate(@Valid @RequestBody ValidateItemsRequest request) {
        return service.validateItems(request);
    }

    @PostMapping("/reserve-stock")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void reserve(@Valid @RequestBody StockRequest request) {
        service.reserve(request);
    }

    @PostMapping("/release-stock")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void release(@Valid @RequestBody StockRequest request) {
        service.release(request);
    }
}
