# Endpoint Coverage and Authorization

Public clients call the API Gateway on port 8080. `/internal/**` is denied at the gateway and is reachable only through service discovery with a valid `SYSTEM_SERVICE` JWT.

## Identity Service

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/v1/auth/register` | Public | Register an active customer account |
| POST | `/api/v1/auth/login` | Public | Authenticate and issue access/refresh tokens |
| POST | `/api/v1/auth/refresh` | Public with refresh token | Rotate refresh token and issue new access token |
| POST | `/api/v1/auth/logout` | Authenticated | Revoke the supplied refresh token after ownership check |
| GET | `/api/v1/users/me` | Authenticated | Read current profile |
| PUT | `/api/v1/users/me` | Authenticated | Update current profile |
| PUT | `/api/v1/users/me/password` | Authenticated | Change current password and prevent reuse |
| GET | `/api/v1/admin/users` | ADMIN | Search/page users |
| GET | `/api/v1/admin/users/{userId}` | ADMIN | Read a user |
| PATCH | `/api/v1/admin/users/{userId}/status` | ADMIN | Change account status with audit reason |
| PUT | `/api/v1/admin/users/{userId}/roles` | ADMIN | Replace roles with audit reason |
| DELETE | `/api/v1/admin/users/{userId}` | ADMIN | Soft-delete a user |

## Catalog Service

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/v1/products` | Public | Page/search active products |
| GET | `/api/v1/products/{productId}` | Public | Read an active product |
| GET | `/api/v1/products/{productId}/availability` | Public | Read stock/sellability |
| POST | `/api/v1/admin/products` | CATALOG_MANAGER or ADMIN | Create product |
| GET | `/api/v1/admin/products` | CATALOG_MANAGER or ADMIN | Page/search all non-deleted products |
| GET | `/api/v1/admin/products/{productId}` | CATALOG_MANAGER or ADMIN | Read product including inactive |
| PUT | `/api/v1/admin/products/{productId}` | CATALOG_MANAGER or ADMIN | Replace editable product metadata |
| PATCH | `/api/v1/admin/products/{productId}/price` | CATALOG_MANAGER or ADMIN | Change price with reason |
| PATCH | `/api/v1/admin/products/{productId}/inventory` | CATALOG_MANAGER or ADMIN | Set/increase/decrease inventory with movement record |
| PATCH | `/api/v1/admin/products/{productId}/status` | CATALOG_MANAGER or ADMIN | Activate/deactivate product |
| DELETE | `/api/v1/admin/products/{productId}` | ADMIN | Soft-delete product |
| POST | `/internal/v1/products/validate-items` | SYSTEM_SERVICE | Validate status, stock, currency and calculate snapshot prices |
| POST | `/internal/v1/products/reserve-stock` | SYSTEM_SERVICE | Idempotently reserve stock by order ID |
| POST | `/internal/v1/products/release-stock` | SYSTEM_SERVICE | Idempotently release a prior reservation |

## Order Service

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/v1/orders` | CUSTOMER or ADMIN | Validate products, reserve stock and create order |
| GET | `/api/v1/orders` | CUSTOMER or ADMIN | List only authenticated user's orders |
| GET | `/api/v1/orders/{orderId}` | CUSTOMER or ADMIN + owner | Read own order |
| POST | `/api/v1/orders/{orderId}/cancel` | CUSTOMER or ADMIN + owner | Cancel own unpaid/failed-payment order |
| GET | `/api/v1/admin/orders` | ORDER_SUPPORT or ADMIN | Filter/page all orders |
| GET | `/api/v1/admin/orders/{orderId}` | ORDER_SUPPORT or ADMIN | Read any order |
| PATCH | `/api/v1/admin/orders/{orderId}/status` | ORDER_SUPPORT or ADMIN | Apply allowed lifecycle transition |
| POST | `/api/v1/admin/orders/{orderId}/cancel` | ORDER_SUPPORT or ADMIN | Privileged cancellation within allowed states |
| GET | `/internal/v1/orders/{orderId}/payment-context` | SYSTEM_SERVICE | Return amount, currency, owner and eligibility |
| POST | `/internal/v1/orders/{orderId}/payment-success` | SYSTEM_SERVICE | Record successful payment |
| POST | `/internal/v1/orders/{orderId}/payment-failed` | SYSTEM_SERVICE | Record failed/cancelled payment |
| POST | `/internal/v1/orders/{orderId}/refund-completed` | SYSTEM_SERVICE | Mark refunded order |

## Payment Service

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/v1/payments` | CUSTOMER or ADMIN | Initiate an idempotent payment for own eligible order |
| GET | `/api/v1/payments/{paymentId}` | CUSTOMER or ADMIN + owner | Read own payment |
| GET | `/api/v1/payments/order/{orderId}` | CUSTOMER or ADMIN + owner | List own payments for an order |
| POST | `/internal/v1/payments/provider-callback` | Public provider endpoint + HMAC signature | Process idempotent provider outcome |
| GET | `/internal/v1/payments/{paymentId}/status` | SYSTEM_SERVICE | Read internal payment status |
| POST | `/internal/v1/payments/{paymentId}/reconcile` | SYSTEM_SERVICE | Record reconciliation action |
| GET | `/api/v1/admin/payments` | PAYMENT_AUDITOR or ADMIN | Filter/page payments |
| GET | `/api/v1/admin/payments/{paymentId}` | PAYMENT_AUDITOR or ADMIN | Read payment |
| POST | `/api/v1/admin/payments/{paymentId}/refunds` | ADMIN | Create full or partial idempotent refund |
| GET | `/api/v1/admin/payments/{paymentId}/refunds` | PAYMENT_AUDITOR or ADMIN | List refunds |

## Important error codes

- Authentication/authorization: `AUTH_INVALID_CREDENTIALS`, `AUTH_ACCOUNT_RESTRICTED`, `AUTH_TOKEN_INVALID`, `AUTH_REFRESH_TOKEN_INVALID`, `AUTH_ACCESS_DENIED`, `AUTH_RESOURCE_OWNERSHIP_VIOLATION`
- Identity: `IDENTITY_EMAIL_ALREADY_EXISTS`, `IDENTITY_USER_NOT_FOUND`, `IDENTITY_PASSWORD_REUSE_NOT_ALLOWED`
- Catalog: `CATALOG_PRODUCT_NOT_FOUND`, `CATALOG_SKU_ALREADY_EXISTS`, `CATALOG_PRODUCT_INACTIVE`, `CATALOG_STOCK_INSUFFICIENT`, `CATALOG_INVENTORY_NEGATIVE`
- Order: `ORDER_NOT_FOUND`, `ORDER_STATUS_TRANSITION_INVALID`, `ORDER_CANCELLATION_NOT_ALLOWED`
- Payment: `PAYMENT_NOT_FOUND`, `PAYMENT_ORDER_NOT_ELIGIBLE`, `PAYMENT_DUPLICATE_REQUEST`, `PAYMENT_REFUND_NOT_ALLOWED`, `PAYMENT_PROVIDER_SIGNATURE_INVALID`
- Platform: `VALIDATION_FAILED`, `DATA_INTEGRITY_CONFLICT`, `UPSTREAM_SERVICE_UNAVAILABLE`, `UPSTREAM_TIMEOUT`, `INTERNAL_ERROR`
