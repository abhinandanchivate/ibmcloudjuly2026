# Implementation Notes

## Data ownership

Every business service owns its data and database. Cross-service foreign keys are represented as UUID values, not database constraints across databases.

## Order creation consistency

Order creation follows this synchronous workflow:

1. Catalog validates products, activity, stock, currency and current prices.
2. Catalog reserves stock using the future order UUID as an idempotency reference.
3. Order persists an immutable price/name/SKU snapshot.
4. If local order persistence fails, Order requests a compensating stock release.

The stock movement uniqueness constraint prevents repeating the same reserve or release operation for the same order/product/type.

A production system should use a transactional outbox and Saga orchestration/choreography to remove the dual-write window between services.

## Order state machine

Allowed transitions are enforced in `OrderService`:

- `PENDING_PAYMENT` → `PAYMENT_CONFIRMED`, `PAYMENT_FAILED`, `CANCELLED`
- `PAYMENT_FAILED` → `PAYMENT_CONFIRMED`, `CANCELLED`
- `PAYMENT_CONFIRMED` → `PROCESSING`, `CANCELLED`
- `PROCESSING` → `SHIPPED`, `CANCELLED`
- `SHIPPED` → `DELIVERED`
- `CANCELLED` → `REFUNDED`

Every transition records actor, reason, old/new status, timestamp and correlation ID.

## Payment idempotency

The `Idempotency-Key` request header is mandatory for payment initiation and refund creation.

- Repeating the same key for the same operation returns the existing result.
- Reusing it for a different order/payment returns `PAYMENT_DUPLICATE_REQUEST`.
- Provider callbacks are also state-idempotent and do not reverse terminal success/refund states.

## Provider callback protection

The callback is allowed without a JWT because a third-party provider normally cannot obtain a SecureShop access token. Instead it requires `X-Provider-Signature`, computed with HMAC-SHA256 over:

```text
paymentId|status|providerReference
```

The demo uses a single shared callback secret. A production adapter should also validate provider timestamp, replay window, provider event ID, source certificate/IP controls where supported, and provider-specific canonicalization.

## Authentication

Identity Service stores BCrypt hashes only. Access tokens include:

- `sub`: immutable user UUID or service name
- `username`: email for a user, service name for internal clients
- `roles`: role names without the `ROLE_` prefix
- issuer, audience, issued-at and expiry

Refresh tokens are never stored in plaintext. Rotation revokes the old database record and stores only the hash of the new token.

## Authorization defence in depth

The gateway blocks unauthenticated public traffic and denies `/internal/**`. Each service performs its own role checks. Ownership checks are enforced in service methods because path authorization alone cannot prove that the authenticated user owns a particular order or payment.

## Audit data

- Identity: administrative status/role/delete actions
- Catalog: stock changes and order reservation/release movements
- Order: every lifecycle transition
- Payment: creation, provider callback, ignored terminal callback, reconciliation and refund completion

## Mapper policy

Manual mappers are used rather than exposing JPA entities. This keeps persistence relationships, password hashes, token hashes, optimistic-lock fields and internal metadata out of public request/response models.

## Deliberate classroom simplifications

- Schema generation uses Hibernate `ddl-auto=update`.
- Internal communication is synchronous OpenFeign.
- One shared JWT HMAC secret is used across trusted services.
- Payment provider interaction is simulated.
- No message broker or distributed tracing backend is required.

These are explicitly replaceable extension points rather than recommended production defaults.
