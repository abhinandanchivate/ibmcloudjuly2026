package com.secureshop.identity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
@SpringBootApplication(scanBasePackages={"com.secureshop.identity","com.secureshop.common"})
@EnableMethodSecurity
public class IdentityServiceApplication { public static void main(String[] args){SpringApplication.run(IdentityServiceApplication.class,args);} }
