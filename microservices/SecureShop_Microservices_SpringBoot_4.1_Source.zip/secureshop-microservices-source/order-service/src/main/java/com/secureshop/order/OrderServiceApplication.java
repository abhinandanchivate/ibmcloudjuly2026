package com.secureshop.order; import org.springframework.boot.*; import org.springframework.boot.autoconfigure.SpringBootApplication; import org.springframework.cloud.openfeign.EnableFeignClients; import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
@SpringBootApplication(scanBasePackages={"com.secureshop.order","com.secureshop.common"}) @EnableFeignClients @EnableMethodSecurity
public class OrderServiceApplication {public static void main(String[] args){SpringApplication.run(OrderServiceApplication.class,args);}}
