package com.secureshop.payment; import org.springframework.boot.*; import org.springframework.boot.autoconfigure.SpringBootApplication; import org.springframework.cloud.openfeign.EnableFeignClients; import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
@SpringBootApplication(scanBasePackages={"com.secureshop.payment","com.secureshop.common"}) @EnableFeignClients @EnableMethodSecurity
public class PaymentServiceApplication {public static void main(String[] args){SpringApplication.run(PaymentServiceApplication.class,args);}}
