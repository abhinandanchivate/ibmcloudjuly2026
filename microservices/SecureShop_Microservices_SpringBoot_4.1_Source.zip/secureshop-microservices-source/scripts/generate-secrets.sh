#!/usr/bin/env sh
set -eu
printf 'JWT_SECRET=%s
' "$(openssl rand -base64 48 | tr -d '
')"
printf 'PAYMENT_PROVIDER_SECRET=%s
' "$(openssl rand -base64 32 | tr -d '
')"
printf 'POSTGRES_PASSWORD=%s
' "$(openssl rand -base64 24 | tr -d '
')"
printf 'EUREKA_PASSWORD=%s
' "$(openssl rand -base64 24 | tr -d '
')"
