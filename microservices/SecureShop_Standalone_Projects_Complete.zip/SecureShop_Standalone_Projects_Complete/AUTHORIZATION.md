# `@PreAuthorize` rules

- Identity admin controller: `hasRole('ADMIN')`
- Profile controller: `isAuthenticated()`
- Catalog admin controller: `hasAnyRole('CATALOG_MANAGER','ADMIN')`
- Catalog delete: `hasRole('ADMIN')`
- Catalog internal controller: `hasRole('SYSTEM_SERVICE')`
- Customer order controller: `hasAnyRole('CUSTOMER','ADMIN')`
- Order admin controller: `hasAnyRole('ORDER_SUPPORT','ADMIN')`
- Order internal controller: `hasRole('SYSTEM_SERVICE')`
- Customer payment controller: `hasAnyRole('CUSTOMER','ADMIN')`
- Payment admin controller: `hasAnyRole('PAYMENT_AUDITOR','ADMIN')`
- Refund creation: `hasRole('ADMIN')`
- Payment internal status/reconcile: `hasRole('SYSTEM_SERVICE')`
- Provider callback: `permitAll()` plus HMAC signature verification
