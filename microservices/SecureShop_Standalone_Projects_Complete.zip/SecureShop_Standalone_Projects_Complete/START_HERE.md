# SecureShop — Independent Standalone Spring Boot Projects

This workspace is **not** a Maven multi-module project.

## Important structure rules

- There is no root `pom.xml`.
- There is no `<modules>` section.
- Every application has its own independent `pom.xml`.
- Open each application folder separately in IntelliJ IDEA or VS Code.
- Do not import the outer workspace folder as a Maven project.

## Independent applications

1. `config-server`
2. `eureka-server`
3. `identity-service`
4. `catalog-service`
5. `order-service`
6. `payment-service`
7. `api-gateway`

Additional folders:

- `config-repository` — configuration files to push to the GitHub configuration repository.
- `postman` — collection and local environment.
- `docker` and `docker-compose.yml` — PostgreSQL setup.

## Open a project

Example for Identity Service:

```bash
cd identity-service
mvn clean spring-boot:run
```

Repeat from the relevant folder for every other application.

## Recommended startup order

1. PostgreSQL using `docker compose up -d`
2. Config Server
3. Eureka Server
4. Identity Service
5. Catalog Service
6. Order Service
7. Payment Service
8. API Gateway

## IntelliJ IDEA

Use **File → Open** and select one application folder, for example `identity-service`.
Open the other applications in separate IntelliJ windows. Each project resolves only its own `pom.xml`.
