package com.secureshop.gateway;
import org.slf4j.MDC;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import java.util.UUID;
@Component
public class CorrelationIdGlobalFilter implements GlobalFilter, Ordered {
 public static final String HEADER="X-Correlation-ID";
 @Override public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
  String id=exchange.getRequest().getHeaders().getFirst(HEADER);
  if(id==null||id.isBlank()) id=UUID.randomUUID().toString();
  final String correlationId=id;
  ServerWebExchange mutated=exchange.mutate().request(r->r.headers(h->h.set(HEADER,correlationId))).build();
  mutated.getResponse().getHeaders().set(HEADER,correlationId);
  return chain.filter(mutated).contextWrite(ctx->ctx.put("correlationId",correlationId));
 }
 @Override public int getOrder(){return Ordered.HIGHEST_PRECEDENCE;}
}
