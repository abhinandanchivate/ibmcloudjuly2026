package com.secureshop.gateway;
import java.time.Instant;
public record GatewayApiError(Instant timestamp, int status, String error, String code, String message, String path, String correlationId, Object details) {}
