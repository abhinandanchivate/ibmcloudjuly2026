package com.secureshop.gateway;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.support.NotFoundException;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import java.time.Instant;
@Component
public class GatewayFailureFilter implements GlobalFilter, Ordered {
 private final ObjectMapper mapper;
 public GatewayFailureFilter(ObjectMapper mapper){this.mapper=mapper;}
 @Override public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain){
  return chain.filter(exchange).onErrorResume(ex -> {
   HttpStatus status=(ex instanceof java.util.concurrent.TimeoutException)?HttpStatus.GATEWAY_TIMEOUT:HttpStatus.SERVICE_UNAVAILABLE;
   String code=status==HttpStatus.GATEWAY_TIMEOUT?"UPSTREAM_TIMEOUT":"UPSTREAM_SERVICE_UNAVAILABLE";
   if(!(ex instanceof NotFoundException) && !(ex instanceof ResponseStatusException) && status==HttpStatus.SERVICE_UNAVAILABLE) return Mono.error(ex);
   GatewayApiError error=new GatewayApiError(Instant.now(),status.value(),status.getReasonPhrase(),code,
      "A required downstream service is unavailable.",exchange.getRequest().getPath().value(),
      exchange.getResponse().getHeaders().getFirst(CorrelationIdGlobalFilter.HEADER),null);
   exchange.getResponse().setStatusCode(status); exchange.getResponse().getHeaders().set("Content-Type","application/json");
   try { byte[] bytes=mapper.writeValueAsBytes(error); return exchange.getResponse().writeWith(Mono.just(exchange.getResponse().bufferFactory().wrap(bytes))); }
   catch(Exception ignored){return exchange.getResponse().setComplete();}
  });
 }
 @Override public int getOrder(){return -2;}
}
