package com.secureshop.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.*;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtAuthenticationConverterAdapter;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Collection;
import java.util.List;

@Configuration
public class GatewaySecurityConfig {
 @Bean SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http, ObjectMapper mapper,
         Converter<Jwt, Mono<AbstractAuthenticationToken>> converter) {
  return http.csrf(ServerHttpSecurity.CsrfSpec::disable)
   .authorizeExchange(auth -> auth
    .pathMatchers("/actuator/health/**").permitAll()
    .pathMatchers(HttpMethod.POST, "/api/v1/auth/register", "/api/v1/auth/login", "/api/v1/auth/refresh").permitAll()
    .pathMatchers(HttpMethod.GET, "/api/v1/products", "/api/v1/products/**").permitAll()
    .pathMatchers("/internal/**").denyAll()
    .anyExchange().authenticated())
   .oauth2ResourceServer(oauth -> oauth.jwt(jwt -> jwt.jwtAuthenticationConverter(converter))
    .authenticationEntryPoint((exchange, ex) -> write(mapper, exchange, HttpStatus.UNAUTHORIZED, "AUTH_TOKEN_INVALID", "Access token is missing, expired, or invalid.")))
   .exceptionHandling(errors -> errors.accessDeniedHandler((exchange, ex) -> write(mapper, exchange, HttpStatus.FORBIDDEN, "AUTH_ACCESS_DENIED", "Access is denied for this operation.")))
   .build();
 }

 @Bean ReactiveJwtDecoder jwtDecoder(@Value("${security.jwt.secret}") String secret,
                                     @Value("${security.jwt.issuer}") String issuer,
                                     @Value("${security.jwt.audience}") String audience) {
  byte[] secretBytes = secret == null ? new byte[0] : secret.getBytes(StandardCharsets.UTF_8);
  if (secretBytes.length < 32) {
   throw new IllegalStateException("JWT_SECRET must contain at least 32 bytes");
  }
  SecretKey key = new SecretKeySpec(secretBytes, "HmacSHA256");
  NimbusReactiveJwtDecoder decoder = NimbusReactiveJwtDecoder.withSecretKey(key).macAlgorithm(MacAlgorithm.HS256).build();
  OAuth2TokenValidator<Jwt> issuerValidator = JwtValidators.createDefaultWithIssuer(issuer);
  OAuth2TokenValidator<Jwt> audienceValidator = jwt -> jwt.getAudience().contains(audience)
   ? OAuth2TokenValidatorResult.success()
   : OAuth2TokenValidatorResult.failure(new OAuth2Error("invalid_token", "Required audience is missing", null));
  decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(issuerValidator, audienceValidator));
  return decoder;
 }

 @Bean Converter<Jwt, Mono<AbstractAuthenticationToken>> jwtAuthenticationConverter() {
  org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter delegate =
      new org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter();
  delegate.setJwtGrantedAuthoritiesConverter(jwt -> {
   Object claim = jwt.getClaims().get("roles");
   if (!(claim instanceof Collection<?> roles)) return List.of();
   return roles.stream().map(String::valueOf).map(r -> new SimpleGrantedAuthority("ROLE_" + r)).map(a -> (GrantedAuthority)a).toList();
  });
  return new ReactiveJwtAuthenticationConverterAdapter(delegate);
 }

 private Mono<Void> write(ObjectMapper mapper, org.springframework.web.server.ServerWebExchange exchange,
                          HttpStatus status, String code, String message) {
  String correlationId = exchange.getResponse().getHeaders().getFirst("X-Correlation-ID");
  GatewayApiError error = new GatewayApiError(Instant.now(), status.value(), status.getReasonPhrase(), code, message,
          exchange.getRequest().getPath().value(), correlationId, null);
  exchange.getResponse().setStatusCode(status);
  exchange.getResponse().getHeaders().set("Content-Type", "application/json");
  try {
   byte[] bytes = mapper.writeValueAsBytes(error);
   return exchange.getResponse().writeWith(Mono.just(exchange.getResponse().bufferFactory().wrap(bytes)));
  } catch (Exception e) { return exchange.getResponse().setComplete(); }
 }
}
