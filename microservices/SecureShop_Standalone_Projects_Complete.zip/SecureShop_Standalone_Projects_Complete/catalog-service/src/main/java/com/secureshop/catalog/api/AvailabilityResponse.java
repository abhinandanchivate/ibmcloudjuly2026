package com.secureshop.catalog.api; import java.util.UUID; public record AvailabilityResponse(UUID productId,int availableQuantity,boolean active,boolean sellable){}
