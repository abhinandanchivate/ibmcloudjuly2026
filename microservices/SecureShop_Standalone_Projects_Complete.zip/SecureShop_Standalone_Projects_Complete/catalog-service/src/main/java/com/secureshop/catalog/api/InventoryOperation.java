package com.secureshop.catalog.api; public enum InventoryOperation { SET, INCREASE, DECREASE }
