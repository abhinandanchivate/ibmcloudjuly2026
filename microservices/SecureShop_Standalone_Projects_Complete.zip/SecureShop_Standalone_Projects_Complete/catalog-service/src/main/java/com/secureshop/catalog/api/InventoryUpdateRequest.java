package com.secureshop.catalog.api; import jakarta.validation.constraints.*;
public record InventoryUpdateRequest(@NotNull InventoryOperation operation,@PositiveOrZero int quantity,@NotBlank @Size(max=300) String reason){}
