package com.secureshop.catalog.api; import jakarta.validation.constraints.*; import java.math.BigDecimal;
public record PriceUpdateRequest(@NotNull @DecimalMin("0.01") BigDecimal price,@NotBlank String reason){}
