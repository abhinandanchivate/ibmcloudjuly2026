package com.secureshop.catalog.api; import jakarta.validation.constraints.*; import java.math.BigDecimal;
public record ProductCreateRequest(@NotBlank @Size(max=80) String sku,@NotBlank @Size(max=200) String name,@Size(max=2000) String description,@NotNull @DecimalMin("0.01") BigDecimal price,@NotBlank @Pattern(regexp="^[A-Za-z]{3}$") String currency,@Min(0) int stockQuantity,boolean active){}
