package com.secureshop.catalog.api; import jakarta.validation.constraints.*; import java.util.UUID; public record ProductItemRequest(@NotNull UUID productId,@Positive int quantity){}
