package com.secureshop.catalog.api; import jakarta.validation.constraints.NotBlank; public record ProductStatusRequest(boolean active,@NotBlank String reason){}
