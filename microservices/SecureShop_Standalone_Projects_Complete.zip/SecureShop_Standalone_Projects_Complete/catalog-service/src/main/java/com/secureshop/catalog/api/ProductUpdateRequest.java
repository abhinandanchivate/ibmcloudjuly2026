package com.secureshop.catalog.api; import jakarta.validation.constraints.*;
public record ProductUpdateRequest(@NotBlank @Size(max=80) String sku,@NotBlank @Size(max=200) String name,@Size(max=2000) String description,@NotBlank @Pattern(regexp="^[A-Za-z]{3}$") String currency){}
