package com.secureshop.catalog.api; import java.math.BigDecimal; import java.util.List; public record ValidateItemsResponse(List<ValidatedItemResponse> items,BigDecimal total,String currency){}
