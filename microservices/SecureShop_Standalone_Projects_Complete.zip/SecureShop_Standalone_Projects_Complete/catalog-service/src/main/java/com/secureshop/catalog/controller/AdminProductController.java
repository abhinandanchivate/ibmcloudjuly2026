package com.secureshop.catalog.controller;

import com.secureshop.catalog.api.InventoryUpdateRequest;
import com.secureshop.catalog.api.PriceUpdateRequest;
import com.secureshop.catalog.api.ProductCreateRequest;
import com.secureshop.catalog.api.ProductResponse;
import com.secureshop.catalog.api.ProductStatusRequest;
import com.secureshop.catalog.api.ProductUpdateRequest;
import com.secureshop.catalog.service.CatalogService;
import com.secureshop.common.api.PageResponse;
import jakarta.validation.Valid;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/products")
@PreAuthorize("hasAnyRole('CATALOG_MANAGER','ADMIN')")
public class AdminProductController {
    private final CatalogService service;

    public AdminProductController(CatalogService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductCreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @GetMapping
    public PageResponse<ProductResponse> list(@RequestParam(required = false) String q,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.adminList(q, pageable);
    }

    @GetMapping("/{id}")
    public ProductResponse get(@PathVariable UUID id) {
        return service.adminGet(id);
    }

    @PutMapping("/{id}")
    public ProductResponse update(@PathVariable UUID id,
                                  @Valid @RequestBody ProductUpdateRequest request) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/price")
    public ProductResponse updatePrice(@PathVariable UUID id,
                                       @Valid @RequestBody PriceUpdateRequest request) {
        return service.updatePrice(id, request);
    }

    @PatchMapping("/{id}/inventory")
    public ProductResponse updateInventory(@PathVariable UUID id,
                                           @Valid @RequestBody InventoryUpdateRequest request,
                                           Authentication authentication) {
        return service.updateInventory(id, request, authentication);
    }

    @PatchMapping("/{id}/status")
    public ProductResponse updateStatus(@PathVariable UUID id,
                                        @Valid @RequestBody ProductStatusRequest request) {
        return service.updateStatus(id, request);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable UUID id) {
        service.delete(id);
    }
}
