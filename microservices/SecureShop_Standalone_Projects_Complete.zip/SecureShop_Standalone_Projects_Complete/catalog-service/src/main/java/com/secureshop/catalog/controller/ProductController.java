package com.secureshop.catalog.controller;

import com.secureshop.catalog.api.AvailabilityResponse;
import com.secureshop.catalog.api.ProductResponse;
import com.secureshop.catalog.service.CatalogService;
import com.secureshop.common.api.PageResponse;
import java.math.BigDecimal;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private final CatalogService service;

    public ProductController(CatalogService service) {
        this.service = service;
    }

    @GetMapping
    public PageResponse<ProductResponse> list(@RequestParam(required = false) String q,
                                              @RequestParam(required = false) BigDecimal minPrice,
                                              @RequestParam(required = false) BigDecimal maxPrice,
                                              @PageableDefault(size = 20, sort = "name") Pageable pageable) {
        return service.publicList(q, minPrice, maxPrice, pageable);
    }

    @GetMapping("/{id}")
    public ProductResponse get(@PathVariable UUID id) {
        return service.publicGet(id);
    }

    @GetMapping("/{id}/availability")
    public AvailabilityResponse availability(@PathVariable UUID id) {
        return service.availability(id);
    }
}
