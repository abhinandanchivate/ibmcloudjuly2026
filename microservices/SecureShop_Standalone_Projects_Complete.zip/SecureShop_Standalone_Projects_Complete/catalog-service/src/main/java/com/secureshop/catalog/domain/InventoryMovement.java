package com.secureshop.catalog.domain;
import jakarta.persistence.*; import java.time.Instant; import java.util.UUID;
@Entity @Table(name="inventory_movements",uniqueConstraints=@UniqueConstraint(name="uk_inventory_reference",columnNames={"reference_id","product_id","type"}))
public class InventoryMovement {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id; @Column(name="product_id",nullable=false) private UUID productId; @Column(name="reference_id",nullable=false) private UUID referenceId;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private MovementType type; @Column(nullable=false) private int delta; @Column(nullable=false) private int resultingQuantity;
 @Column(nullable=false,length=300) private String reason; @Column(nullable=false,length=100) private String actor; @Column(length=100) private String correlationId; @Column(nullable=false,updatable=false) private Instant createdAt;
 @PrePersist void create(){createdAt=Instant.now();}
 public void setProductId(UUID v){productId=v;} public void setReferenceId(UUID v){referenceId=v;} public void setType(MovementType v){type=v;} public void setDelta(int v){delta=v;} public void setResultingQuantity(int v){resultingQuantity=v;} public void setReason(String v){reason=v;} public void setActor(String v){actor=v;} public void setCorrelationId(String v){correlationId=v;}
}
