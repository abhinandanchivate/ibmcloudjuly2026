package com.secureshop.catalog.domain; public enum MovementType { ADMIN_SET, ADMIN_INCREASE, ADMIN_DECREASE, ORDER_RESERVE, ORDER_RELEASE }
