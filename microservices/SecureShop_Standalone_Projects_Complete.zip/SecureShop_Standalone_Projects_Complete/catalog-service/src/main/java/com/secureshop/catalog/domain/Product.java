package com.secureshop.catalog.domain;
import jakarta.persistence.*; import java.math.BigDecimal; import java.time.Instant; import java.util.*;
@Entity @Table(name="products",uniqueConstraints=@UniqueConstraint(name="uk_product_sku",columnNames="sku"))
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(nullable=false,length=80) private String sku; @Column(nullable=false,length=200) private String name;
 @Column(length=2000) private String description; @Column(nullable=false,precision=19,scale=2) private BigDecimal price;
 @Column(nullable=false,length=3) private String currency; @Column(nullable=false) private int stockQuantity;
 @Column(nullable=false) private boolean active=true; @Column(nullable=false) private boolean deleted;
 @Column(nullable=false,updatable=false) private Instant createdAt; @Column(nullable=false) private Instant updatedAt; @Version private long version;
 @PrePersist void create(){Instant n=Instant.now();createdAt=n;updatedAt=n;sku=sku.trim().toUpperCase(Locale.ROOT);currency=currency.trim().toUpperCase(Locale.ROOT);}
 @PreUpdate void update(){updatedAt=Instant.now();sku=sku.trim().toUpperCase(Locale.ROOT);currency=currency.trim().toUpperCase(Locale.ROOT);}
 public UUID getId(){return id;} public String getSku(){return sku;} public void setSku(String v){sku=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getDescription(){return description;} public void setDescription(String v){description=v;} public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal v){price=v;} public String getCurrency(){return currency;} public void setCurrency(String v){currency=v;} public int getStockQuantity(){return stockQuantity;} public void setStockQuantity(int v){stockQuantity=v;} public boolean isActive(){return active;} public void setActive(boolean v){active=v;} public boolean isDeleted(){return deleted;} public void setDeleted(boolean v){deleted=v;} public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public long getVersion(){return version;}
}
