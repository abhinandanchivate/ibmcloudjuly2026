package com.secureshop.catalog.repository;
import com.secureshop.catalog.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.UUID;
public interface InventoryMovementRepository extends JpaRepository<InventoryMovement,UUID>{boolean existsByReferenceIdAndProductIdAndType(UUID referenceId,UUID productId,MovementType type);}
