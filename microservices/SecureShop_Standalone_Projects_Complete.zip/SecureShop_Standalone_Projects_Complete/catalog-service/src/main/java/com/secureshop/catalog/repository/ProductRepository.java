package com.secureshop.catalog.repository;
import com.secureshop.catalog.domain.Product; import jakarta.persistence.LockModeType; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.*; import org.springframework.data.repository.query.Param; import java.math.BigDecimal; import java.util.*;
public interface ProductRepository extends JpaRepository<Product,UUID>{
 boolean existsBySkuIgnoreCase(String sku);
 @Query("select p from Product p where p.deleted=false and p.active=true and (:q is null or lower(p.name) like lower(concat('%',:q,'%')) or lower(p.sku) like lower(concat('%',:q,'%'))) and (:minPrice is null or p.price>=:minPrice) and (:maxPrice is null or p.price<=:maxPrice)") Page<Product> searchPublic(@Param("q") String q,@Param("minPrice") BigDecimal minPrice,@Param("maxPrice") BigDecimal maxPrice,Pageable pageable);
 @Query("select p from Product p where p.deleted=false and (:q is null or lower(p.name) like lower(concat('%',:q,'%')) or lower(p.sku) like lower(concat('%',:q,'%')))") Page<Product> searchAdmin(@Param("q") String q,Pageable pageable);
 Optional<Product> findByIdAndDeletedFalse(UUID id); Optional<Product> findByIdAndDeletedFalseAndActiveTrue(UUID id);
 @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select p from Product p where p.id=:id and p.deleted=false") Optional<Product> findForUpdate(@Param("id") UUID id);
}
