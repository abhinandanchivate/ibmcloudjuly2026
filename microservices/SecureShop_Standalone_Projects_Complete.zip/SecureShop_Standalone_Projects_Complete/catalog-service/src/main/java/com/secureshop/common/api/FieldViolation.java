package com.secureshop.common.api;

public record FieldViolation(String field, String message, Object rejectedValue) {
}
