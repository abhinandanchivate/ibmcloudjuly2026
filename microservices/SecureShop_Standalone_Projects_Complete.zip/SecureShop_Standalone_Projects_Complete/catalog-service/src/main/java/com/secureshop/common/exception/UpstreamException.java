package com.secureshop.common.exception;

import org.springframework.http.HttpStatus;

public class UpstreamException extends DomainException {
    public UpstreamException(String message) {
        super(HttpStatus.SERVICE_UNAVAILABLE, "UPSTREAM_SERVICE_UNAVAILABLE", message);
    }
    public UpstreamException(String code, String message, HttpStatus status) {
        super(status, code, message);
    }
}
