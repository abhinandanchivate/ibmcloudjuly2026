package com.secureshop.common.security;

import com.secureshop.common.exception.DomainException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import java.util.UUID;

public final class CurrentUser {
    private CurrentUser() {}

    public static UUID userId(Authentication authentication) {
        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            try { return UUID.fromString(jwtAuth.getToken().getSubject()); }
            catch (IllegalArgumentException ignored) { }
        }
        throw new DomainException(HttpStatus.UNAUTHORIZED, "AUTH_TOKEN_INVALID", "Authenticated token has no valid user identifier.");
    }
}
