package com.secureshop.common.security;

import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class ServiceTokenProvider {
    private final JwtEncoder encoder;
    private final String issuer;
    private final String audience;
    private final String serviceName;
    private final Duration lifetime;

    public ServiceTokenProvider(JwtEncoder encoder, String issuer, String audience, String serviceName, Duration lifetime) {
        this.encoder = encoder;
        this.issuer = issuer;
        this.audience = audience;
        this.serviceName = serviceName;
        this.lifetime = lifetime;
    }

    public String issue() {
        Instant now = Instant.now();
        JwtClaimsSet claims = JwtClaimsSet.builder().issuer(issuer).subject(serviceName).audience(List.of(audience))
                .issuedAt(now).expiresAt(now.plus(lifetime)).id(UUID.randomUUID().toString())
                .claim("username", serviceName).claim("roles", List.of("SYSTEM_SERVICE")).build();
        JwsHeader header = JwsHeader.with(MacAlgorithm.HS256).type("JWT").build();
        return encoder.encode(JwtEncoderParameters.from(header, claims)).getTokenValue();
    }
}
