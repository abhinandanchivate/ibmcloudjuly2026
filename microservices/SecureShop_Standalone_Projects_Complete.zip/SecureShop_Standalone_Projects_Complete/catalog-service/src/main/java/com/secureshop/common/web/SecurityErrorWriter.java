package com.secureshop.common.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.secureshop.common.api.ApiError;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.time.Instant;

public final class SecurityErrorWriter {
    private SecurityErrorWriter() {}

    public static void write(ObjectMapper mapper, HttpServletRequest request, HttpServletResponse response,
                             HttpStatus status, String code, String message) throws IOException {
        String correlationId = response.getHeader(CorrelationIdFilter.HEADER);
        response.setStatus(status.value());
        response.setContentType("application/json");
        mapper.writeValue(response.getOutputStream(), new ApiError(Instant.now(), status.value(), status.getReasonPhrase(),
                code, message, request.getRequestURI(), correlationId, null));
    }
}
