# SecureShop Config Repository

Push these YAML files to the GitHub repository configured by `CONFIG_GIT_URI`.
The file name must match each application's `spring.application.name`.
Do not commit real production secrets; replace training defaults with environment variables or a secret manager.
