CREATE DATABASE secureshop_identity;
CREATE DATABASE secureshop_catalog;
CREATE DATABASE secureshop_order;
CREATE DATABASE secureshop_payment;
