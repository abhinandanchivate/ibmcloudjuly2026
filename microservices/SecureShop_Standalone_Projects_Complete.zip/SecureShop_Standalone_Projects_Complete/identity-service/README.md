# Identity Service

Authenticates users, issues JWT access and refresh tokens, manages profile, roles and account status.

## Integration checklist

- Independent Maven project
- Spring Boot 4.1.0 / Java 21
- Spring Cloud 2025.1.2
- Config Client with fail-fast and retry
- Eureka Client with explicit discovery enablement
- JWT authentication and role authorization
- PostgreSQL and Spring Data JPA
- DTO validation, mapper layer and global exception handler
- Gateway-compatible `/api/v1/**` endpoints

## Service identity

- `spring.application.name`: `identity-service`
- Default port from Config Server: `8081`
- Config Server: `${CONFIG_SERVER_URL:http://localhost:8888}`
- Eureka: `${EUREKA_URL:http://localhost:8761/eureka/}`

## Run

```bash
mvn clean spring-boot:run
```
