package com.secureshop.identity.api;
import jakarta.validation.constraints.*;
public record RegisterRequest(@NotBlank @Email @Size(max=180) String email,
 @NotBlank @Size(min=12,max=72) String password,@NotBlank @Size(max=80) String firstName,
 @NotBlank @Size(max=80) String lastName,@Pattern(regexp="^[0-9+() -]{7,30}$") String phone){}
