package com.secureshop.identity.api;
import jakarta.validation.constraints.*;
public record UpdateProfileRequest(@NotBlank @Size(max=80) String firstName,@NotBlank @Size(max=80) String lastName,
 @Pattern(regexp="^[0-9+() -]{7,30}$") String phone){}
