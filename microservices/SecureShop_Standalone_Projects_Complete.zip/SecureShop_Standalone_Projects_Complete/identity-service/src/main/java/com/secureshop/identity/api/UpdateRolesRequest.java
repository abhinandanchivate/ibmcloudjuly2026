package com.secureshop.identity.api;
import com.secureshop.identity.domain.RoleName; import jakarta.validation.constraints.*; import java.util.Set;
public record UpdateRolesRequest(@NotEmpty Set<RoleName> roles,@NotBlank String reason){}
