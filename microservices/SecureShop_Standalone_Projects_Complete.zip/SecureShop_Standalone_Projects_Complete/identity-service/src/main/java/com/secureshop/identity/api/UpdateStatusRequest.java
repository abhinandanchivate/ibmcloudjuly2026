package com.secureshop.identity.api;
import com.secureshop.identity.domain.AccountStatus; import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
public record UpdateStatusRequest(@NotNull AccountStatus status,@NotBlank String reason){}
