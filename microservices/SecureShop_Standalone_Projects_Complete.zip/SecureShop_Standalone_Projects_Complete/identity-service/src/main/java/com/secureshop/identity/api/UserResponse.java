package com.secureshop.identity.api;
import com.secureshop.identity.domain.AccountStatus;
import java.time.Instant; import java.util.*;
public record UserResponse(UUID id,String email,String firstName,String lastName,String phone,AccountStatus status,Set<String> roles,Instant createdAt,Instant updatedAt){}
