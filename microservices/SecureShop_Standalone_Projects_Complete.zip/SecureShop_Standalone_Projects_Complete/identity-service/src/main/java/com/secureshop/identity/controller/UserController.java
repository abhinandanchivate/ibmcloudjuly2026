package com.secureshop.identity.controller;

import com.secureshop.identity.api.ChangePasswordRequest;
import com.secureshop.identity.api.UpdateProfileRequest;
import com.secureshop.identity.api.UserResponse;
import com.secureshop.identity.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users/me")
@PreAuthorize("isAuthenticated()")
public class UserController {
    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @GetMapping
    public UserResponse me(Authentication authentication) {
        return service.me(authentication);
    }

    @PutMapping
    public UserResponse update(@Valid @RequestBody UpdateProfileRequest request,
                               Authentication authentication) {
        return service.updateMe(authentication, request);
    }

    @PutMapping("/password")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void changePassword(@Valid @RequestBody ChangePasswordRequest request,
                               Authentication authentication) {
        service.changePassword(authentication, request);
    }
}
