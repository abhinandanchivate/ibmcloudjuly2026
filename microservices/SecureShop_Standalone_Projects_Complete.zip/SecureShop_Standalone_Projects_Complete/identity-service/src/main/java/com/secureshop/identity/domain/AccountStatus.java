package com.secureshop.identity.domain;
public enum AccountStatus { ACTIVE, DISABLED, LOCKED, UNVERIFIED, DELETED }
