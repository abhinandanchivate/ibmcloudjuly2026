package com.secureshop.identity.domain;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;
@Entity @Table(name="identity_audit_events")
public class IdentityAuditEvent {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 private UUID actorId; private UUID targetUserId;
 @Column(nullable=false,length=80) private String action;
 @Column(length=1000) private String oldValue; @Column(length=1000) private String newValue;
 @Column(length=100) private String correlationId;
 @Column(nullable=false,updatable=false) private Instant createdAt;
 @PrePersist void create(){createdAt=Instant.now();}
 public void setActorId(UUID v){actorId=v;} public void setTargetUserId(UUID v){targetUserId=v;} public void setAction(String v){action=v;}
 public void setOldValue(String v){oldValue=v;} public void setNewValue(String v){newValue=v;} public void setCorrelationId(String v){correlationId=v;}
}
