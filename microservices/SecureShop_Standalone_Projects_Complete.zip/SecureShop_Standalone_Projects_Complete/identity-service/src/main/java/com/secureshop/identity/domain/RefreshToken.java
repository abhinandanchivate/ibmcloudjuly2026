package com.secureshop.identity.domain;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;
@Entity
@Table(name="refresh_tokens",indexes=@Index(name="idx_refresh_token_hash",columnList="token_hash",unique=true))
public class RefreshToken {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="user_id",nullable=false) private UserAccount user;
 @Column(name="token_hash",nullable=false,length=64,unique=true) private String tokenHash;
 @Column(nullable=false) private Instant expiresAt;
 @Column(nullable=false) private boolean revoked;
 @Column(nullable=false,updatable=false) private Instant createdAt;
 private Instant revokedAt;
 @PrePersist void create(){createdAt=Instant.now();}
 public UUID getId(){return id;} public UserAccount getUser(){return user;} public void setUser(UserAccount user){this.user=user;}
 public String getTokenHash(){return tokenHash;} public void setTokenHash(String tokenHash){this.tokenHash=tokenHash;}
 public Instant getExpiresAt(){return expiresAt;} public void setExpiresAt(Instant expiresAt){this.expiresAt=expiresAt;}
 public boolean isRevoked(){return revoked;} public void setRevoked(boolean revoked){this.revoked=revoked;}
 public Instant getCreatedAt(){return createdAt;} public Instant getRevokedAt(){return revokedAt;} public void setRevokedAt(Instant revokedAt){this.revokedAt=revokedAt;}
}
