package com.secureshop.identity.domain;
public enum RoleName { CUSTOMER, CATALOG_MANAGER, ORDER_SUPPORT, PAYMENT_AUDITOR, ADMIN, SYSTEM_SERVICE }
