package com.secureshop.identity.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.*;

@Entity
@Table(name="user_accounts", uniqueConstraints=@UniqueConstraint(name="uk_user_email", columnNames="email"))
public class UserAccount {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(nullable=false,length=180) private String email;
 @Column(nullable=false,length=100) private String passwordHash;
 @Column(nullable=false,length=80) private String firstName;
 @Column(nullable=false,length=80) private String lastName;
 @Column(length=30) private String phone;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private AccountStatus status=AccountStatus.ACTIVE;
 @ElementCollection(fetch=FetchType.EAGER)
 @CollectionTable(name="user_roles",joinColumns=@JoinColumn(name="user_id"))
 @Enumerated(EnumType.STRING) @Column(name="role_name",nullable=false,length=40)
 private Set<RoleName> roles=new HashSet<>();
 @Column(nullable=false) private boolean deleted;
 @Column(nullable=false,updatable=false) private Instant createdAt;
 @Column(nullable=false) private Instant updatedAt;
 @Version private long version;
 @PrePersist void create(){Instant now=Instant.now();createdAt=now;updatedAt=now;email=email.trim().toLowerCase(Locale.ROOT);}
 @PreUpdate void update(){updatedAt=Instant.now();email=email.trim().toLowerCase(Locale.ROOT);}
 public UUID getId(){return id;} public void setId(UUID id){this.id=id;}
 public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
 public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String passwordHash){this.passwordHash=passwordHash;}
 public String getFirstName(){return firstName;} public void setFirstName(String firstName){this.firstName=firstName;}
 public String getLastName(){return lastName;} public void setLastName(String lastName){this.lastName=lastName;}
 public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;}
 public AccountStatus getStatus(){return status;} public void setStatus(AccountStatus status){this.status=status;}
 public Set<RoleName> getRoles(){return roles;} public void setRoles(Set<RoleName> roles){this.roles=roles;}
 public boolean isDeleted(){return deleted;} public void setDeleted(boolean deleted){this.deleted=deleted;}
 public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public long getVersion(){return version;}
}
