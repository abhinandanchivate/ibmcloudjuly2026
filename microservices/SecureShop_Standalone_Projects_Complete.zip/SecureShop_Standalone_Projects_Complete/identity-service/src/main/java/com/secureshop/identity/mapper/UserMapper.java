package com.secureshop.identity.mapper;
import com.secureshop.identity.api.UserResponse; import com.secureshop.identity.domain.UserAccount; import org.springframework.stereotype.Component;
import java.util.stream.Collectors;
@Component public class UserMapper { public UserResponse toResponse(UserAccount u){return new UserResponse(u.getId(),u.getEmail(),u.getFirstName(),u.getLastName(),u.getPhone(),u.getStatus(),u.getRoles().stream().map(Enum::name).collect(Collectors.toUnmodifiableSet()),u.getCreatedAt(),u.getUpdatedAt());}}
