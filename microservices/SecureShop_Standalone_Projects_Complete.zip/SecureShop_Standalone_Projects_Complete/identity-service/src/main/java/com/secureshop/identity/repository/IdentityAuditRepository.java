package com.secureshop.identity.repository;
import com.secureshop.identity.domain.IdentityAuditEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;
public interface IdentityAuditRepository extends JpaRepository<IdentityAuditEvent,UUID>{}
