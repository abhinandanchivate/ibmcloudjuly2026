package com.secureshop.identity.repository;
import com.secureshop.identity.domain.UserAccount;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface UserAccountRepository extends JpaRepository<UserAccount,UUID> {
 Optional<UserAccount> findByEmailIgnoreCaseAndDeletedFalse(String email);
 boolean existsByEmailIgnoreCase(String email);
 Page<UserAccount> findByDeletedFalse(Pageable pageable);
 Page<UserAccount> findByDeletedFalseAndEmailContainingIgnoreCase(String email,Pageable pageable);
}
