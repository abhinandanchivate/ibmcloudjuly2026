package com.secureshop.identity.service;
import com.secureshop.identity.domain.UserAccount;
import org.springframework.beans.factory.annotation.Value; import org.springframework.security.oauth2.jose.jws.MacAlgorithm; import org.springframework.security.oauth2.jwt.*; import org.springframework.stereotype.Service;
import java.time.*; import java.util.*;
@Service public class JwtTokenService {
 private final JwtEncoder encoder; private final String issuer; private final String audience; private final Duration lifetime;
 public JwtTokenService(JwtEncoder encoder,@Value("${security.jwt.issuer}") String issuer,@Value("${security.jwt.audience}") String audience,@Value("${identity.access-token-lifetime}") Duration lifetime){this.encoder=encoder;this.issuer=issuer;this.audience=audience;this.lifetime=lifetime;}
 public String issue(UserAccount user){Instant now=Instant.now();JwtClaimsSet claims=JwtClaimsSet.builder().issuer(issuer).subject(user.getId().toString()).audience(List.of(audience)).issuedAt(now).expiresAt(now.plus(lifetime)).id(UUID.randomUUID().toString()).claim("username",user.getEmail()).claim("roles",user.getRoles().stream().map(Enum::name).toList()).build();JwsHeader header=JwsHeader.with(MacAlgorithm.HS256).type("JWT").build();return encoder.encode(JwtEncoderParameters.from(header,claims)).getTokenValue();}
 public long expiresInSeconds(){return lifetime.toSeconds();}
}
