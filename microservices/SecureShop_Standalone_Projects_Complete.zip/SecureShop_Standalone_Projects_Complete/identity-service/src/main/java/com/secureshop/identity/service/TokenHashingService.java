package com.secureshop.identity.service;
import org.springframework.stereotype.Service; import java.nio.charset.StandardCharsets; import java.security.*; import java.util.HexFormat;
@Service public class TokenHashingService { public String hash(String value){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}}
