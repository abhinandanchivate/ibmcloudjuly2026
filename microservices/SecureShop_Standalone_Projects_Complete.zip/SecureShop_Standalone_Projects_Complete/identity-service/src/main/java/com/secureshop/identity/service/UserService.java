package com.secureshop.identity.service;

import com.secureshop.common.api.PageResponse;
import com.secureshop.common.exception.DomainException;
import com.secureshop.common.security.CurrentUser;
import com.secureshop.identity.api.ChangePasswordRequest;
import com.secureshop.identity.api.UpdateProfileRequest;
import com.secureshop.identity.api.UpdateRolesRequest;
import com.secureshop.identity.api.UpdateStatusRequest;
import com.secureshop.identity.api.UserResponse;
import com.secureshop.identity.domain.AccountStatus;
import com.secureshop.identity.domain.RefreshToken;
import com.secureshop.identity.domain.RoleName;
import com.secureshop.identity.domain.UserAccount;
import com.secureshop.identity.mapper.UserMapper;
import com.secureshop.identity.repository.RefreshTokenRepository;
import com.secureshop.identity.repository.UserAccountRepository;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    private final UserAccountRepository users;
    private final RefreshTokenRepository refreshTokens;
    private final UserMapper mapper;
    private final PasswordEncoder encoder;
    private final AuditService audit;

    public UserService(
            UserAccountRepository users,
            RefreshTokenRepository refreshTokens,
            UserMapper mapper,
            PasswordEncoder encoder,
            AuditService audit) {
        this.users = users;
        this.refreshTokens = refreshTokens;
        this.mapper = mapper;
        this.encoder = encoder;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public UserResponse me(Authentication authentication) {
        return mapper.toResponse(find(CurrentUser.userId(authentication)));
    }

    @Transactional
    public UserResponse updateMe(Authentication authentication, UpdateProfileRequest request) {
        UserAccount user = find(CurrentUser.userId(authentication));
        user.setFirstName(request.firstName().trim());
        user.setLastName(request.lastName().trim());
        user.setPhone(request.phone());
        return mapper.toResponse(user);
    }

    @Transactional
    public void changePassword(Authentication authentication, ChangePasswordRequest request) {
        UserAccount user = find(CurrentUser.userId(authentication));
        if (!encoder.matches(request.currentPassword(), user.getPasswordHash())) {
            throw new DomainException(HttpStatus.UNAUTHORIZED, "AUTH_INVALID_CREDENTIALS",
                    "Current password is invalid.");
        }
        if (encoder.matches(request.newPassword(), user.getPasswordHash())) {
            throw new DomainException(HttpStatus.UNPROCESSABLE_CONTENT,
                    "IDENTITY_PASSWORD_REUSE_NOT_ALLOWED",
                    "New password must differ from the current password.");
        }
        user.setPasswordHash(encoder.encode(request.newPassword()));
        revokeRefreshTokens(user);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserResponse> list(String query, Pageable pageable) {
        Page<UserAccount> page = query == null || query.isBlank()
                ? users.findByDeletedFalse(pageable)
                : users.findByDeletedFalseAndEmailContainingIgnoreCase(query.trim(), pageable);
        return PageResponse.from(page.map(mapper::toResponse));
    }

    @Transactional(readOnly = true)
    public UserResponse get(UUID id) {
        return mapper.toResponse(find(id));
    }

    @Transactional
    public UserResponse updateStatus(
            Authentication authentication, UUID id, UpdateStatusRequest request) {
        UUID actorId = CurrentUser.userId(authentication);
        if (request.status() == AccountStatus.DELETED) {
            throw new DomainException(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED",
                    "Use the delete endpoint to deactivate a user.");
        }
        if (actorId.equals(id) && request.status() != AccountStatus.ACTIVE) {
            throw new DomainException(HttpStatus.CONFLICT, "IDENTITY_SELF_ADMINISTRATION_NOT_ALLOWED",
                    "An administrator cannot restrict their own active account.");
        }
        UserAccount user = find(id);
        AccountStatus old = user.getStatus();
        user.setStatus(request.status());
        if (request.status() != AccountStatus.ACTIVE) {
            revokeRefreshTokens(user);
        }
        audit.record(actorId, id, "USER_STATUS_CHANGED", old,
                request.status() + " reason=" + request.reason());
        return mapper.toResponse(user);
    }

    @Transactional
    public UserResponse updateRoles(
            Authentication authentication, UUID id, UpdateRolesRequest request) {
        UUID actorId = CurrentUser.userId(authentication);
        if (request.roles().contains(RoleName.SYSTEM_SERVICE)) {
            throw new DomainException(HttpStatus.FORBIDDEN, "AUTH_ACCESS_DENIED",
                    "SYSTEM_SERVICE cannot be assigned to a user account.");
        }
        if (actorId.equals(id) && !request.roles().contains(RoleName.ADMIN)) {
            throw new DomainException(HttpStatus.CONFLICT, "IDENTITY_SELF_ADMINISTRATION_NOT_ALLOWED",
                    "An administrator cannot remove their own ADMIN role.");
        }
        UserAccount user = find(id);
        Set<RoleName> old = Set.copyOf(user.getRoles());
        user.setRoles(new HashSet<>(request.roles()));
        revokeRefreshTokens(user);
        audit.record(actorId, id, "USER_ROLES_CHANGED", old,
                request.roles() + " reason=" + request.reason());
        return mapper.toResponse(user);
    }

    @Transactional
    public void delete(Authentication authentication, UUID id) {
        UUID actorId = CurrentUser.userId(authentication);
        if (actorId.equals(id)) {
            throw new DomainException(HttpStatus.CONFLICT, "IDENTITY_SELF_ADMINISTRATION_NOT_ALLOWED",
                    "An administrator cannot delete their own account.");
        }
        UserAccount user = find(id);
        user.setDeleted(true);
        user.setStatus(AccountStatus.DELETED);
        revokeRefreshTokens(user);
        audit.record(actorId, id, "USER_DEACTIVATED", null, "soft-delete");
    }

    private void revokeRefreshTokens(UserAccount user) {
        Instant now = Instant.now();
        for (RefreshToken token : refreshTokens.findByUser_IdAndRevokedFalse(user.getId())) {
            token.setRevoked(true);
            token.setRevokedAt(now);
        }
    }

    private UserAccount find(UUID id) {
        return users.findById(id).filter(user -> !user.isDeleted())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND,
                        "IDENTITY_USER_NOT_FOUND", "Requested user does not exist."));
    }
}
