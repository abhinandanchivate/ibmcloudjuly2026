# Order Service

Creates and manages orders and uses a Eureka-resolved Feign client for Catalog internal APIs.

## Integration checklist

- Independent Maven project
- Spring Boot 4.1.0 / Java 21
- Spring Cloud 2025.1.2
- Config Client with fail-fast and retry
- Eureka Client with explicit discovery enablement
- JWT authentication and role authorization
- PostgreSQL and Spring Data JPA
- DTO validation, mapper layer and global exception handler
- Gateway-compatible `/api/v1/**` endpoints

## Service identity

- `spring.application.name`: `order-service`
- Default port from Config Server: `8083`
- Config Server: `${CONFIG_SERVER_URL:http://localhost:8888}`
- Eureka: `${EUREKA_URL:http://localhost:8761/eureka/}`

## Internal discovery call

`@FeignClient(name = "catalog-service")` resolves Catalog instances through Eureka and sends a short-lived `SYSTEM_SERVICE` JWT.

## Run

```bash
mvn clean spring-boot:run
```
