package com.secureshop.order.api; import jakarta.validation.constraints.*; public record CancelOrderRequest(@NotBlank @Size(max=500) String reason){}
