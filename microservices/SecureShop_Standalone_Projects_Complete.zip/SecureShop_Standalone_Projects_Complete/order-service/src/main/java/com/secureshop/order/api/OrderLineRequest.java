package com.secureshop.order.api; import jakarta.validation.constraints.*; import java.util.UUID; public record OrderLineRequest(@NotNull UUID productId,@Positive int quantity){}
