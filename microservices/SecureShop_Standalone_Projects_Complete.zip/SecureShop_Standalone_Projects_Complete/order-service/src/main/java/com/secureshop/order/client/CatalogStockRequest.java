package com.secureshop.order.client; import java.util.*; public record CatalogStockRequest(UUID orderId,List<CatalogItemRequest> items,String reason){}
