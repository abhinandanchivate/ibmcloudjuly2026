package com.secureshop.order.client; import java.util.List; public record CatalogValidateRequest(List<CatalogItemRequest> items){}
