package com.secureshop.order.client; import java.math.BigDecimal; import java.util.List; public record CatalogValidateResponse(List<CatalogValidatedItem> items,BigDecimal total,String currency){}
