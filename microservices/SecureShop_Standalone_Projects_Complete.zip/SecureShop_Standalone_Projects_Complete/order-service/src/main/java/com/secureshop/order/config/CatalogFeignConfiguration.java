package com.secureshop.order.config;

import com.secureshop.common.security.JwtSupport;
import com.secureshop.common.security.ServiceTokenProvider;
import feign.RequestInterceptor;
import java.time.Duration;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.jwt.JwtEncoder;

@Configuration
public class CatalogFeignConfiguration {
    @Bean
    JwtEncoder serviceJwtEncoder(@Value("${security.jwt.secret}") String secret) {
        return JwtSupport.encoder(secret);
    }

    @Bean
    ServiceTokenProvider serviceTokenProvider(
            JwtEncoder encoder,
            @Value("${security.jwt.issuer}") String issuer,
            @Value("${security.jwt.audience}") String audience,
            @Value("${service-auth.service-name}") String name,
            @Value("${service-auth.token-lifetime}") Duration lifetime) {
        return new ServiceTokenProvider(encoder, issuer, audience, name, lifetime);
    }

    @Bean
    RequestInterceptor serviceTokenInterceptor(ServiceTokenProvider provider) {
        return template -> {
            template.header("Authorization", "Bearer " + provider.issue());
            String correlationId = MDC.get("correlationId");
            if (correlationId != null && !correlationId.isBlank()) {
                template.header("X-Correlation-ID", correlationId);
            }
        };
    }
}
