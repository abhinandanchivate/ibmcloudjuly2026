package com.secureshop.order.controller;

import com.secureshop.common.api.PageResponse;
import com.secureshop.order.api.CancelOrderRequest;
import com.secureshop.order.api.OrderResponse;
import com.secureshop.order.api.UpdateOrderStatusRequest;
import com.secureshop.order.domain.OrderStatus;
import com.secureshop.order.service.OrderService;
import jakarta.validation.Valid;
import java.time.Instant;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/orders")
@PreAuthorize("hasAnyRole('ORDER_SUPPORT','ADMIN')")
public class AdminOrderController {
    private final OrderService service;

    public AdminOrderController(OrderService service) {
        this.service = service;
    }

    @GetMapping
    public PageResponse<OrderResponse> list(
            @RequestParam(required = false) UUID customerId,
            @RequestParam(required = false) OrderStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.adminList(customerId, status, from, to, pageable);
    }

    @GetMapping("/{id}")
    public OrderResponse get(@PathVariable UUID id) {
        return service.adminGet(id);
    }

    @PatchMapping("/{id}/status")
    public OrderResponse updateStatus(Authentication authentication,
                                      @PathVariable UUID id,
                                      @Valid @RequestBody UpdateOrderStatusRequest request) {
        return service.adminStatus(authentication, id, request);
    }

    @PostMapping("/{id}/cancel")
    public OrderResponse cancel(Authentication authentication,
                                @PathVariable UUID id,
                                @Valid @RequestBody CancelOrderRequest request) {
        return service.adminCancel(authentication, id, request);
    }
}
