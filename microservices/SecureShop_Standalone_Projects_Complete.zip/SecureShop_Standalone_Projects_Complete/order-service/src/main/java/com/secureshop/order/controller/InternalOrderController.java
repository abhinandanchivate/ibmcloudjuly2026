package com.secureshop.order.controller;

import com.secureshop.order.api.OrderResponse;
import com.secureshop.order.api.PaymentContextResponse;
import com.secureshop.order.api.PaymentOutcomeRequest;
import com.secureshop.order.api.RefundOutcomeRequest;
import com.secureshop.order.service.OrderService;
import jakarta.validation.Valid;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/internal/v1/orders")
@PreAuthorize("hasRole('SYSTEM_SERVICE')")
public class InternalOrderController {
    private final OrderService service;

    public InternalOrderController(OrderService service) {
        this.service = service;
    }

    @GetMapping("/{id}/payment-context")
    public PaymentContextResponse paymentContext(@PathVariable UUID id) {
        return service.paymentContext(id);
    }

    @PostMapping("/{id}/payment-success")
    public OrderResponse paymentSuccess(@PathVariable UUID id,
                                        @Valid @RequestBody PaymentOutcomeRequest request) {
        return service.paymentSuccess(id, request);
    }

    @PostMapping("/{id}/payment-failed")
    public OrderResponse paymentFailed(@PathVariable UUID id,
                                       @Valid @RequestBody PaymentOutcomeRequest request) {
        return service.paymentFailed(id, request);
    }

    @PostMapping("/{id}/refund-completed")
    public OrderResponse refundCompleted(@PathVariable UUID id,
                                         @Valid @RequestBody RefundOutcomeRequest request) {
        return service.refundCompleted(id, request);
    }
}
