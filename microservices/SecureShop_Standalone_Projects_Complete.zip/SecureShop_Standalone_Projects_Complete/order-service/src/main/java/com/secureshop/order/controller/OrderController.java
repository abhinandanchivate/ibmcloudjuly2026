package com.secureshop.order.controller;

import com.secureshop.common.api.PageResponse;
import com.secureshop.order.api.CancelOrderRequest;
import com.secureshop.order.api.CreateOrderRequest;
import com.secureshop.order.api.OrderResponse;
import com.secureshop.order.service.OrderService;
import jakarta.validation.Valid;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/orders")
@PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
public class OrderController {
    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrderResponse> create(Authentication authentication,
                                                @Valid @RequestBody CreateOrderRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(authentication, request));
    }

    @GetMapping
    public PageResponse<OrderResponse> list(Authentication authentication,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.mine(authentication, pageable);
    }

    @GetMapping("/{id}")
    public OrderResponse get(Authentication authentication, @PathVariable UUID id) {
        return service.mineById(authentication, id);
    }

    @PostMapping("/{id}/cancel")
    public OrderResponse cancel(Authentication authentication,
                                @PathVariable UUID id,
                                @Valid @RequestBody CancelOrderRequest request) {
        return service.cancelMine(authentication, id, request);
    }
}
