package com.secureshop.payment.api; import jakarta.validation.constraints.NotBlank; public record ReconcileRequest(@NotBlank String reason){}
