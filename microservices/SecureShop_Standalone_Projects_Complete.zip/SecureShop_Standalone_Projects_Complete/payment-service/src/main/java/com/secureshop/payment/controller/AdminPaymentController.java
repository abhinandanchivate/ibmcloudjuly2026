package com.secureshop.payment.controller;

import com.secureshop.common.api.PageResponse;
import com.secureshop.payment.api.PaymentResponse;
import com.secureshop.payment.api.RefundRequest;
import com.secureshop.payment.api.RefundResponse;
import com.secureshop.payment.domain.PaymentStatus;
import com.secureshop.payment.service.PaymentService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/payments")
@PreAuthorize("hasAnyRole('PAYMENT_AUDITOR','ADMIN')")
public class AdminPaymentController {
    private final PaymentService service;

    public AdminPaymentController(PaymentService service) {
        this.service = service;
    }

    @GetMapping
    public PageResponse<PaymentResponse> list(@RequestParam(required = false) UUID orderId,
                                              @RequestParam(required = false) UUID customerId,
                                              @RequestParam(required = false) PaymentStatus status,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.adminList(orderId, customerId, status, pageable);
    }

    @GetMapping("/{id}")
    public PaymentResponse get(@PathVariable UUID id) {
        return service.adminGet(id);
    }

    @PostMapping("/{id}/refunds")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RefundResponse> refund(Authentication authentication,
                                                  @PathVariable UUID id,
                                                  @RequestHeader("Idempotency-Key") String idempotencyKey,
                                                  @Valid @RequestBody RefundRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.refund(authentication, id, idempotencyKey, request));
    }

    @GetMapping("/{id}/refunds")
    public List<RefundResponse> refunds(@PathVariable UUID id) {
        return service.listRefunds(id);
    }
}
