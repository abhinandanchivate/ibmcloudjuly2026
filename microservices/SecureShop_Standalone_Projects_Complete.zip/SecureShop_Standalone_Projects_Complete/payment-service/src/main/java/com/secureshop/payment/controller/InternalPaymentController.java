package com.secureshop.payment.controller;

import com.secureshop.payment.api.PaymentResponse;
import com.secureshop.payment.api.ProviderCallbackRequest;
import com.secureshop.payment.api.ReconcileRequest;
import com.secureshop.payment.service.PaymentService;
import jakarta.validation.Valid;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/v1/payments")
public class InternalPaymentController {
    private final PaymentService service;

    public InternalPaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping("/provider-callback")
    @PreAuthorize("permitAll()")
    public PaymentResponse callback(@RequestHeader("X-Provider-Signature") String signature,
                                    @Valid @RequestBody ProviderCallbackRequest request) {
        return service.callback(request, signature);
    }

    @GetMapping("/{id}/status")
    @PreAuthorize("hasRole('SYSTEM_SERVICE')")
    public PaymentResponse status(@PathVariable UUID id) {
        return service.internalStatus(id);
    }

    @PostMapping("/{id}/reconcile")
    @PreAuthorize("hasRole('SYSTEM_SERVICE')")
    public PaymentResponse reconcile(@PathVariable UUID id,
                                     @Valid @RequestBody ReconcileRequest request) {
        return service.reconcile(id, request);
    }
}
