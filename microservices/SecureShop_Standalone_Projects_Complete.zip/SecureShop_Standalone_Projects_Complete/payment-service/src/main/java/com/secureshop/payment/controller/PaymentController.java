package com.secureshop.payment.controller;

import com.secureshop.payment.api.CreatePaymentRequest;
import com.secureshop.payment.api.PaymentResponse;
import com.secureshop.payment.service.PaymentService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/payments")
@PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
public class PaymentController {
    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<PaymentResponse> create(Authentication authentication,
                                                  @RequestHeader("Idempotency-Key") String idempotencyKey,
                                                  @Valid @RequestBody CreatePaymentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.create(authentication, idempotencyKey, request));
    }

    @GetMapping("/{id}")
    public PaymentResponse get(Authentication authentication, @PathVariable UUID id) {
        return service.own(authentication, id);
    }

    @GetMapping("/order/{orderId}")
    public List<PaymentResponse> byOrder(Authentication authentication, @PathVariable UUID orderId) {
        return service.byOrder(authentication, orderId);
    }
}
