package com.secureshop.payment.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "payment_audit_events", indexes = {
        @Index(name = "idx_payment_audit_payment", columnList = "payment_id"),
        @Index(name = "idx_payment_audit_created", columnList = "created_at")
})
public class PaymentAuditEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "payment_id", nullable = false)
    private UUID paymentId;

    @Column(nullable = false, length = 60)
    private String action;

    @Enumerated(EnumType.STRING)
    @Column(name = "previous_status", length = 30)
    private PaymentStatus previousStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "new_status", length = 30)
    private PaymentStatus newStatus;

    @Column(nullable = false, length = 160)
    private String actor;

    @Column(length = 1000)
    private String details;

    @Column(name = "correlation_id", length = 100)
    private String correlationId;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void create() {
        createdAt = Instant.now();
    }

    public void setPaymentId(UUID paymentId) { this.paymentId = paymentId; }
    public void setAction(String action) { this.action = action; }
    public void setPreviousStatus(PaymentStatus previousStatus) { this.previousStatus = previousStatus; }
    public void setNewStatus(PaymentStatus newStatus) { this.newStatus = newStatus; }
    public void setActor(String actor) { this.actor = actor; }
    public void setDetails(String details) { this.details = details; }
    public void setCorrelationId(String correlationId) { this.correlationId = correlationId; }
}
