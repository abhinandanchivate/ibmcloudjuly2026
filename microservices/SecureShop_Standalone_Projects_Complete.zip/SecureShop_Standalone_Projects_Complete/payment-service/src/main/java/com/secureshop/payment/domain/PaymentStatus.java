package com.secureshop.payment.domain; public enum PaymentStatus { INITIATED, PENDING, SUCCESS, FAILED, CANCELLED, REFUND_PENDING, PARTIALLY_REFUNDED, REFUNDED }
