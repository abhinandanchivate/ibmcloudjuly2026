package com.secureshop.payment.domain; public enum RefundStatus { PENDING, COMPLETED, FAILED }
