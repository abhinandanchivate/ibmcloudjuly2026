package com.secureshop.payment.repository;

import com.secureshop.payment.domain.PaymentAuditEvent;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentAuditEventRepository extends JpaRepository<PaymentAuditEvent, UUID> {
}
