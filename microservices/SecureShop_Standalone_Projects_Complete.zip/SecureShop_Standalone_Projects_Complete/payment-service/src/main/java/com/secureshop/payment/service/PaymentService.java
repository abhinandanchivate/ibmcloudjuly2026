package com.secureshop.payment.service;

import com.secureshop.common.api.PageResponse;
import com.secureshop.common.exception.DomainException;
import com.secureshop.common.security.CurrentUser;
import com.secureshop.payment.api.CreatePaymentRequest;
import com.secureshop.payment.api.PaymentResponse;
import com.secureshop.payment.api.ProviderCallbackRequest;
import com.secureshop.payment.api.ReconcileRequest;
import com.secureshop.payment.api.RefundRequest;
import com.secureshop.payment.api.RefundResponse;
import com.secureshop.payment.client.OrderGateway;
import com.secureshop.payment.client.OrderPaymentContext;
import com.secureshop.payment.client.PaymentOutcomeRequest;
import com.secureshop.payment.client.RefundOutcomeRequest;
import com.secureshop.payment.domain.Payment;
import com.secureshop.payment.domain.PaymentAuditEvent;
import com.secureshop.payment.domain.PaymentStatus;
import com.secureshop.payment.domain.Refund;
import com.secureshop.payment.domain.RefundStatus;
import com.secureshop.payment.mapper.PaymentMapper;
import com.secureshop.payment.repository.PaymentAuditEventRepository;
import com.secureshop.payment.repository.PaymentRepository;
import com.secureshop.payment.repository.RefundRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaymentService {
    private final PaymentRepository payments;
    private final RefundRepository refunds;
    private final PaymentAuditEventRepository audits;
    private final OrderGateway orders;
    private final PaymentMapper mapper;
    private final ProviderSignatureService signatures;

    public PaymentService(
            PaymentRepository payments,
            RefundRepository refunds,
            PaymentAuditEventRepository audits,
            OrderGateway orders,
            PaymentMapper mapper,
            ProviderSignatureService signatures) {
        this.payments = payments;
        this.refunds = refunds;
        this.audits = audits;
        this.orders = orders;
        this.mapper = mapper;
        this.signatures = signatures;
    }

    @Transactional
    public PaymentResponse create(Authentication authentication, String key, CreatePaymentRequest request) {
        requireKey(key);
        Optional<Payment> existing = payments.findByIdempotencyKey(key);
        if (existing.isPresent()) {
            Payment payment = existing.get();
            if (!payment.getOrderId().equals(request.orderId())) {
                throw duplicate();
            }
            return mapper.toResponse(payment);
        }

        OrderPaymentContext context = orders.context(request.orderId());
        UUID userId = CurrentUser.userId(authentication);
        if (!context.customerId().equals(userId)) {
            throw new DomainException(HttpStatus.FORBIDDEN, "AUTH_RESOURCE_OWNERSHIP_VIOLATION",
                    "User does not own the requested order.");
        }
        if (!context.paymentEligible()) {
            throw new DomainException(HttpStatus.UNPROCESSABLE_CONTENT, "PAYMENT_ORDER_NOT_ELIGIBLE",
                    "Order is not eligible for payment.");
        }

        Payment payment = new Payment();
        payment.setOrderId(context.orderId());
        payment.setCustomerId(context.customerId());
        payment.setAmount(context.payableAmount().setScale(2, RoundingMode.HALF_UP));
        payment.setCurrency(context.currency());
        payment.setStatus(PaymentStatus.PENDING);
        payment.setIdempotencyKey(key);
        payment.setProviderReference("demo-" + UUID.randomUUID());
        Payment saved = payments.save(payment);
        audit(saved, "PAYMENT_CREATED", null, saved.getStatus(), authentication.getName(),
                "Payment initiated for order " + saved.getOrderId());
        return mapper.toResponse(saved);
    }

    @Transactional(readOnly = true)
    public PaymentResponse own(Authentication authentication, UUID id) {
        Payment payment = payments.findByIdAndCustomerId(id, CurrentUser.userId(authentication))
                .orElseThrow(this::notFound);
        return mapper.toResponse(payment);
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> byOrder(Authentication authentication, UUID orderId) {
        return payments.findByOrderIdAndCustomerIdOrderByCreatedAtDesc(orderId, CurrentUser.userId(authentication))
                .stream().map(mapper::toResponse).toList();
    }

    @Transactional
    public PaymentResponse callback(ProviderCallbackRequest request, String signature) {
        if (!signatures.valid(request, signature)) {
            throw new DomainException(HttpStatus.UNAUTHORIZED, "PAYMENT_PROVIDER_SIGNATURE_INVALID",
                    "Provider callback signature is invalid.");
        }
        if (!Set.of(PaymentStatus.SUCCESS, PaymentStatus.FAILED, PaymentStatus.CANCELLED).contains(request.status())) {
            throw new DomainException(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED",
                    "Provider callback status must be SUCCESS, FAILED, or CANCELLED.");
        }

        Payment payment = find(request.paymentId());
        if (payment.getStatus() == request.status()) {
            return mapper.toResponse(payment);
        }
        if (Set.of(PaymentStatus.SUCCESS, PaymentStatus.REFUNDED, PaymentStatus.PARTIALLY_REFUNDED)
                .contains(payment.getStatus())) {
            audit(payment, "CALLBACK_IGNORED", payment.getStatus(), payment.getStatus(), "payment-provider",
                    "Ignored callback attempting terminal-state change to " + request.status());
            return mapper.toResponse(payment);
        }

        PaymentStatus previous = payment.getStatus();
        payment.setProviderReference(request.providerReference());
        if (request.status() == PaymentStatus.SUCCESS) {
            orders.success(payment.getOrderId(),
                    new PaymentOutcomeRequest(payment.getId().toString(), request.providerReference()));
            payment.setStatus(PaymentStatus.SUCCESS);
        } else {
            orders.failed(payment.getOrderId(),
                    new PaymentOutcomeRequest(payment.getId().toString(), request.providerReference()));
            payment.setStatus(request.status());
        }
        audit(payment, "PROVIDER_CALLBACK", previous, payment.getStatus(), "payment-provider",
                "Provider reference: " + request.providerReference());
        return mapper.toResponse(payment);
    }

    @Transactional(readOnly = true)
    public PaymentResponse internalStatus(UUID id) {
        return mapper.toResponse(find(id));
    }

    @Transactional
    public PaymentResponse reconcile(UUID id, ReconcileRequest request) {
        Payment payment = find(id);
        audit(payment, "PAYMENT_RECONCILED", payment.getStatus(), payment.getStatus(), "system-service",
                request.reason());
        return mapper.toResponse(payment);
    }

    @Transactional(readOnly = true)
    public PageResponse<PaymentResponse> adminList(
            UUID orderId, UUID customerId, PaymentStatus status, Pageable page) {
        return PageResponse.from(payments.search(orderId, customerId, status, page).map(mapper::toResponse));
    }

    @Transactional(readOnly = true)
    public PaymentResponse adminGet(UUID id) {
        return mapper.toResponse(find(id));
    }

    @Transactional
    public RefundResponse refund(
            Authentication authentication, UUID paymentId, String key, RefundRequest request) {
        requireKey(key);
        Optional<Refund> existing = refunds.findByIdempotencyKey(key);
        if (existing.isPresent()) {
            Refund refund = existing.get();
            if (!refund.getPayment().getId().equals(paymentId)) {
                throw duplicate();
            }
            return mapper.toResponse(refund);
        }

        Payment payment = find(paymentId);
        if (!Set.of(PaymentStatus.SUCCESS, PaymentStatus.PARTIALLY_REFUNDED).contains(payment.getStatus())) {
            throw new DomainException(HttpStatus.UNPROCESSABLE_CONTENT, "PAYMENT_REFUND_NOT_ALLOWED",
                    "Payment status does not allow a refund.");
        }

        BigDecimal completed = refunds.findByPaymentIdAndStatus(paymentId, RefundStatus.COMPLETED).stream()
                .map(Refund::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal remaining = payment.getAmount().subtract(completed);
        BigDecimal amount = (request.amount() == null ? remaining : request.amount())
                .setScale(2, RoundingMode.HALF_UP);
        if (amount.signum() <= 0 || amount.compareTo(remaining) > 0) {
            throw new DomainException(HttpStatus.UNPROCESSABLE_CONTENT, "PAYMENT_REFUND_NOT_ALLOWED",
                    "Refund exceeds the remaining refundable amount.");
        }

        Refund refund = new Refund();
        refund.setPayment(payment);
        refund.setAmount(amount);
        refund.setStatus(RefundStatus.COMPLETED);
        refund.setIdempotencyKey(key);
        refund.setReason(request.reason());
        refund.setActor(authentication.getName());
        refund.setProviderReference("refund-" + UUID.randomUUID());
        refund.setCorrelationId(MDC.get("correlationId"));
        Refund saved = refunds.save(refund);

        PaymentStatus previous = payment.getStatus();
        BigDecimal total = completed.add(amount);
        if (total.compareTo(payment.getAmount()) == 0) {
            orders.refund(payment.getOrderId(),
                    new RefundOutcomeRequest(saved.getId().toString(), amount, saved.getProviderReference()));
            payment.setStatus(PaymentStatus.REFUNDED);
        } else {
            payment.setStatus(PaymentStatus.PARTIALLY_REFUNDED);
        }
        audit(payment, "REFUND_COMPLETED", previous, payment.getStatus(), authentication.getName(),
                "Refund " + saved.getId() + " amount " + amount + " " + payment.getCurrency());
        return mapper.toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<RefundResponse> listRefunds(UUID paymentId) {
        find(paymentId);
        return refunds.findByPaymentIdOrderByCreatedAtDesc(paymentId).stream()
                .map(mapper::toResponse).toList();
    }

    private void audit(
            Payment payment,
            String action,
            PaymentStatus previous,
            PaymentStatus next,
            String actor,
            String details) {
        PaymentAuditEvent event = new PaymentAuditEvent();
        event.setPaymentId(payment.getId());
        event.setAction(action);
        event.setPreviousStatus(previous);
        event.setNewStatus(next);
        event.setActor(actor == null || actor.isBlank() ? "unknown" : actor);
        event.setDetails(details);
        event.setCorrelationId(MDC.get("correlationId"));
        audits.save(event);
    }

    private Payment find(UUID id) {
        return payments.findById(id).orElseThrow(this::notFound);
    }

    private DomainException notFound() {
        return new DomainException(HttpStatus.NOT_FOUND, "PAYMENT_NOT_FOUND",
                "Payment record does not exist or is not accessible.");
    }

    private void requireKey(String key) {
        if (key == null || key.isBlank() || key.length() > 120) {
            throw new DomainException(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED",
                    "Idempotency-Key header is required and must be at most 120 characters.");
        }
    }

    private DomainException duplicate() {
        return new DomainException(HttpStatus.CONFLICT, "PAYMENT_DUPLICATE_REQUEST",
                "Idempotency key was already used for a different financial request.");
    }
}
