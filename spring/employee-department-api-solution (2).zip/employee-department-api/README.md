# Employee–Department PK/FK API

A complete Spring Boot REST example demonstrating a relational **Department primary key → Employee foreign key** association with Spring Data JPA and PostgreSQL.

## Technology

- Java 21
- Spring Boot 4.1.0
- Spring Web MVC
- Spring Data JPA / Hibernate
- Jakarta Bean Validation
- PostgreSQL
- Maven
- Docker Compose
- Postman collection with automated variables and tests

## Relationship

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : contains
    DEPARTMENTS {
        bigint department_id PK
        varchar code UK
        varchar name UK
        varchar location
    }
    EMPLOYEES {
        bigint employee_id PK
        varchar employee_code UK
        varchar first_name
        varchar last_name
        varchar email UK
        numeric salary
        date hire_date
        varchar status
        bigint department_id FK
    }
```

- `departments.department_id` is the primary key.
- `employees.department_id` is mandatory and references `departments.department_id`.
- JPA owner side: `Employee.department` using `@ManyToOne` and `@JoinColumn`.
- JPA inverse side: `Department.employees` using `@OneToMany(mappedBy = "department")`.
- A department cannot be deleted while employees reference it.
- REST responses use DTO records, so entities and lazy JPA relationships are not exposed directly.

## Project Structure

```text
src/main/java/com/example/employeedept
├── controller
│   ├── DepartmentController.java
│   └── EmployeeController.java
├── dto
├── entity
├── exception
├── mapper
├── repository
├── service
│   └── impl
└── EmployeeDepartmentApplication.java
```

## Run PostgreSQL

```bash
docker compose up -d
```

Default database values:

```text
Database: employee_department_db
Username: postgres
Password: postgres
Port:     5432
```

## Run the Application

```bash
mvn clean spring-boot:run
```

Base URL:

```text
http://localhost:8080/api
```

Environment variables can override the database configuration:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/employee_department_db
export DB_USERNAME=postgres
export DB_PASSWORD=postgres
mvn spring-boot:run
```

## Main Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/departments` | Create department |
| GET | `/api/departments` | List departments with employee count |
| GET | `/api/departments/{id}` | Get one department |
| PUT | `/api/departments/{id}` | Update department |
| DELETE | `/api/departments/{id}` | Delete an empty department |
| GET | `/api/departments/{id}/employees` | List employees in a department |
| POST | `/api/employees` | Create employee with department FK |
| GET | `/api/employees` | List employees |
| GET | `/api/employees?departmentId=1` | Filter employees by department |
| GET | `/api/employees/{id}` | Get one employee |
| PUT | `/api/employees/{id}` | Update employee and department |
| PUT | `/api/employees/{employeeId}/department/{departmentId}` | Transfer employee |
| DELETE | `/api/employees/{id}` | Delete employee |

## Example Department Request

```json
{
  "code": "SALES",
  "name": "Sales",
  "location": "Pune"
}
```

## Example Employee Request

```json
{
  "employeeCode": "EMP-2001",
  "firstName": "Riya",
  "lastName": "Joshi",
  "email": "riya.joshi@example.com",
  "salary": 72000.00,
  "hireDate": "2026-07-01",
  "status": "ACTIVE",
  "departmentId": 1
}
```

Allowed statuses: `ACTIVE`, `INACTIVE`, `ON_LEAVE`.

## Global Error Response

```json
{
  "timestamp": "2026-07-24T13:30:00",
  "status": 400,
  "error": "Bad Request",
  "code": "VALIDATION_FAILED",
  "message": "Request validation failed",
  "path": "/api/employees",
  "fieldErrors": {
    "email": "Email must be valid"
  }
}
```

Handled cases include resource not found, duplicate code/email, validation failure, malformed JSON, PK/UK/FK database violations, department deletion while employees exist, and unexpected errors.

## Postman

Import:

```text
postman/Employee-Department-API.postman_collection.json
```

Run the collection from top to bottom. It creates two unique departments and an employee, tests reads and updates, transfers the employee to the second department, verifies the FK deletion restriction, checks validation handling, and cleans up its generated records.

## Database SQL

- `database/schema.sql`: explicit PostgreSQL PK, unique-key and FK DDL.
- `database/useful-queries.sql`: joins, department counts, and FK inspection.
- `src/main/resources/data.sql`: idempotent starter data loaded at application startup.
