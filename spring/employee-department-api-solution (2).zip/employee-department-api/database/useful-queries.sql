-- View employees with department details
SELECT e.employee_id,
       e.employee_code,
       e.first_name,
       e.last_name,
       e.email,
       e.salary,
       e.status,
       d.department_id,
       d.code AS department_code,
       d.name AS department_name
FROM employees e
JOIN departments d ON d.department_id = e.department_id
ORDER BY e.employee_id;

-- Count employees per department, including empty departments
SELECT d.department_id,
       d.code,
       d.name,
       COUNT(e.employee_id) AS employee_count
FROM departments d
LEFT JOIN employees e ON e.department_id = d.department_id
GROUP BY d.department_id, d.code, d.name
ORDER BY d.department_id;

-- Inspect the foreign-key constraint in PostgreSQL
SELECT tc.constraint_name,
       tc.table_name,
       kcu.column_name,
       ccu.table_name AS referenced_table,
       ccu.column_name AS referenced_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
 AND tc.constraint_schema = kcu.constraint_schema
JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = tc.constraint_name
 AND ccu.constraint_schema = tc.constraint_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_name = 'employees';
