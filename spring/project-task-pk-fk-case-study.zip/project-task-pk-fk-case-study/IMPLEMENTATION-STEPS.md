# Project-Task Management API - Implementation Steps

## 1. Assignment Objective

Complete a Spring Boot REST API that manages projects and their tasks. `Project.id` is the primary key. `Task.project_id` is a mandatory foreign key. The starter already contains entities, enums, DTO records, PostgreSQL configuration, Docker Compose, SQL references, and a Postman collection.

Do not expose JPA entities directly from controllers. All request and response bodies must use the supplied DTOs.

## 2. Packages to Add

Create these packages below `com.example.projecttask`:

- `repository`
- `mapper`
- `service`
- `service.impl`
- `controller`
- `exception`
- `validation` (optional for reusable business validation)

## 3. Repository Layer

### ProjectRepository

Extend `JpaRepository<Project, Long>` and add:

- `boolean existsByProjectCodeIgnoreCase(String projectCode)`
- `boolean existsByProjectCodeIgnoreCaseAndIdNot(String projectCode, Long id)` if project code becomes editable
- a query to list projects by status
- a query to search by name or project code, ignoring case

### TaskRepository

Extend `JpaRepository<Task, Long>` and add:

- `List<Task> findByProjectIdOrderByDueDateAsc(Long projectId)`
- `Page<Task> findByProjectId(Long projectId, Pageable pageable)`
- `boolean existsByProjectIdAndTitleIgnoreCase(Long projectId, String title)`
- `boolean existsByProjectIdAndTitleIgnoreCaseAndIdNot(Long projectId, String title, Long id)`
- `long countByProjectId(Long projectId)`
- `boolean existsByProjectId(Long projectId)`
- optional filters for status, priority, and assignee email

## 4. Mapper Layer

Create `ProjectMapper` and `TaskMapper` components.

### ProjectMapper responsibilities

- Convert `ProjectCreateRequest` into a new Project.
- Copy editable values from `ProjectUpdateRequest` into an existing Project.
- Convert Project to `ProjectResponse` and include the task count.
- Convert Project to `ProjectSummaryResponse`.

### TaskMapper responsibilities

- Convert `TaskCreateRequest` into a new Task.
- Copy values from `TaskUpdateRequest` into an existing Task.
- Convert Task to `TaskResponse`, including a nested `ProjectSummaryResponse`.

Avoid recursively mapping the complete task list into every project response.

## 5. Custom Exceptions

Create at least these runtime exceptions:

- `ResourceNotFoundException`
- `DuplicateResourceException`
- `BusinessRuleException`
- `ResourceConflictException`

Suggested cases:

- Missing project or task: `ResourceNotFoundException`
- Duplicate project code or duplicate task title inside one project: `DuplicateResourceException`
- Invalid dates or invalid status transition: `BusinessRuleException`
- Deleting a project that still has tasks: `ResourceConflictException`

## 6. Project Business Rules

Implement these rules in the service layer:

1. `endDate` must be on or after `startDate`.
2. Project code must be unique, ignoring case.
3. A newly created project starts with `PLANNED` status.
4. Allowed status transitions:
   - `PLANNED -> ACTIVE or CANCELLED`
   - `ACTIVE -> ON_HOLD, COMPLETED, or CANCELLED`
   - `ON_HOLD -> ACTIVE or CANCELLED`
   - `COMPLETED` and `CANCELLED` are terminal.
5. A project cannot become `COMPLETED` while any task is not `DONE` or `CANCELLED`.
6. Updating project dates must not place any existing task due date outside the new range.
7. Deleting a project is forbidden while tasks exist. Return HTTP 409.
8. Project code should be immutable after creation.

## 7. Task Business Rules

1. The parent project must exist.
2. Tasks cannot be created in a `COMPLETED` or `CANCELLED` project.
3. A task due date must fall between the project start and end dates, inclusive.
4. Task title must be unique inside the same project, ignoring case.
5. The same title may exist under a different project.
6. A task cannot move from `DONE` back to `TODO` or `IN_PROGRESS`.
7. A task can be reassigned only to an existing non-terminal project.
8. During reassignment, recheck due date and duplicate title against the target project.
9. Reassigning to the same project should return a business-rule error.
10. Trim user-entered code, title, name, description, and email values before persistence.

## 8. Service Interfaces

Create `ProjectService` methods for:

- create project
- get project by ID
- get all projects with optional status/search filters and pagination
- update project
- update project status
- delete project

Create `TaskService` methods for:

- create task under a project
- get task by ID
- get tasks for a project
- update task
- update task status
- reassign task to another project
- delete task

Use `@Transactional` on write operations. Use `@Transactional(readOnly = true)` on read operations.

## 9. Controller Endpoints

### ProjectController: `/api/projects`

- `POST /api/projects` - create project, return 201
- `GET /api/projects/{projectId}` - return one project, 200
- `GET /api/projects` - pagination plus optional `status` and `search`, 200
- `PUT /api/projects/{projectId}` - full update, 200
- `PATCH /api/projects/{projectId}/status` - update status, 200
- `DELETE /api/projects/{projectId}` - delete empty project, 204

### TaskController

- `POST /api/projects/{projectId}/tasks` - create task, 201
- `GET /api/projects/{projectId}/tasks` - list project tasks, 200
- `GET /api/tasks/{taskId}` - get task, 200
- `PUT /api/tasks/{taskId}` - update task, 200
- `PATCH /api/tasks/{taskId}/status` - update status, 200
- `PATCH /api/tasks/{taskId}/reassign` - move task to another project, 200
- `DELETE /api/tasks/{taskId}` - delete task, 204

Use `@Valid` for request DTOs. Validate path IDs as positive values.

## 10. Global Exception Handler

Create a `@RestControllerAdvice` class and return the supplied error DTOs.

Map errors as follows:

- resource not found -> 404
- duplicate resource -> 409
- business rule violation -> 422
- delete/FK conflict -> 409
- DTO field validation -> 400 with a field-to-message map
- malformed JSON or invalid enum -> 400
- database integrity violation -> 409
- unexpected error -> 500 without exposing stack traces or SQL

Use the current request path in each error response.

## 11. PostgreSQL Setup

Option A - Docker:

```bash
docker compose up -d
```

Option B - existing PostgreSQL:

```sql
CREATE DATABASE project_task_db;
```

Default connection values in `application.yaml`:

- URL: `jdbc:postgresql://localhost:5432/project_task_db`
- username: `postgres`
- password: `postgres`

Override them through `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD`.

## 12. Run and Test

```bash
mvn clean spring-boot:run
```

Import `postman/Project-Task-API.postman_collection.json` and run the folders in sequence. The collection automatically stores `projectId`, `targetProjectId`, and `taskId`.

## 13. Minimum Unit and Integration Tests

Write tests for:

- project date validation
- duplicate project code
- task due date outside project dates
- duplicate task title under the same project
- allowed and blocked status transitions
- delete project with tasks
- successful task reassignment
- reassignment duplicate-title conflict
- controller validation response
- repository relationship persistence

## 14. Completion Checklist

- Application starts successfully.
- PostgreSQL tables contain the named PK, FK, unique constraints, and indexes.
- No entity is returned directly by a controller.
- All write operations enforce business rules.
- All expected errors use the global handler.
- The full Postman collection passes in Collection Runner.
