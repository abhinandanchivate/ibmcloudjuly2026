# Project-Task PK/FK Case Study Starter

This is a hands-on Spring Boot assignment using a different entity pair from Employee-Department.

## Relationship

- `projects.id` - primary key
- `tasks.id` - primary key
- `tasks.project_id` - mandatory foreign key referencing `projects.id`
- One Project can contain many Tasks.
- Each Task belongs to exactly one Project.

## Included Code

- Project and Task JPA entities
- ProjectStatus, TaskStatus, and TaskPriority enums
- request, response, status, reassignment, and error DTO records
- Spring Boot main class
- Maven dependencies
- PostgreSQL `application.yaml`

## Assignment Work Not Implemented

Learners must implement:

- repositories
- mappers
- services and service implementations
- controllers
- custom exceptions
- global exception handler
- automated tests

Complete requirements are in `IMPLEMENTATION-STEPS.md` and `docs/Project-Task-Case-Study.docx`.

## Start PostgreSQL

```bash
docker compose up -d
```

## Run the Application After Completing the Code

```bash
mvn clean spring-boot:run
```

## Postman

Import:

`postman/Project-Task-API.postman_collection.json`

Run folders in numerical order.
