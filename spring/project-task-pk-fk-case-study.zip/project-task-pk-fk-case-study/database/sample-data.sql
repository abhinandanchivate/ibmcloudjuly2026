INSERT INTO projects
(project_code, name, description, status, start_date, end_date, budget)
VALUES
('PRJ-2026-101', 'Customer Portal Modernization', 'Modernize the customer self-service portal.', 'ACTIVE', '2030-08-01', '2030-12-15', 150000.00),
('PRJ-2026-102', 'Data Quality Improvement', 'Improve validation and reporting for operational data.', 'PLANNED', '2030-09-01', '2031-01-31', 85000.00);

INSERT INTO tasks
(title, description, priority, status, due_date, estimated_hours, assignee_email, project_id)
VALUES
('Design authentication flow', 'Define login, token refresh, and logout behavior.', 'HIGH', 'IN_PROGRESS', '2030-08-20', 32, 'architect@example.com', 1),
('Create database migration', 'Prepare the first Flyway migration for portal tables.', 'MEDIUM', 'TODO', '2030-09-05', 16, 'developer@example.com', 1);
