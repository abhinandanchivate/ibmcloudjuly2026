CREATE TABLE projects (
    id BIGSERIAL PRIMARY KEY,
    project_code VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(1000),
    status VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    budget NUMERIC(14,2) NOT NULL,
    CONSTRAINT uk_projects_project_code UNIQUE (project_code),
    CONSTRAINT chk_project_dates CHECK (end_date >= start_date),
    CONSTRAINT chk_project_budget CHECK (budget >= 0)
);

CREATE TABLE tasks (
    id BIGSERIAL PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    description VARCHAR(1200),
    priority VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    due_date DATE NOT NULL,
    estimated_hours INTEGER NOT NULL,
    assignee_email VARCHAR(160) NOT NULL,
    project_id BIGINT NOT NULL,
    CONSTRAINT fk_tasks_project
        FOREIGN KEY (project_id)
        REFERENCES projects(id)
        ON DELETE RESTRICT,
    CONSTRAINT uk_tasks_project_title UNIQUE (project_id, title),
    CONSTRAINT chk_task_estimated_hours CHECK (estimated_hours BETWEEN 1 AND 200)
);

CREATE INDEX idx_tasks_project_id ON tasks(project_id);
CREATE INDEX idx_tasks_status ON tasks(status);
