package com.example.projecttask.dto.project;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ProjectCreateRequest(
        @NotBlank(message = "Project code is required")
        @Pattern(
                regexp = "PRJ-[0-9]{4}-[0-9]{3}",
                message = "Project code must follow PRJ-YYYY-NNN"
        )
        String projectCode,

        @NotBlank(message = "Project name is required")
        @Size(min = 3, max = 120, message = "Project name must contain 3 to 120 characters")
        String name,

        @Size(max = 1000, message = "Description cannot exceed 1000 characters")
        String description,

        @NotNull(message = "Start date is required")
        LocalDate startDate,

        @NotNull(message = "End date is required")
        LocalDate endDate,

        @NotNull(message = "Budget is required")
        @DecimalMin(value = "0.00", inclusive = true, message = "Budget cannot be negative")
        @Digits(integer = 12, fraction = 2, message = "Budget supports up to 12 integer and 2 decimal digits")
        BigDecimal budget
) {
}
