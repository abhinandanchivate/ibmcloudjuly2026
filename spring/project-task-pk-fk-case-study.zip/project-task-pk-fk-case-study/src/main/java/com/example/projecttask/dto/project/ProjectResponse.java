package com.example.projecttask.dto.project;

import com.example.projecttask.entity.ProjectStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ProjectResponse(
        Long id,
        String projectCode,
        String name,
        String description,
        ProjectStatus status,
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal budget,
        long taskCount
) {
}
