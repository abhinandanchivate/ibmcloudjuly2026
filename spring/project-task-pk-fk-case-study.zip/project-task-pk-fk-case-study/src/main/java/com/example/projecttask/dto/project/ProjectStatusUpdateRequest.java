package com.example.projecttask.dto.project;

import com.example.projecttask.entity.ProjectStatus;
import jakarta.validation.constraints.NotNull;

public record ProjectStatusUpdateRequest(
        @NotNull(message = "Project status is required")
        ProjectStatus status
) {
}
