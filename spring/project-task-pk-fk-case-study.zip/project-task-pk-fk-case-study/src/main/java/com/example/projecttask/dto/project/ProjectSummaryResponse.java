package com.example.projecttask.dto.project;

import com.example.projecttask.entity.ProjectStatus;

public record ProjectSummaryResponse(
        Long id,
        String projectCode,
        String name,
        ProjectStatus status
) {
}
