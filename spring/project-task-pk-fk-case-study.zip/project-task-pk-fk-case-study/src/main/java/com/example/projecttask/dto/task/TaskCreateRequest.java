package com.example.projecttask.dto.task;

import com.example.projecttask.entity.TaskPriority;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record TaskCreateRequest(
        @NotBlank(message = "Task title is required")
        @Size(min = 3, max = 160, message = "Task title must contain 3 to 160 characters")
        String title,

        @Size(max = 1200, message = "Task description cannot exceed 1200 characters")
        String description,

        @NotNull(message = "Task priority is required")
        TaskPriority priority,

        @NotNull(message = "Task due date is required")
        LocalDate dueDate,

        @NotNull(message = "Estimated hours are required")
        @Min(value = 1, message = "Estimated hours must be at least 1")
        @Max(value = 200, message = "Estimated hours cannot exceed 200")
        Integer estimatedHours,

        @NotBlank(message = "Assignee email is required")
        @Email(message = "Assignee email must be valid")
        @Size(max = 160)
        String assigneeEmail
) {
}
