package com.example.projecttask.dto.task;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record TaskReassignRequest(
        @NotNull(message = "Target project ID is required")
        @Positive(message = "Target project ID must be positive")
        Long targetProjectId
) {
}
