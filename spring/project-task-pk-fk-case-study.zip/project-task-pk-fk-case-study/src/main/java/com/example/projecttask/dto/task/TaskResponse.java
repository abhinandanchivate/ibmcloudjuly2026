package com.example.projecttask.dto.task;

import com.example.projecttask.dto.project.ProjectSummaryResponse;
import com.example.projecttask.entity.TaskPriority;
import com.example.projecttask.entity.TaskStatus;

import java.time.LocalDate;

public record TaskResponse(
        Long id,
        String title,
        String description,
        TaskPriority priority,
        TaskStatus status,
        LocalDate dueDate,
        Integer estimatedHours,
        String assigneeEmail,
        ProjectSummaryResponse project
) {
}
