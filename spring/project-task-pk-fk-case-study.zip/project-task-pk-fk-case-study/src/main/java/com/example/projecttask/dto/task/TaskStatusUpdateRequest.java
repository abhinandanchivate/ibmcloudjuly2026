package com.example.projecttask.dto.task;

import com.example.projecttask.entity.TaskStatus;
import jakarta.validation.constraints.NotNull;

public record TaskStatusUpdateRequest(
        @NotNull(message = "Task status is required")
        TaskStatus status
) {
}
