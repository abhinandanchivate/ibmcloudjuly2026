package com.example.projecttask.dto.task;

import com.example.projecttask.entity.TaskPriority;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record TaskUpdateRequest(
        @NotBlank(message = "Task title is required")
        @Size(min = 3, max = 160)
        String title,

        @Size(max = 1200)
        String description,

        @NotNull(message = "Task priority is required")
        TaskPriority priority,

        @NotNull(message = "Task due date is required")
        LocalDate dueDate,

        @NotNull(message = "Estimated hours are required")
        @Min(1)
        @Max(200)
        Integer estimatedHours,

        @NotBlank(message = "Assignee email is required")
        @Email(message = "Assignee email must be valid")
        @Size(max = 160)
        String assigneeEmail
) {
}
