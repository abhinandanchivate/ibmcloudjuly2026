package com.example.projecttask.entity;

public enum ProjectStatus {
    PLANNED,
    ACTIVE,
    ON_HOLD,
    COMPLETED,
    CANCELLED
}
