package com.example.projecttask.entity;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
