# Employee–Department PK/FK API with Spring Security

A complete Spring Boot REST example demonstrating:

- Department primary key to Employee foreign key relationship
- Spring Data JPA with PostgreSQL
- JWT-based login
- Database-backed users
- `ADMIN` and `USER` roles
- Endpoint authorization with `@PreAuthorize`
- Validation and global exception handling
- Postman collection with automated login and authorization tests

## Technology

- Java 21
- Spring Boot 4.1.0
- Spring Web MVC
- Spring Data JPA / Hibernate
- Spring Security
- OAuth2 Resource Server JWT support
- Jakarta Bean Validation
- PostgreSQL
- Maven
- Docker Compose

## Data Relationships

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : contains

    DEPARTMENTS {
        bigint department_id PK
        varchar code UK
        varchar name UK
        varchar location
    }

    EMPLOYEES {
        bigint employee_id PK
        varchar employee_code UK
        varchar first_name
        varchar last_name
        varchar email UK
        numeric salary
        date hire_date
        varchar status
        bigint department_id FK
    }

    APP_USERS {
        bigint user_id PK
        varchar username UK
        varchar password_hash
        varchar full_name
        varchar role
        boolean enabled
    }
```

`Employee` owns the JPA relationship using:

```java
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "department_id", nullable = false)
private Department department;
```

`Department` contains the inverse relationship:

```java
@OneToMany(mappedBy = "department")
private List<Employee> employees;
```

A department cannot be deleted while employee records reference it.

## Security Flow

```mermaid
sequenceDiagram
    participant Client
    participant AuthController
    participant AuthenticationManager
    participant PostgreSQL
    participant JWT
    participant SecuredAPI

    Client->>AuthController: POST /api/auth/login
    AuthController->>AuthenticationManager: Authenticate username/password
    AuthenticationManager->>PostgreSQL: Load app_users record
    PostgreSQL-->>AuthenticationManager: BCrypt hash and role
    AuthenticationManager-->>AuthController: Authenticated user
    AuthController->>JWT: Generate signed token with roles claim
    JWT-->>Client: Bearer access token
    Client->>SecuredAPI: Authorization: Bearer token
    SecuredAPI->>SecuredAPI: Validate JWT and @PreAuthorize
    SecuredAPI-->>Client: Response or 403
```

## Roles and Permissions

| Operation | ADMIN | USER |
|---|---:|---:|
| Login | Yes | Yes |
| View own profile | Yes | Yes |
| List departments | Yes | Yes |
| View department | Yes | Yes |
| List employees | Yes | Yes |
| View employee | Yes | Yes |
| Create/update/delete department | Yes | No |
| Create/update/delete employee | Yes | No |
| Transfer employee to another department | Yes | No |
| List application users | Yes | No |
| Create application users | Yes | No |

The role checks are placed directly on controller methods using examples such as:

```java
@PreAuthorize("hasRole('ADMIN')")
```

and:

```java
@PreAuthorize("hasAnyRole('ADMIN', 'USER')")
```

Method security is activated using `@EnableMethodSecurity`.

## Demo Accounts

| Type | Username | Password |
|---|---|---|
| Administrator | `admin` | `Admin@123` |
| Normal user | `user` | `User@123` |

These credentials are for local training only. Change them before using the project outside a demo environment.

Passwords are stored as BCrypt hashes in the `app_users` table.

## Project Structure

```text
src/main/java/com/example/employeedept
├── config
│   └── SecurityConfig.java
├── controller
│   ├── AuthController.java
│   ├── DepartmentController.java
│   ├── EmployeeController.java
│   └── UserController.java
├── dto
├── entity
│   ├── AppUser.java
│   ├── Department.java
│   ├── Employee.java
│   ├── EmployeeStatus.java
│   └── UserRole.java
├── exception
├── mapper
├── repository
├── security
│   ├── DatabaseUserDetailsService.java
│   ├── JwtTokenService.java
│   ├── RestAccessDeniedHandler.java
│   ├── RestAuthenticationEntryPoint.java
│   └── SecurityErrorWriter.java
├── service
│   └── impl
└── EmployeeDepartmentApplication.java
```

## Run PostgreSQL

```bash
docker compose up -d
```

Default database configuration:

```text
Database: employee_department_db
Username: postgres
Password: postgres
Port:     5432
```

## Run the Application

```bash
mvn clean spring-boot:run
```

Base URL:

```text
http://localhost:8080/api
```

## Configuration

Database settings can be overridden through environment variables:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/employee_department_db
export DB_USERNAME=postgres
export DB_PASSWORD=postgres
```

JWT settings:

```bash
export JWT_SECRET='replace-with-a-long-random-secret-containing-at-least-32-bytes'
export JWT_ISSUER='employee-department-api'
export JWT_EXPIRATION_SECONDS=3600
```

The default JWT secret in `application.yaml` exists only so the training project runs immediately. A production system must use a protected environment variable or secret manager.

## Login

### Request

```http
POST /api/auth/login
Content-Type: application/json
```

```json
{
  "username": "admin",
  "password": "Admin@123"
}
```

### Response

```json
{
  "accessToken": "eyJraWQiOi...",
  "tokenType": "Bearer",
  "expiresInSeconds": 3600,
  "username": "admin",
  "fullName": "System Administrator",
  "role": "ADMIN"
}
```

Use the token in subsequent requests:

```http
Authorization: Bearer <accessToken>
```

## Authentication and User Endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | Public | Authenticate and issue JWT |
| GET | `/api/users/me` | ADMIN, USER | View logged-in user |
| GET | `/api/users` | ADMIN | List application users |
| POST | `/api/users` | ADMIN | Create an ADMIN or USER account |

### Create User Request

```json
{
  "username": "trainer.user",
  "password": "Welcome@123",
  "fullName": "Trainer User",
  "role": "USER",
  "enabled": true
}
```

## Department Endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/departments` | ADMIN | Create department |
| GET | `/api/departments` | ADMIN, USER | List departments |
| GET | `/api/departments/{id}` | ADMIN, USER | Get one department |
| GET | `/api/departments/{id}/employees` | ADMIN, USER | List department employees |
| PUT | `/api/departments/{id}` | ADMIN | Update department |
| DELETE | `/api/departments/{id}` | ADMIN | Delete empty department |

## Employee Endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/employees` | ADMIN | Create employee with department FK |
| GET | `/api/employees` | ADMIN, USER | List employees |
| GET | `/api/employees?departmentId=1` | ADMIN, USER | Filter by department |
| GET | `/api/employees/{id}` | ADMIN, USER | Get one employee |
| PUT | `/api/employees/{id}` | ADMIN | Update employee |
| PUT | `/api/employees/{employeeId}/department/{departmentId}` | ADMIN | Transfer department |
| DELETE | `/api/employees/{id}` | ADMIN | Delete employee |

## Example Department Request

```json
{
  "code": "SALES",
  "name": "Sales",
  "location": "Pune"
}
```

## Example Employee Request

```json
{
  "employeeCode": "EMP-2001",
  "firstName": "Riya",
  "lastName": "Joshi",
  "email": "riya.joshi@example.com",
  "salary": 72000.00,
  "hireDate": "2026-07-01",
  "status": "ACTIVE",
  "departmentId": 1
}
```

Employee statuses: `ACTIVE`, `INACTIVE`, `ON_LEAVE`.

## Security Error Responses

Missing or invalid JWT:

```json
{
  "timestamp": "2026-07-27T15:00:00",
  "status": 401,
  "error": "Unauthorized",
  "code": "AUTHENTICATION_REQUIRED",
  "message": "A valid bearer token is required to access this resource",
  "path": "/api/employees",
  "fieldErrors": {}
}
```

Authenticated user without the required role:

```json
{
  "timestamp": "2026-07-27T15:00:00",
  "status": 403,
  "error": "Forbidden",
  "code": "ACCESS_DENIED",
  "message": "You do not have permission to perform this operation",
  "path": "/api/departments",
  "fieldErrors": {}
}
```

## Global Exception Handling

The project handles:

- Resource not found
- Duplicate department code/name
- Duplicate employee code/email
- Duplicate username
- Invalid login credentials
- Missing or invalid JWT
- Insufficient role
- Bean validation failures
- Malformed JSON
- Primary-key, unique-key, and foreign-key violations
- Attempt to delete a department containing employees
- Unexpected server errors

## Postman Collection

Import:

```text
postman/Employee-Department-API.postman_collection.json
```

Run the collection from top to bottom. It automatically:

1. Logs in as the administrator and stores the admin JWT.
2. Logs in as the normal user and stores the user JWT.
3. Verifies both allowed and forbidden role operations.
4. Creates departments and an employee using the admin token.
5. Tests the employee-to-department foreign key.
6. Tests global exception responses.
7. Deletes generated records.

## Database Files

- `database/schema.sql`: manual PostgreSQL schema including PK, FK and `app_users`.
- `database/useful-queries.sql`: relationship, constraint and security-user queries.
- `src/main/resources/data.sql`: idempotent sample departments, employees and BCrypt demo users.
