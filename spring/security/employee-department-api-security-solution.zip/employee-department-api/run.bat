@echo off
docker compose up -d
if errorlevel 1 exit /b 1
mvn spring-boot:run
