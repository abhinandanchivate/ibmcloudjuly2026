package com.example.employeedept.controller;

import com.example.employeedept.dto.LoginRequest;
import com.example.employeedept.dto.LoginResponse;
import com.example.employeedept.dto.UserResponse;
import com.example.employeedept.exception.UnauthorizedException;
import com.example.employeedept.security.JwtTokenService;
import com.example.employeedept.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenService jwtTokenService;
    private final UserService userService;

    @Autowired
    public AuthController(
            AuthenticationManager authenticationManager,
            JwtTokenService jwtTokenService,
            UserService userService) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenService = jwtTokenService;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(
            @Valid @RequestBody LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.username().trim(),
                            request.password()
                    )
            );

            UserResponse user = userService.getByUsername(authentication.getName());
            String token = jwtTokenService.generateToken(authentication);

            return ResponseEntity.ok(new LoginResponse(
                    token,
                    "Bearer",
                    jwtTokenService.getExpirationSeconds(),
                    user.username(),
                    user.fullName(),
                    user.role()
            ));
        } catch (AuthenticationException exception) {
            throw new UnauthorizedException("Invalid username or password");
        }
    }
}
