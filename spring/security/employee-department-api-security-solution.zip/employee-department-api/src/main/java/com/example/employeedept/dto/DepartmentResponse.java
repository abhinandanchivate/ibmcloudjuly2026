package com.example.employeedept.dto;

public record DepartmentResponse(
        Long id,
        String code,
        String name,
        String location,
        long employeeCount
) {
}
