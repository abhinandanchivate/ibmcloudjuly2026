package com.example.employeedept.dto;

public record DepartmentSummaryResponse(
        Long id,
        String code,
        String name
) {
}
