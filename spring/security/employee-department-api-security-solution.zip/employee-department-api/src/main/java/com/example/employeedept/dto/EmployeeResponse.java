package com.example.employeedept.dto;

import com.example.employeedept.entity.EmployeeStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

public record EmployeeResponse(
        Long id,
        String employeeCode,
        String firstName,
        String lastName,
        String fullName,
        String email,
        BigDecimal salary,
        LocalDate hireDate,
        EmployeeStatus status,
        DepartmentSummaryResponse department
) {
}
