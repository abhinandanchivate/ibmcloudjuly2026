package com.example.employeedept.dto;

import com.example.employeedept.entity.UserRole;

public record LoginResponse(
        String accessToken,
        String tokenType,
        long expiresInSeconds,
        String username,
        String fullName,
        UserRole role
) {
}
