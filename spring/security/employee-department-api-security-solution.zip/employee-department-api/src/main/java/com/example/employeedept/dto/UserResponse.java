package com.example.employeedept.dto;

import com.example.employeedept.entity.UserRole;

public record UserResponse(
        Long id,
        String username,
        String fullName,
        UserRole role,
        boolean enabled
) {
}
