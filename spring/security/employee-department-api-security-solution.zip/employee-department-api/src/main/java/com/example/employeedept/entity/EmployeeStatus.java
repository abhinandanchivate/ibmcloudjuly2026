package com.example.employeedept.entity;

public enum EmployeeStatus {
    ACTIVE,
    INACTIVE,
    ON_LEAVE
}
