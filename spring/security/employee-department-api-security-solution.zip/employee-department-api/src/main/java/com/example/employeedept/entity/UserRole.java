package com.example.employeedept.entity;

public enum UserRole {
    ADMIN,
    USER
}
