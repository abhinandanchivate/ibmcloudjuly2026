package com.example.employeedept.exception;

public class DepartmentNotEmptyException extends RuntimeException {

    public DepartmentNotEmptyException(String message) {
        super(message);
    }
}
