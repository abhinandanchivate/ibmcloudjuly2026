package com.example.employeedept.mapper;

import com.example.employeedept.dto.DepartmentRequest;
import com.example.employeedept.dto.DepartmentResponse;
import com.example.employeedept.entity.Department;
import org.springframework.stereotype.Component;

@Component
public class DepartmentMapper {

    public Department toEntity(DepartmentRequest request) {
        Department department = new Department();
        updateEntity(department, request);
        return department;
    }

    public void updateEntity(Department department, DepartmentRequest request) {
        department.setCode(normalizeCode(request.code()));
        department.setName(request.name().trim());
        department.setLocation(trimToNull(request.location()));
    }

    public DepartmentResponse toResponse(Department department, long employeeCount) {
        return new DepartmentResponse(
                department.getId(),
                department.getCode(),
                department.getName(),
                department.getLocation(),
                employeeCount
        );
    }

    private String normalizeCode(String code) {
        return code.trim().toUpperCase();
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}
