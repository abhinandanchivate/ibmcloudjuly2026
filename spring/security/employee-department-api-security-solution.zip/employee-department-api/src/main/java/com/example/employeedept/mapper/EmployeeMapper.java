package com.example.employeedept.mapper;

import com.example.employeedept.dto.DepartmentSummaryResponse;
import com.example.employeedept.dto.EmployeeRequest;
import com.example.employeedept.dto.EmployeeResponse;
import com.example.employeedept.entity.Department;
import com.example.employeedept.entity.Employee;
import org.springframework.stereotype.Component;

@Component
public class EmployeeMapper {

    public Employee toEntity(EmployeeRequest request, Department department) {
        Employee employee = new Employee();
        updateEntity(employee, request, department);
        return employee;
    }

    public void updateEntity(Employee employee, EmployeeRequest request, Department department) {
        employee.setEmployeeCode(request.employeeCode().trim().toUpperCase());
        employee.setFirstName(request.firstName().trim());
        employee.setLastName(request.lastName().trim());
        employee.setEmail(request.email().trim().toLowerCase());
        employee.setSalary(request.salary());
        employee.setHireDate(request.hireDate());
        employee.setStatus(request.status());
        employee.setDepartment(department);
    }

    public EmployeeResponse toResponse(Employee employee) {
        Department department = employee.getDepartment();
        DepartmentSummaryResponse departmentResponse = new DepartmentSummaryResponse(
                department.getId(),
                department.getCode(),
                department.getName()
        );

        return new EmployeeResponse(
                employee.getId(),
                employee.getEmployeeCode(),
                employee.getFirstName(),
                employee.getLastName(),
                employee.getFirstName() + " " + employee.getLastName(),
                employee.getEmail(),
                employee.getSalary(),
                employee.getHireDate(),
                employee.getStatus(),
                departmentResponse
        );
    }
}
