package com.example.employeedept.repository;

import com.example.employeedept.entity.Employee;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Override
    @EntityGraph(attributePaths = "department")
    Optional<Employee> findById(Long id);

    @Override
    @EntityGraph(attributePaths = "department")
    List<Employee> findAll();

    @EntityGraph(attributePaths = "department")
    List<Employee> findAllByDepartmentIdOrderByIdAsc(Long departmentId);

    boolean existsByDepartmentId(Long departmentId);

    long countByDepartmentId(Long departmentId);

    boolean existsByEmployeeCodeIgnoreCase(String employeeCode);

    boolean existsByEmployeeCodeIgnoreCaseAndIdNot(String employeeCode, Long id);

    boolean existsByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCaseAndIdNot(String email, Long id);
}
