package com.example.employeedept.service;

import com.example.employeedept.dto.DepartmentRequest;
import com.example.employeedept.dto.DepartmentResponse;
import com.example.employeedept.dto.EmployeeResponse;

import java.util.List;

public interface DepartmentService {

    DepartmentResponse create(DepartmentRequest request);

    DepartmentResponse getById(Long id);

    List<DepartmentResponse> getAll();

    DepartmentResponse update(Long id, DepartmentRequest request);

    void delete(Long id);

    List<EmployeeResponse> getEmployees(Long departmentId);
}
