package com.example.employeedept.service;

import com.example.employeedept.dto.EmployeeRequest;
import com.example.employeedept.dto.EmployeeResponse;

import java.util.List;

public interface EmployeeService {

    EmployeeResponse create(EmployeeRequest request);

    EmployeeResponse getById(Long id);

    List<EmployeeResponse> getAll(Long departmentId);

    EmployeeResponse update(Long id, EmployeeRequest request);

    EmployeeResponse transferDepartment(Long employeeId, Long departmentId);

    void delete(Long id);
}
