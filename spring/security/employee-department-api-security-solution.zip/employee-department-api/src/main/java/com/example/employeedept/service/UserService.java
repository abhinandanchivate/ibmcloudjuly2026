package com.example.employeedept.service;

import com.example.employeedept.dto.CreateUserRequest;
import com.example.employeedept.dto.UserResponse;

import java.util.List;

public interface UserService {

    UserResponse create(CreateUserRequest request);

    List<UserResponse> getAll();

    UserResponse getByUsername(String username);
}
