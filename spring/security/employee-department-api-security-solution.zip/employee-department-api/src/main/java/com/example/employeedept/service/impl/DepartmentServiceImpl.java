package com.example.employeedept.service.impl;

import com.example.employeedept.dto.DepartmentRequest;
import com.example.employeedept.dto.DepartmentResponse;
import com.example.employeedept.dto.EmployeeResponse;
import com.example.employeedept.entity.Department;
import com.example.employeedept.exception.DepartmentNotEmptyException;
import com.example.employeedept.exception.DuplicateResourceException;
import com.example.employeedept.exception.ResourceNotFoundException;
import com.example.employeedept.mapper.DepartmentMapper;
import com.example.employeedept.mapper.EmployeeMapper;
import com.example.employeedept.repository.DepartmentRepository;
import com.example.employeedept.repository.EmployeeRepository;
import com.example.employeedept.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentMapper departmentMapper;
    private final EmployeeMapper employeeMapper;

    @Autowired
    public DepartmentServiceImpl(
            DepartmentRepository departmentRepository,
            EmployeeRepository employeeRepository,
            DepartmentMapper departmentMapper,
            EmployeeMapper employeeMapper) {
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
        this.departmentMapper = departmentMapper;
        this.employeeMapper = employeeMapper;
    }

    @Override
    public DepartmentResponse create(DepartmentRequest request) {
        String normalizedCode = request.code().trim();
        String normalizedName = request.name().trim();
        validateUniqueFields(normalizedCode, normalizedName, null);

        Department department = departmentMapper.toEntity(request);
        Department savedDepartment = departmentRepository.save(department);
        return departmentMapper.toResponse(savedDepartment, 0);
    }

    @Override
    @Transactional(readOnly = true)
    public DepartmentResponse getById(Long id) {
        Department department = findDepartment(id);
        long employeeCount = employeeRepository.countByDepartmentId(id);
        return departmentMapper.toResponse(department, employeeCount);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DepartmentResponse> getAll() {
        return departmentRepository.findAll().stream()
                .map(department -> departmentMapper.toResponse(
                        department,
                        employeeRepository.countByDepartmentId(department.getId())
                ))
                .toList();
    }

    @Override
    public DepartmentResponse update(Long id, DepartmentRequest request) {
        Department department = findDepartment(id);
        validateUniqueFields(request.code().trim(), request.name().trim(), id);

        departmentMapper.updateEntity(department, request);
        Department updatedDepartment = departmentRepository.save(department);
        long employeeCount = employeeRepository.countByDepartmentId(id);
        return departmentMapper.toResponse(updatedDepartment, employeeCount);
    }

    @Override
    public void delete(Long id) {
        Department department = findDepartment(id);
        if (employeeRepository.existsByDepartmentId(id)) {
            throw new DepartmentNotEmptyException(
                    "Department " + id + " cannot be deleted because employees still reference it"
            );
        }
        departmentRepository.delete(department);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmployeeResponse> getEmployees(Long departmentId) {
        findDepartment(departmentId);
        return employeeRepository.findAllByDepartmentIdOrderByIdAsc(departmentId).stream()
                .map(employeeMapper::toResponse)
                .toList();
    }

    private Department findDepartment(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department not found with ID: " + id
                ));
    }

    private void validateUniqueFields(String code, String name, Long currentId) {
        boolean duplicateCode = currentId == null
                ? departmentRepository.existsByCodeIgnoreCase(code)
                : departmentRepository.existsByCodeIgnoreCaseAndIdNot(code, currentId);
        if (duplicateCode) {
            throw new DuplicateResourceException("Department code already exists: " + code);
        }

        boolean duplicateName = currentId == null
                ? departmentRepository.existsByNameIgnoreCase(name)
                : departmentRepository.existsByNameIgnoreCaseAndIdNot(name, currentId);
        if (duplicateName) {
            throw new DuplicateResourceException("Department name already exists: " + name);
        }
    }
}
