package com.example.employeedept.service.impl;

import com.example.employeedept.dto.EmployeeRequest;
import com.example.employeedept.dto.EmployeeResponse;
import com.example.employeedept.entity.Department;
import com.example.employeedept.entity.Employee;
import com.example.employeedept.exception.DuplicateResourceException;
import com.example.employeedept.exception.ResourceNotFoundException;
import com.example.employeedept.mapper.EmployeeMapper;
import com.example.employeedept.repository.DepartmentRepository;
import com.example.employeedept.repository.EmployeeRepository;
import com.example.employeedept.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final EmployeeMapper employeeMapper;

    @Autowired
    public EmployeeServiceImpl(
            EmployeeRepository employeeRepository,
            DepartmentRepository departmentRepository,
            EmployeeMapper employeeMapper) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.employeeMapper = employeeMapper;
    }

    @Override
    public EmployeeResponse create(EmployeeRequest request) {
        validateUniqueFields(request.employeeCode(), request.email(), null);
        Department department = findDepartment(request.departmentId());

        Employee employee = employeeMapper.toEntity(request, department);
        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toResponse(savedEmployee);
    }

    @Override
    @Transactional(readOnly = true)
    public EmployeeResponse getById(Long id) {
        return employeeMapper.toResponse(findEmployee(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmployeeResponse> getAll(Long departmentId) {
        List<Employee> employees;
        if (departmentId == null) {
            employees = employeeRepository.findAll();
        } else {
            findDepartment(departmentId);
            employees = employeeRepository.findAllByDepartmentIdOrderByIdAsc(departmentId);
        }

        return employees.stream()
                .map(employeeMapper::toResponse)
                .toList();
    }

    @Override
    public EmployeeResponse update(Long id, EmployeeRequest request) {
        Employee employee = findEmployee(id);
        validateUniqueFields(request.employeeCode(), request.email(), id);
        Department department = findDepartment(request.departmentId());

        employeeMapper.updateEntity(employee, request, department);
        Employee updatedEmployee = employeeRepository.save(employee);
        return employeeMapper.toResponse(updatedEmployee);
    }

    @Override
    public EmployeeResponse transferDepartment(Long employeeId, Long departmentId) {
        Employee employee = findEmployee(employeeId);
        Department department = findDepartment(departmentId);
        employee.setDepartment(department);
        return employeeMapper.toResponse(employeeRepository.save(employee));
    }

    @Override
    public void delete(Long id) {
        Employee employee = findEmployee(id);
        employeeRepository.delete(employee);
    }

    private Employee findEmployee(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with ID: " + id
                ));
    }

    private Department findDepartment(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department not found with ID: " + id
                ));
    }

    private void validateUniqueFields(String employeeCode, String email, Long currentId) {
        String normalizedCode = employeeCode.trim();
        String normalizedEmail = email.trim();

        boolean duplicateCode = currentId == null
                ? employeeRepository.existsByEmployeeCodeIgnoreCase(normalizedCode)
                : employeeRepository.existsByEmployeeCodeIgnoreCaseAndIdNot(normalizedCode, currentId);
        if (duplicateCode) {
            throw new DuplicateResourceException("Employee code already exists: " + normalizedCode);
        }

        boolean duplicateEmail = currentId == null
                ? employeeRepository.existsByEmailIgnoreCase(normalizedEmail)
                : employeeRepository.existsByEmailIgnoreCaseAndIdNot(normalizedEmail, currentId);
        if (duplicateEmail) {
            throw new DuplicateResourceException("Employee email already exists: " + normalizedEmail);
        }
    }
}
