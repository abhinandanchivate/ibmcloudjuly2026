package com.example.employeedept.service.impl;

import com.example.employeedept.dto.CreateUserRequest;
import com.example.employeedept.dto.UserResponse;
import com.example.employeedept.entity.AppUser;
import com.example.employeedept.exception.DuplicateResourceException;
import com.example.employeedept.exception.ResourceNotFoundException;
import com.example.employeedept.repository.AppUserRepository;
import com.example.employeedept.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserServiceImpl(
            AppUserRepository appUserRepository,
            PasswordEncoder passwordEncoder) {
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserResponse create(CreateUserRequest request) {
        String username = request.username().trim().toLowerCase();
        if (appUserRepository.existsByUsernameIgnoreCase(username)) {
            throw new DuplicateResourceException(
                    "Username already exists: " + username
            );
        }

        AppUser appUser = new AppUser();
        appUser.setUsername(username);
        appUser.setPasswordHash(passwordEncoder.encode(request.password()));
        appUser.setFullName(request.fullName().trim());
        appUser.setRole(request.role());
        appUser.setEnabled(request.enabled());

        return toResponse(appUserRepository.save(appUser));
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getAll() {
        return appUserRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getByUsername(String username) {
        AppUser appUser = appUserRepository.findByUsernameIgnoreCase(username)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with username: " + username
                ));
        return toResponse(appUser);
    }

    private UserResponse toResponse(AppUser appUser) {
        return new UserResponse(
                appUser.getId(),
                appUser.getUsername(),
                appUser.getFullName(),
                appUser.getRole(),
                appUser.isEnabled()
        );
    }
}
