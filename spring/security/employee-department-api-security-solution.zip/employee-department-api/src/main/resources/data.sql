INSERT INTO departments (code, name, location)
VALUES
    ('ENG', 'Engineering', 'Pune'),
    ('HR', 'Human Resources', 'Mumbai'),
    ('FIN', 'Finance', 'Bengaluru')
ON CONFLICT DO NOTHING;

INSERT INTO employees
(employee_code, first_name, last_name, email, salary, hire_date, status, department_id)
SELECT 'EMP-1001', 'Aarav', 'Sharma', 'aarav.sharma@example.com', 85000.00,
       DATE '2024-04-15', 'ACTIVE', department_id
FROM departments
WHERE code = 'ENG'
ON CONFLICT DO NOTHING;

INSERT INTO employees
(employee_code, first_name, last_name, email, salary, hire_date, status, department_id)
SELECT 'EMP-1002', 'Meera', 'Patil', 'meera.patil@example.com', 68000.00,
       DATE '2023-09-10', 'ACTIVE', department_id
FROM departments
WHERE code = 'HR'
ON CONFLICT DO NOTHING;

-- Demo accounts. Passwords are BCrypt hashes, never plain text in the database.
-- admin / Admin@123
-- user  / User@123
INSERT INTO app_users (username, password_hash, full_name, role, enabled)
VALUES
    ('admin', '$2y$10$dLvLkRCGW6PbNYd0ZfVV3.EzhXSqOiPWl/UgvYMmgFrQGNaWla/Re',
     'System Administrator', 'ADMIN', TRUE),
    ('user', '$2y$10$22vriipemctE.sTT2dXbiO.b93DXXtn.AWPWfZEKDB8/SwV3jdjwG',
     'Normal User', 'USER', TRUE)
ON CONFLICT DO NOTHING;
