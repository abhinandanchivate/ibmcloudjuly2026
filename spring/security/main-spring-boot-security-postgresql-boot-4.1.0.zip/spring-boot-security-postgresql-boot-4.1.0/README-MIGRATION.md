# Spring Boot 4.1 Migration Notes

This project was migrated from Spring Boot 3.1.0 to Spring Boot 4.1.0.

## Main changes

- Spring Boot parent upgraded to `4.1.0`.
- Uses Java 17 or newer.
- Replaced deprecated `spring-boot-starter-web` with `spring-boot-starter-webmvc`.
- Uses Spring Boot 4 modular test starters.
- Updated the Spring Security configuration for Spring Security 7.
- Updated `DaoAuthenticationProvider` to use its required `UserDetailsService` constructor.
- Replaced field injection in security infrastructure with constructor injection.
- Updated application JSON serialization code to Jackson 3 (`tools.jackson`).
- Added environment-variable based PostgreSQL and JWT configuration.
- Added an H2 test profile so `./mvnw test` does not require PostgreSQL.
- Corrected `RoleRepository` ID type from `Long` to `Integer`.
- Added automatic initialization for USER, MODERATOR, and ADMIN roles.

## Prerequisites

- Java 17+
- PostgreSQL
- Maven 3.6.3+ or the included Maven Wrapper

## PostgreSQL setup

Create a database named `testdb`, or provide environment variables:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/testdb
export DB_USERNAME=postgres
export DB_PASSWORD=postgres
export JWT_SECRET=QmV6S29kZXItU3ByaW5nLUJvb3QtNC1KV1QtU2VjcmV0LUtleS0yMDI2IQ==
```

Run:

```bash
./mvnw spring-boot:run
```

## Required roles

The application automatically creates `ROLE_USER`, `ROLE_MODERATOR`, and `ROLE_ADMIN` during startup.

## Endpoints

- `POST /api/auth/signup`
- `POST /api/auth/signin`
- `GET /api/test/all` — public
- `GET /api/test/user` — USER, MODERATOR, or ADMIN
- `GET /api/test/mod` — MODERATOR
- `GET /api/test/admin` — ADMIN
