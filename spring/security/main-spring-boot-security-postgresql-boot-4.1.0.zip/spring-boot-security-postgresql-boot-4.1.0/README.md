# Spring Boot 4.1 JWT Security with PostgreSQL

Spring Boot REST API demonstrating:

- Spring Boot 4.1.0
- Spring Security 7
- JWT authentication
- PostgreSQL with Spring Data JPA
- Role-based authorization using `@PreAuthorize`
- Jakarta Bean Validation
- Jackson 3

## Requirements

- Java 17 or newer
- PostgreSQL
- Maven 3.6.3+ or the included Maven Wrapper

## Database

Create the database:

```sql
CREATE DATABASE testdb;
```

Default application settings:

```properties
DB_URL=jdbc:postgresql://localhost:5432/testdb
DB_USERNAME=postgres
DB_PASSWORD=postgres
```

You can override them with environment variables:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/testdb
export DB_USERNAME=postgres
export DB_PASSWORD=your_password
export JWT_SECRET=QmV6S29kZXItU3ByaW5nLUJvb3QtNC1KV1QtU2VjcmV0LUtleS0yMDI2IQ==
export JWT_EXPIRATION_MS=86400000
```

The application automatically inserts these roles when it starts:

- `ROLE_USER`
- `ROLE_MODERATOR`
- `ROLE_ADMIN`

## Run

Linux/macOS:

```bash
./mvnw spring-boot:run
```

Windows:

```bat
mvnw.cmd spring-boot:run
```

## Test

Tests use an in-memory H2 database and do not require PostgreSQL:

```bash
./mvnw test
```

## API

### Register a normal user

```http
POST /api/auth/signup
Content-Type: application/json

{
  "username": "abhi",
  "email": "abhi@example.com",
  "password": "password123"
}
```

### Register an admin

```http
POST /api/auth/signup
Content-Type: application/json

{
  "username": "admin",
  "email": "admin@example.com",
  "password": "password123",
  "role": ["admin"]
}
```

### Sign in

```http
POST /api/auth/signin
Content-Type: application/json

{
  "username": "abhi",
  "password": "password123"
}
```

Use the returned token:

```http
Authorization: Bearer <access-token>
```

### Authorization endpoints

| Endpoint | Access |
|---|---|
| `GET /api/test/all` | Public |
| `GET /api/test/user` | USER, MODERATOR, ADMIN |
| `GET /api/test/mod` | MODERATOR |
| `GET /api/test/admin` | ADMIN |

## Migration details

See [`README-MIGRATION.md`](README-MIGRATION.md) for the Spring Boot 3.1 to 4.1 migration changes.
