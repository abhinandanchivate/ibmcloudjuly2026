package com.bezkoder.spring.security.postgresql.config;

import java.util.Arrays;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bezkoder.spring.security.postgresql.models.ERole;
import com.bezkoder.spring.security.postgresql.models.Role;
import com.bezkoder.spring.security.postgresql.repository.RoleRepository;

@Component
public class RoleDataInitializer implements ApplicationRunner {

  private final RoleRepository roleRepository;

  public RoleDataInitializer(RoleRepository roleRepository) {
    this.roleRepository = roleRepository;
  }

  @Override
  @Transactional
  public void run(ApplicationArguments args) {
    Arrays.stream(ERole.values())
        .filter(roleName -> roleRepository.findByName(roleName).isEmpty())
        .map(Role::new)
        .forEach(roleRepository::save);
  }
}
